﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Domain
{
    public class Tool
    {
        [Key]
        public Guid Id { get; set; }
        public string Area { get; set; }
        public string Section { get; set; }
        public string EqpId { get; set; }
        public string Entity { get; set; }
        public string Tooltype { get; set; }
        public string ToolModel { get; set; }
        public string Process { get; set; }
        public string Supplier { get; set; }
        public string Location { get; set; }
        public string FabBay { get; set; }
        public string ToolClass { get; set; } // FE|BE|MFE|MBE
        public string EeOwner { get; set; }
        public string PeOwner { get; set; }
        public DateTime ReleaseTarget { get; set; }
        public int Priority { get; set; }
        public string ReleaseCriteria { get; set; }
        public string CurrentStage { get; set; }
        public string Status { get; set; }
        public int StageGap { get; set; }
        public int OverallGap { get; set; }
        public Guid? ProjectId { get; set; }
        public DateTime CreateAt { get; set; }
        public string CreateBy { get; set; }

        //[ForeignKey("ProjectId")]
        public Project Project { get; set; }
    }
}
