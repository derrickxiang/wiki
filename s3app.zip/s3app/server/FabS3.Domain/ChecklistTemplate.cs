﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Domain
{
    public class ChecklistTemplate
    {
        [Key]
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string ChecklistId { get; set; }
        public string SubTitle { get; set;  }
        public string HeaderFields { get; set; }
        public string FooterFields { get; set; }
        public string Applicant { get; set; }
        public string SignOff { get; set; }
        public int Version { get; set; }
        public bool IsLatest { get; set; }
        public int TotalItems { get; set; } = 1;
        public DateTime UpdateAt { get; set; }
        public string UpdateBy { get; set; }
    }
}
