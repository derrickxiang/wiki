﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Domain
{
    public class UserTxn
    {
        [Key]
        public Guid Id { get; set; }
        public string UserId { get; set; }
        public string TxnType { get; set; }
        public string Message { get; set; }
        public DateTime TxnTime { get; set; } = DateTime.Now;
    }
}
