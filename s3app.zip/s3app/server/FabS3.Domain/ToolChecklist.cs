﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Domain
{
    public class ToolChecklist
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("ToolId")]
        public Tool Tool { get; set; }
        public Guid ToolId { get; set; }
        public Guid StageId { get; set; }
        public Guid TemplateId { get; set; }
        public string ChecklistId { get; set; }
        public int TemplateVer { get; set; }
        public int Seq { get; set; }
        public string Item { get; set; }
        public string InputType { get; set; } // Text | Boolean | Notes Link | eChecklist
        public string Owner { get; set; }
        public string Value { get; set; }
        public int TotalItems { get; set; }
        public int CompleteItems { get; set; }
        public string Status { get; set; }
        public string Remark { get; set; }
        public DateTime UpdateAt { get; set; }
        public string UpdateBy { get; set; }
        public string  ApprovalStatus { get; set; }
        public string ApprovalBy { get; set; }
        public DateTime ApprovalAt { get; set; }
        public DateTime CompleteAt { get; set; }
    }
}
