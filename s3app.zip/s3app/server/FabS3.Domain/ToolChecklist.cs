﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Domain
{
    public class ToolChecklist
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("ToolId")]
        public Tool Tool { get; set; }
        public Guid ToolId { get; set; }
        public string Name { get; set; }
        public Guid TemplateId { get; set; }

        [ForeignKey("TemplateId")]
        public ChecklistTemplate ChecklistTemplate { get; set; }
        public int ChecklistTemplateVer { get; set; }
        public string ResponsibleParty { get; set; }
        public int Seq { get; set; }
        public int TotalItems { get; set; }
        public int CompleteItems { get; set; }
        public string Status { get; set; }
        public string Remark { get; set; }
        public DateTime UpdateAt { get; set; }
        public string UpdateBy { get; set; }
        public DateTime CompleteAt { get; set; }
    }
}
