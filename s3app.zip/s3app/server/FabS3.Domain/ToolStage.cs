﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Domain
{
    public class ToolStage
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("ToolId")]
        public Tool Tool { get; set; }
        public Guid ToolId { get; set; }

        [ForeignKey("StageId")]
        public Stage Stage { get; set; }
        public Guid StageId { get; set; }
        public string ResponsibleParty { get; set; }
        public string Owner { get; set; }
        public DateTime RequireDate { get; set; }
        public string RequireDateBy { get; set; }
        public DateTime PlanDate { get; set; }
        public string PlanDateBy { get; set; }
        public DateTime ForecastDate { get; set; }
        public DateTime ActualDate { get; set; }
        public string Status { get; set; }
        public int TotalChecklist { get; set; }
        public int CompleteChecklist { get; set; }
        public string Remark { get; set; }
        public float LeadTime { get; set; }
        public DateTime UpdateAt { get; set; }
        public string UpdateBy { get; set; }
    }
}
