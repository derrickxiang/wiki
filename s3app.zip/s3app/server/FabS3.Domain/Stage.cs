﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Domain
{
    public class Stage
    {
        [Key]
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int Seq { get; set; }
        public int Tier { get; set; }
        public string Category { get; set; }
        public float LeadTime { get; set; }
        public DateTime CreateAt { get; set; } = DateTime.Now;
        public string CreateBy { get; set; }
        public string Owner { get; set; }
        public string SignOff { get; set; }
    }

    public class StageParam
    {
        public const int MaxPageSize = 50;
        private int _pageSize = 20;
        public int Current { get; set; } = 1;

        public int PageSize
        {
            get { return _pageSize; }
            set
            {
                _pageSize = (value > MaxPageSize) ? MaxPageSize : value;
            }
        }

        public string Name { get; set; }
        public int Tier { get; set; } = -1;
        public string Category { get; set; }
    }
}
