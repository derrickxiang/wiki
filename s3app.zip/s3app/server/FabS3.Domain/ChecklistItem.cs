﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Domain
{
    public class ChecklistItem
    {
        [Key]
        public Guid Id { get; set; }
        public Guid TemplateId { get; set; }
        public string ChecklistId { get; set; }
        public ChecklistTemplate Template { get; set; }
        public float Seq { get; set; }
        public float SubSeq { get; set; }
        public string Category { get; set; }
        public string SubCategory { get; set; }
        public string Owner { get; set; }
        public string InputType { get; set; }
        public int MaxLength { get; set; }
        public string InputValue { get; set; }
        public string Remark { get; set; }
    }
}
