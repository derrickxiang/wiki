﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Domain
{
    public class SignOff
    {
        [Key]
        public Guid Id { get; set; }

        [ForeignKey("ChecklistId")]
        public ToolChecklist Checklist { get; set; }
        public Guid ChecklistId { get; set; }
        public string Item { get; set; }
        public string Remark { get; set; }
        public DateTime SignDate { get; set; }
        public string SignBy { get; set; }
    }
}
