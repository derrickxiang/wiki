﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Domain
{
    public class SignOff
    {
        [Key]
        public Guid Id { get; set; }
        
        public Guid ChecklistId { get; set; }
        public Guid ToolId { get; set; }
        public Guid StageId { get; set; }
        public string StageName { get; set; }
        public string EqpId { get; set; }
        public int StageSeq { get; set; }
        public string Category { get; set; }
        public string Item { get; set; }
        public string Remark { get; set; }
        public string Status { get; set; }
        public DateTime SubmitDate { get; set; }
        public string SubmitBy { get; set; }
        public DateTime SignDate { get; set; }
        public string SignBy { get; set; }
    }

    public class SignOffGroup
    {
        [Key]
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
