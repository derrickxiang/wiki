﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Domain
{
    public class Change
    {
        [Key]
        public Guid Id { get; set; }
        [ForeignKey("ToolId")]
        public Tool Tool { get; set; }
        [ForeignKey("StageId")]
        public Stage Stage { get; set; }
        public Guid ToolId { get; set; }
        public Guid StageId { get; set; }
        public string ChangeItem { get; set; }
        public string OldValue { get; set; }
        public string NewValue { get; set; }
        public DateTime ChangeDate { get; set; }
        public string ChangeBy { get; set; }
        public string ApproveStatus { get; set; } // Pending | Approved | Rejected 
        public string HandleBy { get; set; }
        public DateTime HandleDate { get; set; }
    }
}
