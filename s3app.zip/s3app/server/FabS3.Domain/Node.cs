﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Domain
{
    public class Node
    {
        public string Title { get; set; }
        public string Value { get; set; }
        public List<Node> Children { get; set; }
    }
}
