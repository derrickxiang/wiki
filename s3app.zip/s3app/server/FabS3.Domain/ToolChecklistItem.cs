﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Domain
{
    public class ToolChecklistItem
    {
        [Key]
        public Guid Id { get; set; }
        
        public Guid ToolChecklistId { get; set; }
        public Guid ChecklistItemId { get; set; }
        public string Value { get; set; }
        public string Remark { get; set; }
        public DateTime UpdateAt { get; set; } = DateTime.Now;

        public string UpdateBy { get; set; }
    }
}
