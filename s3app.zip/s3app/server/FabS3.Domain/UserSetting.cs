﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Domain
{
    public class UserSetting
    {
        [Key]
        public Guid Id { get; set; }
        public string UserId { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
        public DateTime UpdateAt { get; set; }

        [ForeignKey("UserId")]
        public AppUser User { get; set; }
    }
}
