﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Domain
{
    public class AppUser : IdentityUser
    {
        [Key]
        public string EmpId { get => Id; set => Id = value; }
        public string Name { set; get; }
        public string Division { get; set; }
        public string Dept { set; get; }
        public string Section { set; get; }
        public string Level { set; get; }
        public string Ext { set; get; }
        public string MgrId { set; get; }
        public string DefaultProject { get; set; }
        public ICollection<AppRole> UserRoles { get; set; }
        public ICollection<RefreshToken> RefreshTokens { get; set; } = new List<RefreshToken>();
        public ICollection<UserSetting> UserSettings { get; set; }
    }
}
