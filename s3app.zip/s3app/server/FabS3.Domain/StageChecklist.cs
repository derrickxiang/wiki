﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Domain
{
    public class StageChecklist
    {
        public Guid Id { get; set; }
        public Guid StageId { get; set; }
        public Stage Stage { get; set; }
        public int Seq { get; set; }
        public string Item { get; set; }
        public string Description { get; set; }
        public string InputType { get; set; } // Text | Boolean | Notes Link | eChecklist
        public string Owner { get; set; }
        public DateTime UpdateAt { get; set; }
        public string UpdateBy { get; set; }
    }
}
