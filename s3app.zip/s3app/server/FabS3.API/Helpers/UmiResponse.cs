﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FabS3.API.Helpers
{
    public class UmiResponse
    {
        public bool Success { get; set; }
        public object Data { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
        public int Status { get; set; }
        public string StatusText { get; set; }
        public int ShowType { get; set; } // error display type： 0 silent; 1 message.warn; 2 message.error; 4 notification; 9 page
        public string TraceId { get; set; }
        public string Host { get; set; }
    }
}
