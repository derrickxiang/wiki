﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FabS3.API.Helpers
{
    public class StringToGuidResolver : IValueResolver<string, Guid, Guid> 
    {
        public Guid Resolve(string source, Guid destination, Guid member, ResolutionContext context)
        {
            return String.IsNullOrEmpty(source) ? Guid.Empty : Guid.Parse(source);
        }
    }
}
