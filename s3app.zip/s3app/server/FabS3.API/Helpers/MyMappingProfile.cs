﻿using AutoMapper;
using FabS3.API.DTOs;
using FabS3.Domain;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FabS3.API.Helpers
{
    public class MyMappingProfile : Profile
    {
        public MyMappingProfile()
        {

            CreateMap<ChecklistItem, ChecklistItem>();
            CreateMap<ChecklistTemplate, ChecklistTemplate>();

            CreateMap<Project, Project>();

            CreateMap<Stage, Stage>();

            CreateMap<StageChecklist, StageChecklist>();

            CreateMap<Tool, ToolDto>()
                .ForMember(o => o.Project, opt => opt.MapFrom( d => d.Project.Name));
            CreateMap<ToolDto, Tool>()
                .ForMember(dest => dest.ProjectId,
                opt => opt.MapFrom(
                    src => String.IsNullOrEmpty(src.ProjectId) ? Guid.Empty : Guid.Parse(src.ProjectId)));

            CreateMap<ToolForCreationDto, Tool>()
                .ForMember(dest => dest.ProjectId, 
                opt => opt.MapFrom(
                    src => String.IsNullOrEmpty(src.ProjectId) ? Guid.Empty : Guid.Parse(src.ProjectId) ));

            CreateMap<ToolStageForCreationDto, ToolStage>();

            CreateMap<ToolStage, ToolStageDto>()
                .ForMember(d => d.EqpId, opt => opt.MapFrom(s => s.Tool.EqpId))
                .ForMember(d => d.Area, opt => opt.MapFrom(s => s.Tool.Area))
                .ForMember(d => d.StageName, opt => opt.MapFrom(s => s.Stage.Name));

            CreateMap<ToolStage, ToolStage>();
        }
    }
}
