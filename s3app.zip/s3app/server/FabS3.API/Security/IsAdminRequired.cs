﻿using FabS3.API.DTOs;
using FabS3.Data;
using FabS3.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace FabS3.API.Security
{
    public class IsAdminRequirement : IAuthorizationRequirement
    {
    }

    public class IsAdminRequirementHandler : AuthorizationHandler<IsAdminRequirement>
    {
        private readonly S3Context _context;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public IsAdminRequirementHandler(S3Context context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }

        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, IsAdminRequirement requirement)
        {
            var userId = context.User.FindFirstValue(ClaimTypes.Name);

            if (userId == null) return Task.CompletedTask;

            var user = _context.Users
                .Join(_context.UserRoles, u => u.Id, ur => ur.UserId, (u, ur) => new { u, ur })
                .Join(_context.Roles, ur => ur.ur.RoleId, r => r.Id, (ur, r) => new { ur, r })
                .Where(c => c.ur.u.EmpId == userId)
                .Select(c => new UserDto()
                {
                    EmpId = c.ur.u.EmpId,
                    Role = c.r.Name
                }).ToList();
                

            if (user == null || user.Count() < 1) return Task.CompletedTask;

            if (user.Where(r => r.Role == "Admin").Count() > 0) context.Succeed(requirement);

            return Task.CompletedTask;
        }
    }
}
