﻿using FabS3.Domain;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading.Tasks;

namespace FabS3.API.Security
{
    public class MySignInManager : SignInManager<AppUser>
    {
        public MySignInManager(UserManager<AppUser> userManager, 
            IHttpContextAccessor contextAccessor, 
            IUserClaimsPrincipalFactory<AppUser> claimsFactory, 
            IOptions<IdentityOptions> optionsAccessor, 
            ILogger<SignInManager<AppUser>> logger, 
            IAuthenticationSchemeProvider schemes, 
            IUserConfirmation<AppUser> confirmation) : base(userManager, contextAccessor, claimsFactory, optionsAccessor, logger, schemes, confirmation)
        {
        }

        public override async Task<SignInResult> CheckPasswordSignInAsync(AppUser user, string password, bool lockoutOnFailure)
        {
#if DEBUG
            //if (user.EmpId == "00072289") return SignInResult.Success;

#endif
            try
            {
                using (WindowsLogin wi = new WindowsLogin(user.EmpId, password))
                {
#pragma warning disable CA1416 // Validate platform compatibility
                    WindowsIdentity.RunImpersonated(wi.Identity.AccessToken, () =>
                    {
                        WindowsIdentity user = WindowsIdentity.GetCurrent();

                        var empId = user.Name.Replace("UMC\\", "");

                        AppUser appUser = new AppUser();

                        appUser.EmpId = empId;


                    });
#pragma warning restore CA1416 // Validate platform compatibility

                    return SignInResult.Success;
                }
            }
            catch (Exception ex)
            {

                return SignInResult.Failed;
            }
        }
    }
}
