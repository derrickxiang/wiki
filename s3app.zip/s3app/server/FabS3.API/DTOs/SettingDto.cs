﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FabS3.API.DTOs
{
    public class SettingDto
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
}
