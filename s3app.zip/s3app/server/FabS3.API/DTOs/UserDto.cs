﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FabS3.API.DTOs
{
    public class UserDto
    {
        public string EmpId { get; set; }
        public string UserId { get; set; }
        public string Name { get; set; }
        public string Dept { get; set; }
        public string Section { get; set; }
        public string Role { get; set; }
        public string[] Roles { get; set; }
        public string Token { get; set; }
        public int NotifyCount { get; set; }
        public int UnreadCount { get; set; }
        public string Phone { get; set; }
        public string DefaultProject { get; set; }
    }
}
