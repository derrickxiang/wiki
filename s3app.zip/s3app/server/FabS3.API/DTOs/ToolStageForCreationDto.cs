﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FabS3.API.DTOs
{
    public class ToolStageForCreationDto
    {     
        public string ToolId { get; set; }
        public string StageId { get; set; }
        public string? ResponsibleParty { get; set; }
        public string? Owner { get; set; }
        public DateTime? RequireDate { get; set; }
        public string? RequireDateBy { get; set; }
        public DateTime? PlanDate { get; set; }
        public string? PlanDateBy { get; set; }
        public DateTime? ForecastDate { get; set; }
        public DateTime? ActualDate { get; set; }
        public string? Status { get; set; }
        public int TotalChecklist { get; set; }
        public int CompleteChecklist { get; set; }
        public string Remark { get; set; }
        public float LeadTime { get; set; }
        public DateTime UpdateAt { get; set; }
        public string UpdateBy { get; set; }
    }

    public class ToolStageDto
    {
        public string Id { get; set; }
        public string ToolId { get; set; }
        public string StageId { get; set; }
        public string? EqpId { get; set; }
        public string? StageName { get; set; }
        public string? Area { get; set; }
        public string? ResponsibleParty { get; set; }
        public string? Owner { get; set; }
        public DateTime? RequireDate { get; set; }
        public string? RequireDateBy { get; set; }
        public DateTime? PlanDate { get; set; }
        public string? PlanDateBy { get; set; }
        public DateTime? ForecastDate { get; set; }
        public DateTime? ActualDate { get; set; }
        public string? Status { get; set; }
        public int TotalChecklist { get; set; }
        public int CompleteChecklist { get; set; }
        public string Remark { get; set; }
        public float LeadTime { get; set; }
        public DateTime UpdateAt { get; set; }
        public string UpdateBy { get; set; }
    }
}
