﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FabS3.API.DTOs
{
    public class ToolDto
    {
        public string Id { get; set; }
        public string Area { get; set; }
        public string Section { get; set; }
        public string EqpId { get; set; }
        public string Entity { get; set; }
        public string Tooltype { get; set; }
        public string ToolModel { get; set; }
        public string Process { get; set; }
        public string ProcessType { get; set; }
        public string Supplier { get; set; }
        public string Location { get; set; }
        public string FabBay { get; set; }
        public string ToolClass { get; set; }
        public string EeOwner { get; set; }
        public string PeOwner { get; set; }
        public DateTime ReleaseTarget { get; set; }
        public int Priority { get; set; }
        public string ReleaseCriteria { get; set; }
        public string CurrentStage { get; set; }
        public string Status { get; set; }
        public int StageGap { get; set; }
        public int OverallGap { get; set; }
        public string ProjectId { get; set; }
        public string Project { get; set; }
        public DateTime CreateAt { get; set; }
        public string CreateBy { get; set; }

        // plan dates
        public string ToolRegistrationPlanDate { get; set; }
        public string PreSiteInspectionPlanDate { get; set; }
        public string SiteInspectionPlanDate { get; set; }
        public string PreMoveInPlanDate { get; set; }
        public string MoveInPlanDate { get; set; }
        public string PreESO1PlanDate { get; set; }
        public string ESO1PlanDate { get; set; }
        public string PreESO2PlanDate { get; set; }
        public string ESO2PlanDate { get; set; }
        public string PostESO2PlanDate { get; set; }
        public string EEHandoverPlanDate { get; set; }
        public string ProcessTuningPlanDate { get; set; }
        public string NPWMatchingPlanDate { get; set; }
        public string PrePcrbPlanDate { get; set; }
        public string PcrbQualPlanDate { get; set; }
        public string PrePilotPlanDate { get; set; }
        public string PilotPlanDate { get; set; }

        // req dates
        public string ToolRegistrationReqDate { get; set; }
        public string PreSiteInspectionReqDate { get; set; }
        public string SiteInspectionReqDate { get; set; }
        public string PreMoveInReqDate { get; set; }
        public string MoveInReqDate { get; set; }
        public string PreESO1ReqDate { get; set; }
        public string ESO1ReqDate { get; set; }
        public string PreESO2ReqDate { get; set; }
        public string ESO2ReqDate { get; set; }
        public string PostESO2ReqDate { get; set; }
        public string EEHandoverReqDate { get; set; }
        public string ProcessTuningReqDate { get; set; }
        public string NPWMatchingReqDate { get; set; }
        public string PrePcrbReqDate { get; set; }
        public string PcrbQualReqDate { get; set; }
        public string PrePilotReqDate { get; set; }
        public string PilotReqDate { get; set; }

        public string PreSiteInspectionLT { get; set; }
        public string PreMoveInLT { get; set; }
        public string PreESO1LT { get; set; }
        public string PreESO2LT { get; set; }
        public string PostESO2LT { get; set; }
        public string ProcessTuningLT { get; set; }
        public string PrePcrbLT { get; set; }
        public string PrePilotLT { get; set; }
        public string QualDataReviewLT { get; set; }

        public static object GetPropValue(object src, string propName)
        {
            return src.GetType().GetProperty(propName) != null ? src.GetType().GetProperty(propName).GetValue(src, null) : null;
        }
    }

    public class ToolForCreationDto
    {
        public string Area { get; set; }
        public string Section { get; set; }
        public string EqpId { get; set; }
        public string Entity { get; set; }
        public string Tooltype { get; set; }
        public string ToolModel { get; set; }
        public string Process { get; set; }
        public string Supplier { get; set; }
        public string Location { get; set; }
        public string FabBay { get; set; }
        public string ToolClass { get; set; }
        public string EeOwner { get; set; }
        public string PeOwner { get; set; }
        public DateTime ReleaseTarget { get; set; }
        public int Priority { get; set; }
        public string ReleaseCriteria { get; set; }
        public string CurrentStage { get; set; }
        public string Status { get; set; }
        public int StageGap { get; set; }
        public int OverallGap { get; set; }
        public string ProjectId { get; set; }
        public DateTime CreateAt { get; set; }
        public string CreateBy { get; set; }
    }
}
