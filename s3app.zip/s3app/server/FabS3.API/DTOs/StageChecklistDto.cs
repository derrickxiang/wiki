﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FabS3.API.DTOs
{
    public class StageChecklistDto
    {
        public string Id { get; set; }
        public string StageId { get; set; }
        public string StageName { get; set; }
        public int Seq { get; set; }
        public string Item { get; set; }
        public string ChecklistId { get; set; }
        public string TemplateId { get; set; }
        public int TemplateVer { get; set; }
        public string Description { get; set; }
        public string InputType { get; set; } // Text | Boolean | Notes Link | eChecklist
        public string Owner { get; set; }
        public DateTime UpdateAt { get; set; }
        public string UpdateBy { get; set; }
    }
}
