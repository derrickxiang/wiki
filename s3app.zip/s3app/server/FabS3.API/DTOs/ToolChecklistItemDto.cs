﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FabS3.API.DTOs
{
    public class ToolChecklistItemDto
    {
        public Guid Id { get; set; }
        
        public Guid ToolChecklistId { get; set; }
        public Guid ChecklistItemId { get; set; }
        public float Seq { get; set; }
        public float SubSeq { get; set; }
        public string Category { get; set; }
        public string SubCategory { get; set; }

        public string InputType { get; set; }
        public string Value { get; set; }
        public string Remark { get; set; }
        public DateTime UpdateAt { get; set; } 

        public string UpdateBy { get; set; }
    }
}
