﻿using AutoMapper;
using FabS3.API.Helpers;
using FabS3.Data.Services;
using FabS3.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FabS3.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SignOffController : ControllerBase
    {
        public SignOffController(
            IRepositoryWrapper repositoryWrapper,
            IMapper mapper,
            ILogger<SignOffController> logger
            )
        {
            Repository = repositoryWrapper;
            Logger = logger;
            Mapper = mapper;
        }

        public IRepositoryWrapper Repository { get; set; }
        public ILogger<SignOffController> Logger { get; set; }
        public IMapper Mapper { get; }

        [HttpGet]
        public async Task<ActionResult<UmiResponse>> GetSignOffsAsync()
        {
            var requests = await Repository.SignOff.GetAllAsync();

            return Ok(new UmiResponse
            {
                Data = requests.OrderBy(s => s.SubmitDate).ToList(),
                Success = true
            });
        }

        [HttpGet("groups")]
        public async Task<ActionResult<UmiResponse>> GetSignOffGroupsAsync()
        {
            var groups = await Repository.SignOffGroup.GetAllAsync();

            return Ok(new UmiResponse
            {
                Data = groups.OrderBy(s => s.Name).ToList(),
                Success = true
            });
        }

        [HttpPut]
        public async Task<IActionResult> updateSignoffAsync(SignOff signOff)
        {
            var existRecord = await Repository.SignOff.GetByIdAsync(signOff.Id);

            if (existRecord == null)
            {
                return NotFound();
            }

            if (existRecord.Status != "Submitted")
            {
                return BadRequest("Invalid request status");
            }

            Mapper.Map<SignOff, SignOff>(signOff, existRecord);

            Repository.SignOff.Update(existRecord);

            var result = await Repository.SignOff.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to update signoff record ", signOff);
                return BadRequest();
            }

            return NoContent();
        }

        [HttpPost("checklist")]
        public async Task<IActionResult> updateChecklistSingoffAsync(SignOff signOff)
        {
            if (signOff == null) return BadRequest();

            var existRecord = await Repository.SignOff.GetByConditionAsync(t =>
                        t.ToolId == signOff.ToolId &&
                        t.StageId == signOff.StageId &&
                        t.Category == signOff.Category &&
                        t.Status == "Submitted");

            if (existRecord != null && existRecord.Count() > 0)
            {
                var oldRecord = existRecord.First();

                oldRecord.Status = signOff.Status;
                oldRecord.SignBy = signOff.SignBy;
                oldRecord.SignDate = signOff.SignDate;
                oldRecord.ChecklistId = signOff.ChecklistId;
                oldRecord.Remark = signOff.Remark;

                Repository.SignOff.Update(oldRecord);
            }
            else
            {
                Repository.SignOff.Create(signOff);
            }

            var result = await Repository.SignOff.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to create Signoff.");

                return BadRequest();
            }

            var chkList = await Repository.ToolChecklist.GetByIdAsync(signOff.ChecklistId);

            if (chkList != null)
            {
                chkList.Status = "Approving";
                chkList.Value = "Approving";

                Repository.ToolChecklist.Update(chkList);

                await Repository.ToolChecklist.SaveAsync();
            }

            return Ok();

        }

        [HttpPost("batchUpdate")]
        public async Task<IActionResult> updateSignoffsAsync(SignOff[] signOffs)
        {

            if (signOffs.Length == 0) return BadRequest();

            foreach (SignOff signOff in signOffs)
            {
                var existRecord = await Repository.SignOff.GetByConditionAsync(t =>
                        t.ToolId == signOff.ToolId &&
                        t.StageId == signOff.StageId &&
                        t.Category == signOff.Category &&
                        t.Status == "Submitted");

                if (existRecord != null && existRecord.Count() > 0)
                {
                    var oldRecord = existRecord.First();

                    oldRecord.Status = signOff.Status;
                    oldRecord.SignBy = signOff.SignBy;
                    oldRecord.SignDate = signOff.SignDate;
                    oldRecord.Remark = signOff.Remark;

                    Repository.SignOff.Update(oldRecord);
                }
                else
                {
                    Repository.SignOff.Create(signOff);
                }

                
            }


            var result = await Repository.SignOff.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to create Signoff.");

                return BadRequest();
            }

            var signoff = signOffs[0];

            if (signoff.Category.ToUpper() == "STAGE COMPLETION")
            {
                var toolStageEnum = await Repository.ToolStage.GetByConditionAsync(t => t.ToolId == signoff.ToolId && t.StageId == signoff.StageId);

                if (toolStageEnum != null && toolStageEnum.Count() > 0)
                {
                    var toolStage = toolStageEnum.First();

                    toolStage.Status = "Approving";

                    result = await Repository.ToolStage.SaveAsync();

                    if (!result)
                    {
                        Logger.LogError("Fail to update tool stage status");

                        return BadRequest();
                    }
                }
            }


            return Ok();
        }
    }
}
