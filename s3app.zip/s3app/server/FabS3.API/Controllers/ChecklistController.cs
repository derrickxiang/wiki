﻿using AutoMapper;
using FabS3.API.Helpers;
using FabS3.Data.Services;
using FabS3.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace FabS3.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChecklistController : ControllerBase
    {
        public ChecklistController(
            IRepositoryWrapper repositoryWrapper,
            IMapper mapper,
            ILogger<ChecklistController> logger
            )
        {
            Repository = repositoryWrapper;
            Mapper = mapper;
            Logger = logger;
        }

        public IMapper Mapper { get; }
        public IRepositoryWrapper Repository { get; set; }
        public ILogger<ChecklistController> Logger { get; set; }

        [HttpGet("template")]
        public async Task<ActionResult<UmiResponse>> GetChecklistTemplatesAsync()
        {
            var checklists = await Repository.ChecklistTemplate.GetByConditionAsync(t => t.IsLatest);

            return new UmiResponse
            {
                Data = checklists.OrderBy(s => s.Name).ToList(),
                Success = true
            };
        }

        [HttpGet("template/{checklistTemplateId}", Name = nameof(GetChecklistTemplateAsync))]
        public async Task<ActionResult<ChecklistTemplate>> GetChecklistTemplateAsync(Guid checklistTemplateId)
        {
            var checklist = await Repository.ChecklistTemplate.GetByIdAsync(checklistTemplateId);

            if (checklist == null)
            {
                return NotFound();
            }

            return checklist;
        }

        [HttpGet("template/id")]
        public async Task<ActionResult<UmiResponse>> GetChecklistTemplateByIdAsync(string checklistId)
        {
            var checklist = await Repository.ChecklistTemplate.GetByConditionAsync(c => c.ChecklistId == checklistId && c.IsLatest);

            if (checklistId == null || checklistId.Count() == 0)
            {
                return NotFound();
            }

            return new UmiResponse
            {
                Data = checklist.FirstOrDefault(),
                Success = true
            };
        }

        [HttpPost("template")]
        public async Task<IActionResult> AddChecklistTemplateAsync(
            ChecklistTemplate checklistToCreate
            )
        {
            var checklist = Mapper.Map<ChecklistTemplate>(checklistToCreate);

            var templates = await Repository.ChecklistTemplate.GetByConditionAsync(t => t.ChecklistId == checklist.ChecklistId);

            if (templates.Count() == 0)
            {
                checklist.Version = 1;
                checklist.IsLatest = true;
            }
            else
            {
                var oldChecklist = templates.Where(t => t.IsLatest).FirstOrDefault();

                if (oldChecklist != null)
                {
                    oldChecklist.IsLatest = false;
                    Repository.ChecklistTemplate.Update(oldChecklist);
                }

                checklist.Version = templates.Select(t => t.Version).Max() + 1;
                checklist.IsLatest = true;

            }

            Repository.ChecklistTemplate.Create(checklist);

            var result = await Repository.ChecklistTemplate.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to create ChecklistTemplate.");
            }

            return Ok();
        }


        [HttpDelete("template")]
        public async Task<IActionResult> DeleteChecklistTemplateAsync([FromBody] JsonElement key)
        {
            var checklistTemplateId = key.GetProperty("checklistTemplateId").ToString();

            var checklist = await Repository.ChecklistTemplate.GetByIdAsync(Guid.Parse(checklistTemplateId));

            if (checklist == null)
            {
                return BadRequest();
            }

            //Repository.ChecklistTemplate.Delete(checklist);

            checklist.IsLatest = false;
            Repository.ChecklistTemplate.Update(checklist);

            var result = await Repository.ChecklistTemplate.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to remove checklist ", checklist);
                return BadRequest();
            }

            return NoContent();

        }

        [HttpPut("template")]
        public async Task<IActionResult> UpdateChecklistTemplateAsync(ChecklistTemplate checklistToUpdate)
        {
            var checklist = await Repository.ChecklistTemplate.GetByIdAsync(checklistToUpdate.Id);

            if (checklist == null)
            {
                return BadRequest();
            }

            Mapper.Map<ChecklistTemplate, ChecklistTemplate>(checklistToUpdate, checklist);

            Repository.ChecklistTemplate.Update(checklist);

            var result = await Repository.ChecklistTemplate.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to update checklist ", checklist);
                return BadRequest();
            }

            return NoContent();

        }

        [HttpGet("item")]
        public async Task<ActionResult<IEnumerable<ChecklistItem>>> GetChecklistItemsAsync()
        {
            var checklists = await Repository.ChecklistItem.GetAllAsync();

            return checklists.OrderBy(s => s.Seq).ThenBy(s => s.SubSeq).ToList();
        }

        [HttpGet("items")]
        public async Task<ActionResult<UmiResponse>> GetChecklistItems(string checklistId)
        {
            var items = await Repository.ChecklistItem.GetByConditionAsync(i => i.ChecklistId == checklistId);

            if (items == null)
            {
                return NotFound();
            }

            return new UmiResponse
            {
                Data = items.OrderBy(i => i.Seq).ThenBy(i => i.SubSeq).ToList(),
                Success = true
            };
        }

        [HttpGet("item/{checklistItemId}", Name = nameof(GetChecklistItemAsync))]
        public async Task<ActionResult<ChecklistItem>> GetChecklistItemAsync(Guid checklistItemId)
        {
            var checklist = await Repository.ChecklistItem.GetByIdAsync(checklistItemId);

            if (checklist == null)
            {
                return NotFound();
            }

            return checklist;
        }

        [HttpPost("item")]
        public async Task<ActionResult<UmiResponse>> AddChecklistItemAsync(
            ChecklistItem[] checklistToCreate
            )
        {
            if (checklistToCreate == null || checklistToCreate.Length == 0)
            {
                return BadRequest();
            }

            var checklist0 = Mapper.Map<ChecklistItem>(checklistToCreate[0]);

            ChecklistTemplate template = new ChecklistTemplate();

            if (!String.IsNullOrEmpty(checklist0.ChecklistId))
            {
                var templates = await Repository.ChecklistTemplate.GetByConditionAsync(t => 
                        (t.ChecklistId == checklist0.ChecklistId && t.IsLatest));

                if (templates != null && templates.Count() > 0)
                {
                    template = templates.First();
                }


            }

            for (int i =0; i < checklistToCreate.Length; i++)
            {
                var checklist = Mapper.Map<ChecklistItem>(checklistToCreate[i]);

                if (!String.IsNullOrEmpty(checklist.ChecklistId))
                {                    
                    if (template.Id != null)
                    {
                        checklist.TemplateId = template.Id;
                    }
                }

                Repository.ChecklistItem.Create(checklist);

                
            }

            var result = await Repository.ChecklistItem.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to create ChecklistItem.");
            }
            else
            {
                template.TotalItems = checklistToCreate.Length;

                Repository.ChecklistTemplate.Update(template);

                await Repository.ChecklistTemplate.SaveAsync();
            }

            

            return new UmiResponse
            {
                Success = true
            };
                        
        }


        [HttpDelete("item/{checklistItemId}")]
        public async Task<IActionResult> DeleteChecklistItemAsync(Guid checklistItemId)
        {
            var checklist = await Repository.ChecklistItem.GetByIdAsync(checklistItemId);

            if (checklist == null)
            {
                return BadRequest();
            }

            Repository.ChecklistItem.Delete(checklist);

            var result = await Repository.ChecklistItem.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to remove checklist ", checklist);
                return BadRequest();
            }

            return NoContent();

        }

        [HttpPut("item")]
        public async Task<IActionResult> UpdateChecklistItemAsync(ChecklistItem checklistToUpdate)
        {
            var checklist = await Repository.ChecklistItem.GetByIdAsync(checklistToUpdate.Id);

            if (checklist == null)
            {
                return BadRequest();
            }

            Mapper.Map<ChecklistItem, ChecklistItem>(checklistToUpdate, checklist);

            Repository.ChecklistItem.Update(checklist);

            var result = await Repository.ChecklistItem.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to update checklist ", checklist);
                return BadRequest();
            }

            return NoContent();

        }
    }
}
