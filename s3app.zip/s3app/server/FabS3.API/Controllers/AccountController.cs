﻿using AutoMapper;
using FabS3.API.DTOs;
using FabS3.API.Extensions;
using FabS3.API.Helpers;
using FabS3.Application.Account;
using FabS3.Application.Common;
using FabS3.Data;
using FabS3.Data.Services;
using FabS3.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace FabS3.API.Controllers
{

    public class AccountController : BaseApiController
    {
        public AccountController(
            UserManager<AppUser> userManager,
            SignInManager<AppUser> signInManager,
            RoleManager<AppRole> roleManager,
            TokenService tokenService,
            IConfiguration config,
            ILogger<AccountController> logger,
            IRepositoryWrapper repositoryWrapper,
            IMapper mapper,
            S3Context context
            )
        {
            Mapper = mapper;
            Repository = repositoryWrapper;
            UserManager = userManager;
            SignInManager = signInManager;
            RoleManager = roleManager;
            TokenService = tokenService;
            Config = config;
            Logger = logger;
            Context = context;
        }

        public IMapper Mapper { get; }
        public UserManager<AppUser> UserManager { get; }
        public SignInManager<AppUser> SignInManager { get; }
        public RoleManager<AppRole> RoleManager { get; }
        public TokenService TokenService { get;  }
        public IConfiguration Config { get;  }
        public ILogger Logger { get; }
        public IRepositoryWrapper Repository { get; set; }
        public S3Context Context { get; set; }

        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<ActionResult<UserDto>> Login(LoginDto login)
        {

            try
            {
                var user = await UserManager.Users.FirstOrDefaultAsync(a => a.EmpId == login.Username);

                if (user == null)
                {
                    Logger.LogInformation("User first loggin, start initiating ...({user})", login.Username);


                    var res = await Mediator.Send(new Detail.Query
                    {
                        EmpId = login.Username
                    });

                    if (res.IsSuccess)
                    {
                        user = res.Value;
                        await UserManager.AddToRoleAsync(user, "User");


                        Logger.LogInformation("User init successfully. ({0})", login.Username);
                    }
                    else
                    {
                        Logger.LogWarning("User init failed - {res}", res);
                        return Unauthorized(new UmiResponse
                        {
                            Success = false,
                            Status = 401,
                            StatusText = "Invalid user"
                        });
                    }

                }


                var result = await SignInManager.CheckPasswordSignInAsync(user, login.Password, false);

                if (result.Succeeded)
                {
                    Logger.LogInformation("User logged in successfully. ({0})", login.Username);

                    await SetRefreshToken(user);

                    var roles = await UserManager.GetRolesAsync(user);

                    if (roles.Count() == 0)
                    {
                        var userRole = RoleManager.FindByNameAsync("User").Result;

                        if (userRole != null)
                        {
                            await UserManager.AddToRoleAsync(user, userRole.Name);
                        }

                    }

                    return Ok(new UmiResponse {
                       Data = await CreateUserObject(user),
                       Success = true,
                       Status = 0,
                       StatusText = "ok"
                    });
                }

                return Unauthorized(new UmiResponse
                {
                    Success = false,
                    Status = 401,
                    StatusText = "Invalid username or password"
                });
            }
            catch (Exception ex)
            {

                Logger.LogError(ex, "Error in Login Method");

                return Unauthorized(new UmiResponse
                {
                    Success = false,
                    Status = 401,
                    StatusText = "Invalid username or password"
                });
            }

        }

        [AllowAnonymous]
        [HttpGet("sectionNodes")]
        public async Task<IActionResult> GetSectionNodes()
        {
            return HandleResult(await Mediator.Send(new Sections.Query()));

        }

        [AllowAnonymous]
        [HttpGet("employeeNodes")]
        public async Task<IActionResult> GetEmployeeNodes(string division)
        {
            return HandleResult(await Mediator.Send(new Employees.Query { 
                Division = division
            }));

        }

        [AllowAnonymous]
        [HttpGet("employeeByDept")]
        public async Task<IActionResult> GetEmployeeByDept(string dept)
        {
            return HandleResult(await Mediator.Send(new Employees.QueryDept
            {
                Dept = dept
            }));

        }

        [AllowAnonymous]
        [HttpPost("loginByAp")]
        public async Task<ActionResult<UserDto>> LoginByAp(LoginDto login)
        {

            try
            {
                var user = await UserManager.Users.FirstOrDefaultAsync(a => a.EmpId == login.Username);

                if (user == null)
                {
                    Logger.LogInformation("User first loggin, start initiating ...({user})", login.Username);

                    var res = await Mediator.Send(new Detail.Query
                    {
                        EmpId = login.Username
                    });

                    if (res.IsSuccess)
                    {
                        user = res.Value;
                        await UserManager.AddToRoleAsync(user, "User");

                        Logger.LogInformation("User init successfully. ({0})", login.Username);
                    }
                    else
                    {
                        Logger.LogWarning("User init failed - {res}", res);
                        return Unauthorized();
                    }

                }

                Logger.LogInformation("User logged in successfully. ({0})", login.Username);

                await SetRefreshToken(user);

                return await CreateUserObject(user);

            }
            catch (Exception ex)
            {

                Logger.LogError(ex, "Error in Login Method");

                return Unauthorized();
            }

        }

        [Authorize]
        [HttpGet("currentUser")]
        public async Task<ActionResult<UserDto>> GetCurrentUser()
        {
            var userId = User.FindFirstValue(ClaimTypes.Name);

            if (userId != null)
            {
                var user = await UserManager.Users
                    .FirstOrDefaultAsync(u => u.UserName == User.FindFirstValue(ClaimTypes.Name));

                await SetRefreshToken(user);
                return Ok(new UmiResponse
                {
                    Data = await CreateUserObject(user),
                    Success = true,
                    Status = 0,
                    StatusText = "ok"
                });
            }
            else
            {
                return NotFound();
            }
        }

        [Authorize]
        [HttpPost("refreshToken")]
        public async Task<ActionResult<UserDto>> RefreshToken()
        {
            var refreshToken = Request.Cookies["refreshToken"];

            var user = await UserManager.Users.Include(r => r.RefreshTokens)
                .FirstOrDefaultAsync(x => x.UserName == User.FindFirstValue(ClaimTypes.Name));

            if (user == null) return Unauthorized();

            var oldToken = user.RefreshTokens.SingleOrDefault(x => x.Token == refreshToken);

            if (oldToken == null || !oldToken.IsActive) return Unauthorized();

            return Ok(new UmiResponse
            {
                Data = await CreateUserObject(user),
                Success = true
            });
        }

        [Authorize("IsAdmin")]
        [HttpGet("assignToRole/{role}/{user}")]
        public async Task<ActionResult<string>> AssignUserRole(string role, string user)
        {
            try
            {
                var res = await Mediator.Send(new Detail.Query
                {
                    EmpId = user
                });

                if (res.IsSuccess)
                {
                    var myUser = res.Value;

                    await UserManager.AddToRoleAsync(myUser, role);

                    Logger.LogInformation("User role assigned successfully. ({0} - {1})", user, role);

                    return "Success";
                }
                else
                {
                    Logger.LogInformation("User role assign failed. ({0} - {1}, {2})", user, role, res);

                    return "failed";
                }


            }
            catch (Exception ex)
            {
                Logger.LogError("Error when assigning user to role. {0}, {1}", user, ex.Message);

                return Unauthorized();
            }
        }

        [Authorize("IsAdmin")]
        [HttpGet("adminlist")]
        public async Task<ActionResult<List<AppUser>>> GetAdminUsers()
        {
            var admins = await Mediator.Send(new AdminList.Query { });

            return HandleResult<List<AppUser>>(admins);
        }

        [Authorize("IsAdmin")]
        [HttpPost("AddAdmin")]
        public async Task<ActionResult<string>> AssignAdminUser(LoginDto login)
        {
            try
            {
                var user = await UserManager.Users.FirstOrDefaultAsync(u => u.EmpId == login.Username);

                if (user == null)
                {
                    Logger.LogInformation("User not found, start initiating ...({user})", login.Username);

                    var res = await Mediator.Send(new Detail.Query
                    {
                        EmpId = login.Username
                    });

                    if (res.IsSuccess)
                    {
                        user = res.Value;
                        await UserManager.AddToRoleAsync(user, "User");

                        await UserManager.AddToRoleAsync(user, "Admin");

                        Logger.LogInformation("User init successfully. ({0})", login.Username);
                    }
                    else
                    {
                        Logger.LogWarning("User init failed - {res}", res);
                        return Unauthorized();
                    }

                }
                else
                {
                    var roles = await UserManager.GetRolesAsync(user);

                    if (!roles.Contains("Admin"))
                    {
                        await UserManager.AddToRoleAsync(user, "Admin");
                    }
                }

                return Ok("Success");

            }
            catch (Exception ex)
            {
                Logger.LogError("Error when assigning admin user. {0}", ex.Message);

                return Unauthorized();
            }
        }

        [Authorize("IsAdmin")]
        [HttpPost("DelAdmin")]
        public async Task<ActionResult<string>> DeleteAdminUser(LoginDto login)
        {
            try
            {
                var user = await UserManager.Users.FirstOrDefaultAsync(u => u.EmpId == login.Username);

                if (user == null)
                {
                    return NotFound();
                }

                var roles = await UserManager.GetRolesAsync(user);

                if (roles.Contains("Admin"))
                {
                    await UserManager.RemoveFromRoleAsync(user, "Admin");
                }

                return Ok("Success");
            }
            catch (Exception ex)
            {
                Logger.LogError("Error when removing admin user. {0}", ex.Message);

                return Unauthorized();
            }
        }

        [Authorize("IsAdmin")]
        [HttpGet("removeUserRole/{role}/{user}")]
        public async Task<ActionResult<string>> RemoveUserRole(string role, string user)
        {
            try
            {
                var res = await Mediator.Send(new Detail.Query
                {
                    EmpId = user
                });

                if (res.IsSuccess)
                {
                    var myUser = res.Value;

                    await UserManager.RemoveFromRoleAsync(myUser, role);

                    Logger.LogInformation("User role removed successfully. ({0} - {1})", user, role);

                    return Ok(new UmiResponse
                    {
                        Success = true
                    });
                }
                else
                {
                    Logger.LogInformation("User role remove failed. ({0} - {1}, {2})", user, role, res);

                    return  "failed";
                }


            }
            catch (Exception ex)
            {
                Logger.LogError("Error when removing user to role. {0}, {1}", user, ex.Message);

                return Unauthorized();
            }
        }

        [Authorize("IsAdmin")]
        [HttpPost("addRole")]
        public async Task<ActionResult> AddUserRole(string roleName)
        {
            if (String.IsNullOrEmpty(roleName)) return BadRequest();

            if (await RoleManager.RoleExistsAsync(roleName))
            {
                return BadRequest("Role is already exists.");
            }

            var result = await RoleManager.CreateAsync(new AppRole { Name = roleName });

            Logger.LogDebug("Create role {0}: {1}", roleName, result.Succeeded);

            return NoContent();
        }

        [HttpPost("AddUserTxn")]
        public async Task<IActionResult> AddUserTxn(UserTxn userTxn)
        {
            Repository.UserTxn.Create(userTxn);

            var result = await Repository.UserTxn.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to create user txn");
            }

            return NoContent();


        }

        private async Task<ActionResult<UserDto>> CreateUserObject(AppUser user)
        {
            if (user.DefaultProject == null)
            {
                var defaultProj = await Repository.Project.GetByConditionAsync(p => p.IsDefault);

                if (defaultProj != null && defaultProj.Count() > 0)
                {
                    user.DefaultProject = defaultProj.First().Name;
                }
            }

            return new UserDto
            {
                Name = user.Name,
                EmpId = user.EmpId,
                UserId = user.EmpId,
                Token = TokenService.CreateToken(user),
                Dept = user.Dept,
                Section = user.Section,
                Role = user.GetRoles(Context),
                Roles = user.GetRolesArray(Context),
                DefaultProject = user.DefaultProject
            };
        }


        private async Task SetRefreshToken(AppUser user)
        {
            var refreshToken = TokenService.GenerateRefreshToken();

            user.RefreshTokens.Add(refreshToken);
            await UserManager.UpdateAsync(user);

            var cookieOptions = new CookieOptions
            {
                HttpOnly = true,
                Expires = DateTime.UtcNow.AddDays(7)
            };

            Response.Cookies.Append("refreshToken", refreshToken.Token, cookieOptions);
        }
    }
}
