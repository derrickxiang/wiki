﻿using AutoMapper;
using FabS3.API.DTOs;
using FabS3.API.Helpers;
using FabS3.Data.Services;
using FabS3.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace FabS3.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ToolStageController : ControllerBase
    {
        public ToolStageController(
        IRepositoryWrapper repositoryWrapper,
           IMapper mapper,
            ILogger<ToolStageController> logger
            )
        {
            Repository = repositoryWrapper;
            Mapper = mapper;
            Logger = logger;
        }

        public IMapper Mapper { get; }
        public IRepositoryWrapper Repository { get; set; }
        public ILogger<ToolStageController> Logger { get; set; }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ToolStage>>> GetToolStagesAsync()
        {
            var data = await Repository.ToolStage.GetToolStagesAsync();

            var result = Mapper.Map<ToolStageDto[]>(data);

            return Ok(new UmiResponse
            {
                Data = result,
                Success = true,
                Status = 200
            });
        }

        [HttpGet("{toolStageId}", Name = nameof(GetToolStageAsync))]
        public async Task<ActionResult<ToolStage>> GetToolStageAsync(Guid toolStageId)
        {
            var stage = await Repository.ToolStage.GetByIdAsync(toolStageId);

            if (stage == null)
            {
                return NotFound();
            }

            return stage;
        }

        [HttpPost]
        public async Task<IActionResult> AddToolStageAsync(
            ToolStageForCreationDto stageToCreate
            )
        {
            if (stageToCreate == null) return BadRequest();

            var stage = Mapper.Map<ToolStage>(stageToCreate);

            var existStage = await Repository.ToolStage.GetByConditionAsync(s => s.ToolId == stage.ToolId && s.StageId == stage.StageId);

            if (existStage != null && existStage.Count() > 0)
            {
                var stageToUpdate = existStage.First();
                
                Mapper.Map<ToolStage, ToolStage>(stage, stageToUpdate);

                //Repository.ToolStage.Update(stageToUpdate);

                return CreatedAtRoute(
                    nameof(UpdateToolStageAsync),
                    new
                    {
                        stageToUpdate = stageToUpdate
                    }, stageToUpdate);
            }
            else
            {
                Repository.ToolStage.Create(stage);
            }


            var result = await Repository.ToolStage.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to create ToolStage.");
            }

            return Ok();
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteToolStageAsync([FromBody] JsonElement key)
        {
            var stageId = key.GetProperty("stageId").ToString();
            var stage = await Repository.ToolStage.GetByIdAsync(Guid.Parse(stageId));

            if (stage == null)
            {
                return BadRequest();
            }

            Repository.ToolStage.Delete(stage);

            var result = await Repository.ToolStage.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to remove stage ", stage);
                return BadRequest();
            }

            return NoContent();

        }

        [HttpPut(Name =nameof(UpdateToolStageAsync))]
        public async Task<IActionResult> UpdateToolStageAsync(ToolStage stageToUpdate)
        {
            var stage = await Repository.ToolStage.GetByIdAsync(stageToUpdate.Id);

            if (stage == null)
            {
                return BadRequest();
            }

            Mapper.Map<ToolStage, ToolStage>(stageToUpdate, stage);

            Repository.ToolStage.Update(stage);

            var result = await Repository.ToolStage.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to update tool stage ", stage);
                return BadRequest();
            }

            return NoContent();

        }
    }
}
