﻿using AutoMapper;
using FabS3.API.Helpers;
using FabS3.Data.Services;
using FabS3.Domain;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace FabS3.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StageController : ControllerBase
    {
        public StageController(
            IRepositoryWrapper repositoryWrapper,
            IMapper mapper,
            ILogger<StageController> logger
            )
        {
            Repository = repositoryWrapper;
            Mapper = mapper;
            Logger = logger;
        }

        public IMapper Mapper { get; }
        public IRepositoryWrapper Repository { get; set; }
        public ILogger<StageController> Logger { get; set; }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Stage>>> GetStagesAsync(
            [FromQuery] StageParam stageParam)
        {
            var stages = await Repository.Stage.GetByConditionAsync(m => 
                                (String.IsNullOrEmpty(stageParam.Name) || m.Name.ToLower() == stageParam.Name.ToLower())
                                && (String.IsNullOrEmpty(stageParam.Category) || m.Category.ToLower() == stageParam.Category.ToLower())
                                && (String.IsNullOrEmpty(stageParam.Tier.ToString()) || stageParam.Tier == -1 || m.Tier == stageParam.Tier));

            //if (!String.IsNullOrWhiteSpace(stageParam.Name))
            //{
            //    stages = stages.Where(m => m.Name.ToLower() == stageParam.Name.ToLower());
            //}

            //if (stageParam.Tier > -1)
            //{
            //    stages = stages.Where(m => m.Tier == stageParam.Tier);
            //}

            var stageList = await PagedList<Stage>.ToPagedList(stages.AsQueryable<Stage>(),
                stageParam.Current,
                stageParam.PageSize);

            return Ok(new UmiResponse
            {
                Data = stageList.OrderBy(s => s.Name).ToList(),
                Success = true,
                Status = 200
            });

        }

        [HttpGet("{stageId}", Name = nameof(GetStageAsync))]
        public async Task<ActionResult<Stage>> GetStageAsync(Guid stageId)
        {
            var stage = await Repository.Stage.GetByIdAsync(stageId);

            if (stage == null)
            {
                return NotFound();
            }

            return stage;
        }

        [HttpPost]
        public async Task<IActionResult> AddStageAsync(
            Stage stageToCreate
            )
        {
            var stage = Mapper.Map<Stage>(stageToCreate);

            Repository.Stage.Create(stage);

            var result = await Repository.Stage.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to create Stage.");
            }

            return CreatedAtRoute(
                nameof(GetStageAsync),
                new
                {
                    stageId = stage.Id
                }, stage);
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteStageAsync([FromBody] JsonElement key)
        {
            var stageId = key.GetProperty("stageId").ToString();
            var stage = await Repository.Stage.GetByIdAsync(Guid.Parse(stageId));

            if (stage == null)
            {
                return BadRequest();
            }

            Repository.Stage.Delete(stage);

            var result = await Repository.Stage.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to remove stage ", stage);
                return BadRequest();
            }

            return NoContent();

        }

        [HttpPut]
        public async Task<IActionResult> UpdateStageAsync(Stage stageToUpdate)
        {
            var stage = await Repository.Stage.GetByIdAsync(stageToUpdate.Id);

            if (stage == null)
            {
                return BadRequest();
            }

            Mapper.Map<Stage, Stage>(stageToUpdate, stage);

            Repository.Stage.Update(stage);

            var result = await Repository.Stage.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to update stage ", stage);
                return BadRequest();
            }

            return NoContent();

        }
    }
}
