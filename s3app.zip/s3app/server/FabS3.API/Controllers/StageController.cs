﻿using AutoMapper;
using FabS3.API.Helpers;
using FabS3.Data.Services;
using FabS3.Domain;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace FabS3.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StageController : ControllerBase
    {
        public StageController(
            IRepositoryWrapper repositoryWrapper,
            IMapper mapper,
            ILogger<StageController> logger
            )
        {
            Repository = repositoryWrapper;
            Mapper = mapper;
            Logger = logger;
        }

        public IMapper Mapper { get; }
        public IRepositoryWrapper Repository { get; set; }
        public ILogger<StageController> Logger { get; set; }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Stage>>> GetStagesAsync(
            [FromQuery] StageParam stageParam)
        {
            var stages = await Repository.Stage.GetByConditionAsync(m => 
                                (String.IsNullOrEmpty(stageParam.Name) || m.Name.ToLower() == stageParam.Name.ToLower())
                                && (String.IsNullOrEmpty(stageParam.Category) || m.Category.ToLower() == stageParam.Category.ToLower())
                                && (String.IsNullOrEmpty(stageParam.Tier.ToString()) || stageParam.Tier == -1 || m.Tier == stageParam.Tier));

            //if (!String.IsNullOrWhiteSpace(stageParam.Name))
            //{
            //    stages = stages.Where(m => m.Name.ToLower() == stageParam.Name.ToLower());
            //}

            //if (stageParam.Tier > -1)
            //{
            //    stages = stages.Where(m => m.Tier == stageParam.Tier);
            //}

            //var stageList = await PagedList<Stage>.ToPagedList(stages.AsQueryable<Stage>(),
            //    stageParam.Current,
            //    stageParam.PageSize);

            return Ok(new UmiResponse
            {
                Data = stages.OrderBy(s => s.Seq).ToList(),
                Success = true,
                Status = 200
            });

        }

        [HttpGet("{stageId}", Name = nameof(GetStageAsync))]
        public async Task<ActionResult<Stage>> GetStageAsync(Guid stageId)
        {
            var stage = await Repository.Stage.GetByIdAsync(stageId);

            if (stage == null)
            {
                return NotFound();
            }

            return stage;
        }

        [HttpPost]
        public async Task<IActionResult> AddStageAsync(
            Stage stageToCreate
            )
        {
            try
            {
                var stage = Mapper.Map<Stage>(stageToCreate);

                if (stage == null) return BadRequest();

                var existStage = await Repository.Stage.GetByConditionAsync(s => s.Name == stage.Name);

                if (existStage != null && existStage.Count() > 0)
                {
                    var oldStage = existStage.First();

                    Mapper.Map(stage, oldStage);

                    Repository.Stage.Update(oldStage);
                }
                else
                {
                    Repository.Stage.Create(stage);
                }


                var result = await Repository.Stage.SaveAsync();

                if (!result)
                {
                    Logger.LogError("Fail to create Stage.");
                }

                return CreatedAtRoute(
                    nameof(GetStageAsync),
                    new
                    {
                        stageId = stage.Id
                    }, stage);
            }
            catch(Exception ex)
            {
                Logger.LogError("Error when adding stage - ", ex);
                return BadRequest();
            }
            
        }

        [HttpPost("batch")]
        public async Task<IActionResult> AddStagesAsync(
            Stage[] stagesToCreate
            )
        {
            try
            {
                foreach(Stage stageToCreate in stagesToCreate)
                {
                    var stage = Mapper.Map<Stage>(stageToCreate);

                    if (stage == null) return BadRequest();

                    var existStage = await Repository.Stage.GetByConditionAsync(s => s.Name == stage.Name);

                    if (existStage != null && existStage.Count() > 0)
                    {
                        var oldStage = existStage.First();

                        //Mapper.Map(stage, oldStage);
                        oldStage.Category = String.IsNullOrEmpty(stage.Category) ? oldStage.Category : stage.Category;
                        oldStage.CreateBy = stage.CreateBy;
                        oldStage.CreateAt = stage.CreateAt;
                        oldStage.Description = stage.Name;
                        oldStage.Owner = stage.Owner;
                        oldStage.Seq = stage.Seq;
                        oldStage.SignOff = stage.SignOff;
                        oldStage.Tier = stage.Tier;
                        oldStage.BookTimeSlot = stage.BookTimeSlot;

                        Repository.Stage.Update(oldStage);
                    }
                    else
                    {
                        Repository.Stage.Create(stage);
                    }


                    var result = await Repository.Stage.SaveAsync();

                    if (!result)
                    {
                        Logger.LogError("Fail to create Stage.");
                    }
                }
                

                return Ok();
            }
            catch (Exception ex)
            {
                Logger.LogError("Error when adding stage - ", ex);
                return BadRequest();
            }

        }

        [HttpDelete]
        public async Task<IActionResult> DeleteStageAsync([FromBody] JsonElement key)
        {
            var stageId = key.GetProperty("stageId").ToString();
            var stage = await Repository.Stage.GetByIdAsync(Guid.Parse(stageId));

            if (stage == null)
            {
                return BadRequest();
            }

            Repository.Stage.Delete(stage);

            var result = await Repository.Stage.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to remove stage ", stage);
                return BadRequest();
            }

            return NoContent();

        }

        [HttpPut]
        public async Task<IActionResult> UpdateStageAsync(Stage stageToUpdate)
        {
            var stage = await Repository.Stage.GetByIdAsync(stageToUpdate.Id);

            if (stage == null)
            {
                return BadRequest();
            }

            Mapper.Map<Stage, Stage>(stageToUpdate, stage);

            Repository.Stage.Update(stage);

            var result = await Repository.Stage.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to update stage ", stage);
                return BadRequest();
            }

            return NoContent();

        }
    }
}
