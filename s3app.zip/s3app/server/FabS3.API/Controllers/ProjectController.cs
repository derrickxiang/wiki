﻿using AutoMapper;
using FabS3.API.Helpers;
using FabS3.Data.Services;
using FabS3.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace FabS3.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectController : ControllerBase
    {
        public ProjectController(
            IRepositoryWrapper repositoryWrapper,
            IMapper mapper,
            ILogger<ProjectController> logger
            )
        {
            Repository = repositoryWrapper;
            Mapper = mapper;
            Logger = logger;
        }

        public IMapper Mapper { get; }
        public IRepositoryWrapper Repository { get; set; }
        public ILogger<ProjectController> Logger { get; set; }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Project>>> GetProjectsAsync()
        {
            var projects = await Repository.Project.GetAllAsync();

            return Ok(new UmiResponse
            {
                Data = projects.OrderBy(s => s.Name).ToList(),
                Success = true,
                Status = 200
            });
        }

        [HttpGet("{projectId}", Name = nameof(GetProjectAsync))]
        public async Task<ActionResult<Project>> GetProjectAsync(Guid projectId)
        {
            var project = await Repository.Project.GetByIdAsync(projectId);

            if (project == null)
            {
                return NotFound();
            }

            return project;
        }

        [HttpPost]
        public async Task<IActionResult> AddProjectAsync(
            Project projectToCreate
            )
        {
            var project = Mapper.Map<Project>(projectToCreate);

            Repository.Project.Create(project);

            var result = await Repository.Project.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to create Project.");
            }

            return CreatedAtRoute(
                nameof(GetProjectAsync),
                new
                {
                    projectId = project.Id
                }, project);
        }


        [HttpDelete]
        public async Task<IActionResult> DeleteProjectAsync([FromBody] JsonElement key)
        {
           
            //Dictionary<string, string> keys = JsonSerializer.Deserialize<Dictionary<string, string>>(key);

            //if (keys["projectId"].Length == 0) return BadRequest();

            var projectId = key.GetProperty("projectId").ToString();

            var project = await Repository.Project.GetByIdAsync(Guid.Parse(projectId));

            if (project == null)
            {
                return BadRequest();
            }

            Repository.Project.Delete(project);

            var result = await Repository.Project.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to remove project ", project);
                return BadRequest();
            }

            return NoContent();

        }

        [HttpPost("default")]
        public async Task<IActionResult> SetProjectDefault([FromBody] JsonElement key)
        {
            var projectId = key.GetProperty("projectId").ToString();

            var project = await Repository.Project.GetByIdAsync(Guid.Parse(projectId));

            if (project == null)
            {
                return BadRequest();
            }

            Repository.Project.ClearProjectDefault();

            project.IsDefault = true;

            Repository.Project.Update(project);

            var result = await Repository.Project.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to update project ", project);
                return BadRequest();
            }

            return CreatedAtRoute(
               nameof(GetProjectAsync),
               new
               {
                   projectId = project.Id
               }, project);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateProjectAsync(Project projectToUpdate)
        {
            var project = await Repository.Project.GetByIdAsync(projectToUpdate.Id);

            if (project == null)
            {
                return BadRequest();
            }

            Mapper.Map<Project, Project>(projectToUpdate, project);

            if (project.IsDefault)
            {
                Repository.Project.ClearProjectDefault();
            }

            Repository.Project.Update(project);

            var result = await Repository.Project.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to update project ", project);
                return BadRequest();
            }

            return CreatedAtRoute(
               nameof(GetProjectAsync),
               new
               {
                   projectId = project.Id
               }, project);

        }
    }
}
