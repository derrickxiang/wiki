﻿using AutoMapper;
using FabS3.API.DTOs;
using FabS3.API.Helpers;
using FabS3.Data.Services;
using FabS3.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace FabS3.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ToolController : ControllerBase
    {
        public ToolController(
            IRepositoryWrapper repositoryWrapper,
            IMapper mapper,
            ILogger<ToolController> logger
            )
        {
            Repository = repositoryWrapper;
            Mapper = mapper;
            Logger = logger;
        }

        public IMapper Mapper { get;  }
        public IRepositoryWrapper Repository { get; set; }
        public ILogger<ToolController> Logger { get; set; }

        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult<UmiResponse>> GetToolsAsync(string dept)
        {
            var tools = (await Repository.Tool.GetAllAsync());

            if (!String.IsNullOrEmpty(dept))
            {
                tools = tools.Where(t => t.Area == dept);
            }

            return new UmiResponse
            {
                Data = tools.OrderBy(t => t.EqpId).ToList(),
                Success = true
            };
        }

        [HttpGet("{toolId}", Name = nameof(GetToolAsync))]
        public async Task<ActionResult<ToolDto>> GetToolAsync(Guid toolId)
        {
            var tool = await Repository.Tool.GetByIdAsync(toolId);

            if (tool == null)
            {
                return NotFound();
            }

            var toolDto = Mapper.Map<ToolDto>(tool);

            if (toolDto.ProjectId != null)
            {
                var stage = await Repository.Stage.GetByIdAsync(Guid.Parse(toolDto.ProjectId));

                if (stage != null)
                {
                    toolDto.Project = stage.Name;
                }
            }

            return toolDto;
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteToolAsync([FromBody] JsonElement key)
        {

            var toolId = key.GetProperty("toolId").ToString();
            var tool = await Repository.Tool.GetByIdAsync(Guid.Parse(toolId));

            if (tool == null)
            {
                return BadRequest();
            }

            Repository.Tool.Delete(tool);

            var result = await Repository.Tool.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to remove tool ", tool);
                return BadRequest();
            }

            return NoContent();

        }

        [HttpPut]
        public async Task<IActionResult> UpdateToolAsync(ToolDto toolToUpdate)
        {
            var tool = await Repository.Tool.GetByIdAsync(Guid.Parse(toolToUpdate.Id));

            if (tool == null)
            {
                return BadRequest();
            }

            Mapper.Map<ToolDto, Tool>(toolToUpdate, tool);

            Repository.Tool.Update(tool);

            var result = await Repository.Tool.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to update tool ", tool);
                return BadRequest();
            }

            return NoContent();

        }

        [HttpPost]
        public async Task<IActionResult> AddToolAsync(
            ToolForCreationDto toolForCreationDto
            )
        {
            var tool = Mapper.Map<Tool>(toolForCreationDto);

            var checkExistTool = await Repository.Tool.GetByConditionAsync(s => s.ProjectId == tool.ProjectId && s.EqpId == tool.EqpId);

            if (checkExistTool != null && checkExistTool.Count() > 0)
            {
                //var existTool = checkExistTool.First();

                //return CreatedAtRoute(
                //nameof(GetToolAsync),
                //new
                //{
                //    toolId = existTool.Id
                //}, existTool);

                return BadRequest("Tool with same EQPID already exists");
            }

            Repository.Tool.Create(tool);

            var result = await Repository.Tool.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to create Tool.");
            }

            // init tool stages
            Repository.ToolStage.InitToolStagesAsync(tool.Id);

            var toolDto = Mapper.Map<ToolDto>(tool);

            return CreatedAtRoute(
                nameof(GetToolAsync),
                new
                {
                    toolId = Guid.Parse(toolDto.Id)
                }, toolDto);
        }

    }
}
