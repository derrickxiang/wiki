﻿using AutoMapper;
using FabS3.API.DTOs;
using FabS3.API.Extensions;
using FabS3.API.Helpers;
using FabS3.Data;
using FabS3.Data.Services;
using FabS3.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace FabS3.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ToolController : ControllerBase
    {
        public ToolController(
            IRepositoryWrapper repositoryWrapper,
            IMapper mapper,
            ILogger<ToolController> logger,
            S3Context context
            )
        {
            Repository = repositoryWrapper;
            Mapper = mapper;
            Logger = logger;
            Context = context;
        }

        public IMapper Mapper { get;  }
        public IRepositoryWrapper Repository { get; set; }
        public ILogger<ToolController> Logger { get; set; }
        public S3Context Context { get; set; }

        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult<UmiResponse>> GetToolsAsync(
            string project,
            string dept,
            string section,
            string keyword,
            int current,
            int pageSize)
        {
            var tools = await Repository.Tool.GetByConditionAsync(t =>
                (String.IsNullOrEmpty(project) || (t.Project.Name == project))
                && (String.IsNullOrEmpty(dept) || (t.Area == dept))
                && (String.IsNullOrEmpty(section) || (t.Section == section))
                && (String.IsNullOrEmpty(keyword) || (t.EqpId.ToUpper().Contains(keyword.ToUpper()))));

            List<ToolDto> toolDtos = new List<ToolDto>();

            foreach(Tool tool in tools)
            {
                ToolDto toolDto = new ToolDto();

                Mapper.Map(tool, toolDto);

                var moveInStage = await Repository.ToolStage.GetByConditionAsync(s => s.ToolId == tool.Id && s.Stage.Name == "Move In");
                var eeStage = await Repository.ToolStage.GetByConditionAsync(s => s.ToolId == tool.Id && s.Stage.Name == "EE Handover");
                var pilotStage = await Repository.ToolStage.GetByConditionAsync(s => s.ToolId == tool.Id && s.Stage.Name == "Pilot");
                var pcrbStage = await Repository.ToolStage.GetByConditionAsync(s => s.ToolId == tool.Id && s.Stage.Name == "PCRB Release");

                if (moveInStage != null && moveInStage.Count() > 0)
                {
                    toolDto.MoveInPlanDate = moveInStage.First().PlanDate.ToString("yyyy-MM-dd");
                    toolDto.MoveInReqDate = moveInStage.First().RequireDate.ToString("yyyy-MM-dd");
                }

                if (eeStage != null && eeStage.Count() > 0)
                {
                    toolDto.EEHandoverReqDate = eeStage.First().RequireDate.ToString("yyyy-MM-dd");
                }

                if (pilotStage != null && pilotStage.Count() > 0)
                {
                    toolDto.PilotReqDate = pilotStage.First().RequireDate.ToString("yyyy-MM-dd");
                }

                if (pcrbStage != null && pcrbStage.Count() > 0)
                {
                    toolDto.PcrbQualReqDate = pcrbStage.First().RequireDate.ToString("yyyy-MM-dd");
                }


                toolDtos.Add(toolDto);
            }
           // var toolList = await PagedList<Tool>.ToPagedList(tools.AsQueryable(), current, pageSize);

            return new UmiResponse
            {
                Data = toolDtos.OrderBy(t => t.EqpId).ToList(),
                Total = toolDtos.Count(),
                Success = true
            };
        }

        [HttpGet("{toolId}", Name = nameof(GetToolAsync))]
        public async Task<ActionResult<ToolDto>> GetToolAsync(Guid toolId)
        {
            var tool = await Repository.Tool.GetByIdAsync(toolId);

            if (tool == null)
            {
                return NotFound();
            }

            var toolDto = Mapper.Map<ToolDto>(tool);

            if (toolDto.ProjectId != null)
            {
                var stage = await Repository.Stage.GetByIdAsync(Guid.Parse(toolDto.ProjectId));

                if (stage != null)
                {
                    toolDto.Project = stage.Name;
                }
            }

            return toolDto;
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteToolAsync([FromBody] JsonElement key)
        {

            var toolId = key.GetProperty("toolId").ToString();
            var tool = await Repository.Tool.GetByIdAsync(Guid.Parse(toolId));

            if (tool == null)
            {
                return BadRequest();
            }

            Repository.Tool.Delete(tool);

            var result = await Repository.Tool.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to remove tool ", tool);
                return BadRequest();
            }

            return NoContent();

        }

        [HttpPut]
        public async Task<IActionResult> UpdateToolAsync(ToolDto toolToUpdate)
        {
            var tool = await Repository.Tool.GetByIdAsync(Guid.Parse(toolToUpdate.Id));

            if (tool == null)
            {
                return BadRequest();
            }

            Mapper.Map<ToolDto, Tool>(toolToUpdate, tool);

            Repository.Tool.Update(tool);

            var result = await Repository.Tool.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to update tool ", tool);
                return BadRequest();
            }

            return NoContent();

        }

        [HttpPost("nextstage")]
        public async Task<IActionResult> MoveToNextAsync([FromBody] JsonElement key)
        {

            var toolId = key.GetProperty("toolId").ToString();
            var user = key.GetProperty("user").ToString();

            if (String.IsNullOrEmpty(toolId))
            {
                return BadRequest("Invalid tool id");
            }

            var tool = await Repository.Tool.GetByIdAsync(Guid.Parse(toolId));

            if (tool == null)
            {
                return BadRequest("Not found");
            }

            var currentStage = await Repository.Stage.GetByConditionAsync(s => s.Name == tool.CurrentStage);

            if (currentStage != null && currentStage.Count() > 0)
            {
                var currentToolStage = await Repository.ToolStage.GetByConditionAsync(s => s.ToolId == tool.Id && s.StageId == currentStage.First().Id);
                if (currentToolStage != null && currentToolStage.Count() > 0)
                {
                    var toolStage = currentToolStage.First();

                    toolStage.ActualDate = DateTime.Now;
                    toolStage.Status = "Completed";
                    toolStage.CompleteChecklist = toolStage.TotalChecklist;
                    toolStage.UpdateAt = DateTime.Now;
                    toolStage.UpdateBy = user;

                    Repository.ToolStage.Update(toolStage);

                }

                var nextStage = await Repository.ToolStage.GetNextStageAsync(currentStage.First().Id);

                if (nextStage != null)
                {
                    tool.CurrentStage = nextStage.Name;
                }

                var nextToolStage = await Repository.ToolStage.GetByConditionAsync(s => s.ToolId == tool.Id && s.StageId == nextStage.Id);

                if (nextToolStage != null && nextToolStage.Count() > 0)
                {
                    var nextTS = nextToolStage.First();
                    nextTS.Status = "Processing";
                    nextTS.CompleteChecklist = 0;
                    nextTS.UpdateAt = DateTime.Now;
                    nextTS.UpdateBy = user;

                    Repository.ToolStage.Update(nextTS);
                }


                await Repository.ToolStage.SaveAsync();
            }

            

            return NoContent();

        }

        [HttpPost("batch")]
        public async Task<IActionResult> AddToolsAsync(ToolDto[] tools)
        {
            try
            {
                var allStages = await Repository.Stage.GetAllAsync();
                var firstStage = allStages.OrderBy(s => s.Seq).Take(1);

                foreach(ToolDto toolForCreationDto in tools)
                {
                    toolForCreationDto.CurrentStage = firstStage.FirstOrDefault().Name;

                    var tool = Mapper.Map<Tool>(toolForCreationDto);

                    var checkExistTool = await Repository.Tool.GetByConditionAsync(s => s.ProjectId == tool.ProjectId && s.EqpId == tool.EqpId);

                    if (checkExistTool != null && checkExistTool.Count() > 0)
                    {
                        tool = checkExistTool.First();

                        Mapper.Map<ToolDto, Tool>(toolForCreationDto, tool);

                        Repository.Tool.Update(tool);
                    } 
                    else
                    {

                        Repository.Tool.Create(tool);
                    }

                    var result = await Repository.Tool.SaveAsync();

                    if (!result)
                    {
                        Logger.LogError("Fail to create Tool.");
                        return BadRequest();
                    }

                    // init tool stages
                    //Repository.ToolStage.InitToolStagesAsync(tool.Id);
                    var existStages = await Repository.ToolStage.GetByConditionAsync(s => s.ToolId == tool.Id);

                    if (existStages != null && existStages.Count() > 0)
                    {
                        foreach(ToolStage toolStage in existStages)
                        {
                            Repository.ToolStage.Delete(toolStage);
                        }

                        await Repository.ToolStage.SaveAsync();
                    }

                    //var newStages = await Repository.Stage.GetByConditionAsync(s => !existStages.Where(e => e.StageId == s.Id).Any());
                    var newStages = await Repository.Stage.GetAllAsync();

                    if (newStages.Count() > 0)
                    {                        

                        foreach (Stage s in newStages)
                        {
                            var planDate = ToolDto.GetPropValue(toolForCreationDto, s.Name.Replace(" ", string.Empty).Replace("/SL", string.Empty) + "PlanDate");
                            var reqDate = ToolDto.GetPropValue(toolForCreationDto, s.Name.Replace(" ", string.Empty).Replace("/SL", string.Empty) + "ReqDate");
                            var leadTime = ToolDto.GetPropValue(toolForCreationDto, s.Name.Replace(" ", string.Empty).Replace("/SL", string.Empty) + "LT");

                            var newToolStage = new ToolStage
                            {
                                ToolId = tool.Id,
                                StageId = s.Id,
                                Status = "Init",
                                Owner = s.Owner,
                                ResponsibleParty = s.SignOff
                            };

                            if (planDate != null)
                            {
                                newToolStage.PlanDate = DateTime.ParseExact(planDate.ToString(), "yyyy/M/d", CultureInfo.InvariantCulture);
                                newToolStage.PlanDateBy = toolForCreationDto.CreateBy;
                            }

                            if (reqDate != null)
                            {
                                newToolStage.RequireDate = DateTime.ParseExact(reqDate.ToString(), "yyyy/M/d", CultureInfo.InvariantCulture);
                                newToolStage.RequireDateBy = toolForCreationDto.CreateBy;
                            }

                            if (leadTime != null)
                            {
                                newToolStage.LeadTime = float.Parse(leadTime.ToString());
                            }

                            Repository.ToolStage.Create(newToolStage);
                        }

                        await Repository.ToolStage.SaveAsync();
                    }

                   

                    // init the tool stage checklist
                    var existChks = await Repository.ToolChecklist.GetByConditionAsync(s => s.ToolId == tool.Id);

                    if (existChks != null && existChks.Count() > 0)
                    {
                        foreach(ToolChecklist chk in existChks)
                        {
                            Repository.ToolChecklist.Delete(chk);
                        }
                       
                        await Repository.ToolChecklist.SaveAsync();
                    }

                    var stages = await Repository.ToolStage.GetByConditionAsync(s => s.ToolId == tool.Id);

                    if (stages != null && stages.Count() > 0)
                    {
                        foreach (ToolStage stage in stages)
                        {
                            var checklists = await Repository.StageChecklist.GetByConditionAsync(s => s.StageId == stage.StageId);
                           
                            foreach (StageChecklist chk in checklists)
                            {
                                ToolChecklist tchk = new ToolChecklist();
                                tchk.ToolId = tool.Id;
                                tchk.StageId = stage.StageId;
                                tchk.Seq = chk.Seq;
                                tchk.Item = chk.Item;
                                tchk.InputType = chk.InputType;
                                tchk.Owner = chk.Owner;
                                tchk.ChecklistId = chk.ChecklistId;
                                tchk.TemplateId = chk.TemplateId;
                                tchk.TemplateVer = chk.TemplateVer;
                                tchk.TotalItems = checklists.Count();

                                Repository.ToolChecklist.Create(tchk);
                                                                
                            }

                            await Repository.ToolChecklist.SaveAsync();

                            // update tool stage 
                            stage.TotalChecklist = checklists.Count();
                            stage.CompleteChecklist = 0;

                            Repository.ToolStage.Update(stage);

                            await Repository.ToolStage.SaveAsync();

                            // update checklist items
                            var chkForms = await Repository.ToolChecklist.GetByConditionAsync(t => t.ToolId == tool.Id && t.InputType == "Checklist");

                            if (chkForms != null && chkForms.Count() > 0)
                            {
                                foreach(ToolChecklist chkForm in chkForms)
                                {
                                    if (!String.IsNullOrEmpty(chkForm.ChecklistId))
                                    {
                                        // check exists
                                        var exisItems = await Repository.ToolChecklistItem.GetByConditionAsync(c => c.ToolChecklistId == chkForm.Id);

                                        if (exisItems != null && exisItems.Count() > 0)
                                        {
                                            foreach(var itemToDelete in exisItems)
                                            {
                                                Repository.ToolChecklistItem.Delete(itemToDelete);
                                            }

                                            await Repository.ToolChecklistItem.SaveAsync();
                                        }

                                        var tempItems = await Repository.ChecklistItem.GetByConditionAsync(c => c.ChecklistId == chkForm.ChecklistId);

                                        if (tempItems != null && tempItems.Count() > 0)
                                        {
                                            foreach(ChecklistItem item in tempItems)
                                            {
                                                ToolChecklistItem tItem = new ToolChecklistItem();

                                                tItem.ToolChecklistId = chkForm.Id;
                                                tItem.ChecklistItemId = item.Id;

                                                Repository.ToolChecklistItem.Create(tItem);
                                            }

                                            await Repository.ToolChecklistItem.SaveAsync();
                                        }
                                    }
                                }
                            }
                        }

                    }


                    //await tool.AddStages(Context);
                    //tool.AddChecklist(Context);
                }

                return Ok();
            }
            catch (Exception ex)
            {
                Logger.LogError("Error when adding tools - ", ex);
                return BadRequest();
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddToolAsync(
            ToolForCreationDto toolForCreationDto
            )
        {
            var tool = Mapper.Map<Tool>(toolForCreationDto);

            var checkExistTool = await Repository.Tool.GetByConditionAsync(s => s.ProjectId == tool.ProjectId && s.EqpId == tool.EqpId);

            if (checkExistTool != null && checkExistTool.Count() > 0)
            {
                //var existTool = checkExistTool.First();

                //return CreatedAtRoute(
                //nameof(GetToolAsync),
                //new
                //{
                //    toolId = existTool.Id
                //}, existTool);

                return BadRequest("Tool with same EQPID already exists");
            }

            Repository.Tool.Create(tool);

            var result = await Repository.Tool.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to create Tool.");
            }

            // init tool stages
            //Repository.ToolStage.InitToolStagesAsync(tool.Id);
            tool.AddStages(Context);

            tool.AddChecklist(Context);

            var toolDto = Mapper.Map<ToolDto>(tool);

            return CreatedAtRoute(
                nameof(GetToolAsync),
                new
                {
                    toolId = Guid.Parse(toolDto.Id)
                }, toolDto);
        }

        

    }
}
