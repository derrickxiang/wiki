﻿using AutoMapper;
using FabS3.Data.Services;
using FabS3.Domain;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FabS3.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChangeController : ControllerBase
    {
        public ChangeController(
            IRepositoryWrapper repositoryWrapper,
            IMapper mapper,
            ILogger<ChangeController> logger
            )
        {
            Repository = repositoryWrapper;
            Mapper = mapper;
            Logger = logger;
        }

        public IMapper Mapper { get; }
        public IRepositoryWrapper Repository { get; set; }
        public ILogger<ChangeController> Logger { get; set; }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Change>>> GetChangesAsync()
        {
            var projects = await Repository.Change.GetAllAsync();

            return projects.OrderBy(s => s.ChangeDate).ToList();
        }

        [HttpGet("{projectId}", Name = nameof(GetChangeAsync))]
        public async Task<ActionResult<Change>> GetChangeAsync(Guid projectId)
        {
            var project = await Repository.Change.GetByIdAsync(projectId);

            if (project == null)
            {
                return NotFound();
            }

            return project;
        }

        [HttpPost]
        public async Task<IActionResult> AddChangeAsync(
            Change projectToCreate
            )
        {
            var project = Mapper.Map<Change>(projectToCreate);

            Repository.Change.Create(project);

            var result = await Repository.Change.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to create Change.");
            }

            return CreatedAtRoute(
                nameof(GetChangeAsync),
                new
                {
                    projectId = project.Id
                }, project);
        }


        [HttpDelete("{projectId}")]
        public async Task<IActionResult> DeleteChangeAsync(Guid projectId)
        {
            var project = await Repository.Change.GetByIdAsync(projectId);

            if (project == null)
            {
                return BadRequest();
            }

            Repository.Change.Delete(project);

            var result = await Repository.Change.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to remove project ", project);
                return BadRequest();
            }

            return NoContent();

        }

        [HttpPut]
        public async Task<IActionResult> UpdateChangeAsync(Change projectToUpdate)
        {
            var project = await Repository.Change.GetByIdAsync(projectToUpdate.Id);

            if (project == null)
            {
                return BadRequest();
            }

            Mapper.Map<Change, Change>(projectToUpdate, project);

            Repository.Change.Update(project);

            var result = await Repository.Change.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to update project ", project);
                return BadRequest();
            }

            return NoContent();

        }
    }
}
