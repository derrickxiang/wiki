﻿using ExcelDataReader;
using FabS3.API.Helpers;
using FabS3.Domain;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace FabS3.API.Controllers
{
    public class FileController : BaseApiController
    {
        public FileController(
            IConfiguration config,
            ILogger<FileController> logger
            )
        {
            Config = config;
            Logger = logger;
        }

        IConfiguration Config { get; }
        ILogger Logger { get; }

        IExcelDataReader reader;

        [HttpPost("excelImport")]
        [DisableRequestSizeLimit]
        public async Task<ActionResult<UmiResponse>> ImportExcelAsync()
        {
            try
            {
                var formCollection = await Request.ReadFormAsync();
                var files = formCollection.Files.ToList();
                //// var fileCreateds = await _fileService.UploadSharedFile(files, ClaimsPrincipalExtensions.GetUserId<int>(User));
                //file = files[0];

                // Check the File is received

                if (files == null )
                    throw new Exception("File is Not Received...");

                var tmpFolder = Config["FileSettings:ImportFileFolder"];

                if (!Directory.Exists(tmpFolder))
                {
                    Directory.CreateDirectory(tmpFolder);
                }


                List<ChecklistItem> items = new List<ChecklistItem>();

                foreach ( var file in files)
                {
                    // MAke sure that only Excel file is used 
                    string dataFileName = Path.GetFileName(file.FileName);

                    string extension = Path.GetExtension(dataFileName);

                    string[] allowedExtsnions = new string[] { ".xls", ".xlsx" };

                    if (!allowedExtsnions.Contains(extension))
                        throw new Exception("Sorry! This file is not allowed.");

                    // Make a Copy of the Posted File from the Received HTTP Request
                    string saveToPath = Path.Combine(tmpFolder, dataFileName);

                    using (FileStream stream = new FileStream(saveToPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }

                    // USe this to handle Encodeing differences in .NET Core
                    System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

                    // read the excel file
                    using (var stream = new FileStream(saveToPath, FileMode.Open))
                    {
                        if (extension == ".xls")
                            reader = ExcelReaderFactory.CreateBinaryReader(stream);
                        else
                            reader = ExcelReaderFactory.CreateOpenXmlReader(stream);

                        DataSet ds = new DataSet();
                        ds = reader.AsDataSet();
                        reader.Close();

                        if (ds.Tables.Count > 0)
                        {
                            DataTable itemTable = ds.Tables[0];

                            for (int i = 0; i < itemTable.Rows.Count; i++)
                            {                                
                                DataRow row = itemTable.Rows[i];
                                if (row[0].ToString() == "N") continue;

                                ChecklistItem item = new ChecklistItem();

                                item.Seq = float.Parse(row[0].ToString());
                                item.Category = row[1].ToString();
                                item.SubSeq = float.Parse(row[2].ToString());
                                item.SubCategory = row[3].ToString();
                                item.InputType = row[4].ToString();
                                item.MaxLength = Int32.Parse(row[5].ToString());

                                items.Add(item);
                            }
                        }

                        //if (ds != null && ds.Tables.Count > 0)
                        //{
                        //    // Read the the Table
                        //    DataTable serviceDetails = ds.Tables[0];
                        //    //for (int i = 1; i < serviceDetails.Rows.Count; i++)
                        //    //{
                        //    //    CustomerResponseDetail details = new CustomerResponseDetail();
                        //    //    details.ServiceEngineerName = serviceDetails.Rows[i][0].ToString();
                        //    //    details.CustomerName = serviceDetails.Rows[i][1].ToString();
                        //    //    details.Address = serviceDetails.Rows[i][2].ToString();
                        //    //    details.City = serviceDetails.Rows[i][3].ToString();
                        //    //    details.ComplaintType = serviceDetails.Rows[i][4].ToString();
                        //    //    details.DeviceName = serviceDetails.Rows[i][5].ToString();
                        //    //    details.ComplaintDate = Convert.ToDateTime(serviceDetails.Rows[i][6].ToString());
                        //    //    details.VisitDate = Convert.ToDateTime(serviceDetails.Rows[i][7].ToString());
                        //    //    details.ComplaintDetails = serviceDetails.Rows[i][8].ToString();
                        //    //    details.RepairDetails = serviceDetails.Rows[i][9].ToString();
                        //    //    details.ResolveDate = Convert.ToDateTime(serviceDetails.Rows[i][10].ToString());

                        //    //    details.Fees = Convert.ToDecimal(serviceDetails.Rows[i][11].ToString());
                        //    //    details.UploadDate = DateTime.Now;


                        //    //    // Add the record in Database
                        //    //    //await context.CustomerResponseDetails.AddAsync(details);
                        //    //    //await context.SaveChangesAsync();
                        //    //}
                        //}
                    }
                }
                

                
                return new UmiResponse { 
                    Data = items,
                    Success= true
                };
            }
            catch (Exception ex)
            {
                Logger.LogError("Error when uploading excel file - " + ex.Message);
                return BadRequest();
            }
        }
    }
}
