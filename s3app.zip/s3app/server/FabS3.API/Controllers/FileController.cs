﻿using ExcelDataReader;
using FabS3.API.DTOs;
using FabS3.API.Helpers;
using FabS3.Data.Services;
using FabS3.Domain;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace FabS3.API.Controllers
{
    public class FileController : BaseApiController
    {
        public FileController(
            IConfiguration config,
            ILogger<FileController> logger,
             IRepositoryWrapper repositoryWrapper,
             IHostingEnvironment environment
            )
        {
            Config = config;
            Logger = logger;
            Repository = repositoryWrapper;
            Environment = environment;
        }

        IConfiguration Config { get; }
        ILogger Logger { get; }
        IRepositoryWrapper Repository { get; set; }
        
        private IHostingEnvironment Environment;

        IExcelDataReader reader;

        [NonAction]
        public async Task<ActionResult<List<DataTable>>> ParseUploadFiles()
        {
            try
            {
                List<DataTable> result = new List<DataTable>();

                var formCollection = await Request.ReadFormAsync();
                var files = formCollection.Files.ToList();

                if (files == null)
                    throw new Exception("File is Not Received...");

                var tmpFolder = Config["FileSettings:ImportFileFolder"];

                if (!Directory.Exists(tmpFolder))
                {
                    Directory.CreateDirectory(tmpFolder);
                }


                foreach (var file in files)
                {
                    // MAke sure that only Excel file is used 
                    string dataFileName = Path.GetFileName(file.FileName);

                    string extension = Path.GetExtension(dataFileName);

                    string[] allowedExtsnions = new string[] { ".xls", ".xlsx" };

                    if (!allowedExtsnions.Contains(extension))
                        throw new Exception("Sorry! This file is not allowed.");

                    // Make a Copy of the Posted File from the Received HTTP Request
                    string newFileName = "UserUpload_" + DateTime.Now.ToString("YYYYMMDDHHmiss") + extension;
                    string saveToPath = Path.Combine(tmpFolder, newFileName);

                    using (FileStream stream = new FileStream(saveToPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }

                    // USe this to handle Encodeing differences in .NET Core
                    System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

                    // read the excel file
                    using (var stream = new FileStream(saveToPath, FileMode.Open))
                    {
                        if (extension == ".xls")
                            reader = ExcelReaderFactory.CreateBinaryReader(stream);
                        else
                            reader = ExcelReaderFactory.CreateOpenXmlReader(stream);

                        DataSet ds = new DataSet();
                        ds = reader.AsDataSet();
                        reader.Close();

                        var tables = new List<DataTable>(ds.Tables.Cast<DataTable>());

                        if (tables.Count > 0)
                        {
                            result.AddRange(tables);
                        }
                        
                    }

                }

                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpPost("excelImport/stage")]
        [DisableRequestSizeLimit]
        public async Task<ActionResult<UmiResponse>> ImportStageListAsync()
        {
            try
            {
                var data = await ParseUploadFiles();

                if (data != null && data.Value.Count > 0)
                {
                    List<Stage> stages = new List<Stage>();

                    
                        DataTable itemTable = data.Value[0]; // stage list

                        if (itemTable.Rows.Count > 1)
                        {
                            for (int i = 1; i < itemTable.Rows.Count; i++)
                            {
                                DataRow row = itemTable.Rows[i];
                                
                                Stage item = new Stage();

                                item.Tier = Int32.Parse(row[0].ToString());
                                item.Category = row[2].ToString();
                                item.Seq = Int32.Parse(row[1].ToString());
                                item.Name = row[3].ToString();
                                item.Owner = row[4].ToString();
                                item.SignOff = row[5].ToString();

                                stages.Add(item);
                            }
                    }

                    


                    return new UmiResponse
                    {
                        Data = stages,
                        Success = true
                    };
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                Logger.LogError("Error when uploading excel file (stage data) - " + ex.Message);
                return BadRequest();
            }
        }

        [HttpGet("download/{filename}")]
        public IActionResult DownloadFile(string filename)
        {
            try
            {
                return File(System.IO.File.ReadAllBytes(
                    Path.Combine(this.Environment.WebRootPath, "templates/") + filename
                    ), "application/octet-stream", filename);
            }
            catch (Exception ex)
            {
                Logger.LogError("Error when downloading file - " + ex.Message);
                return BadRequest();
            }

        }

        [HttpPost("excelImport/tool")]
        [DisableRequestSizeLimit]
        public async Task<ActionResult<UmiResponse>> ImportToolsAsync()
        {
            try
            {
                var data = await ParseUploadFiles();
                var allProjects = await Repository.Project.GetAllAsync();

                if (data != null && data.Value.Count > 0)
                {
                    List<ToolDto> tools = new List<ToolDto>();

                    DataTable itemTable = data.Value[0]; 

                    if (itemTable.Rows.Count > 1)
                    {
                       

                        for (int i = 1; i < itemTable.Rows.Count; i++)
                        {
                            DataRow row = itemTable.Rows[i];

                            
                            ToolDto item = new ToolDto();

                            item.Area = row[0].ToString();
                            item.Section = row[1].ToString();
                            item.Tooltype = row[2].ToString();
                            item.Entity = row[3].ToString();
                            item.EqpId = row[4].ToString();
                            item.Supplier = row[5].ToString();
                            item.ToolModel = row[6].ToString();
                            item.Project = row[7].ToString();

                            if (!String.IsNullOrEmpty(item.Project))
                            {
                                var project = allProjects.Where(p => p.Name.ToUpper() == item.Project.ToUpper());

                                if (project != null && project.Count() > 0)
                                {
                                    item.ProjectId = project.First().Id.ToString();
                                }
                            }

                            item.ToolClass = row[8].ToString();
                            item.Process = row[9].ToString();
                            item.ProcessType = row[10].ToString();
                            item.Priority = row[11] != null ? Int32.Parse(row[11].ToString()): 0;
                            item.FabBay = row[12].ToString();
                            item.EeOwner = row[13].ToString();
                            item.PeOwner = row[14].ToString();

                            // plan dates
                            item.ToolRegistrationPlanDate = row[15].ToString().Split(null)[0];
                            item.PreSiteInspectionPlanDate = row[16].ToString().Split(null)[0];
                            item.SiteInspectionPlanDate = row[17].ToString().Split(null)[0];
                            item.PreMoveInPlanDate = row[18].ToString().Split(null)[0];
                            item.MoveInPlanDate = row[19].ToString().Split(null)[0];
                            item.PreESO1PlanDate = row[20].ToString().Split(null)[0];
                            item.ESO1PlanDate = row[21].ToString().Split(null)[0];
                            item.PreESO2PlanDate = row[22].ToString().Split(null)[0];
                            item.ESO2PlanDate = row[23].ToString().Split(null)[0];
                            item.PostESO2PlanDate = row[24].ToString().Split(null)[0];
                            item.EEHandoverPlanDate = row[25].ToString().Split(null)[0];
                            item.ProcessTuningPlanDate = row[26].ToString().Split(null)[0];
                            item.NPWMatchingPlanDate = row[27].ToString().Split(null)[0];
                            item.PrePcrbPlanDate = row[28].ToString().Split(null)[0];
                            item.PcrbQualPlanDate = row[29].ToString().Split(null)[0];
                            item.PrePilotPlanDate = row[30].ToString().Split(null)[0];
                            item.PilotPlanDate = row[31].ToString().Split(null)[0];

                            // req dates
                            item.ToolRegistrationReqDate = row[32].ToString().Split(null)[0];
                            item.PreSiteInspectionReqDate = row[33].ToString().Split(null)[0];
                            item.SiteInspectionReqDate = row[34].ToString().Split(null)[0];
                            item.PreMoveInReqDate = row[35].ToString().Split(null)[0];
                            item.MoveInReqDate = row[36].ToString().Split(null)[0];
                            item.PreESO1ReqDate = row[37].ToString().Split(null)[0];
                            item.ESO1ReqDate = row[38].ToString().Split(null)[0];
                            item.PreESO2ReqDate = row[39].ToString().Split(null)[0];
                            item.ESO2ReqDate = row[40].ToString().Split(null)[0];
                            item.PostESO2ReqDate = row[41].ToString().Split(null)[0];
                            item.EEHandoverReqDate = row[42].ToString().Split(null)[0];
                            item.ProcessTuningReqDate = row[43].ToString().Split(null)[0];
                            item.NPWMatchingReqDate = row[44].ToString().Split(null)[0];
                            item.PrePcrbReqDate = row[45].ToString().Split(null)[0];
                            item.PcrbQualReqDate = row[46].ToString().Split(null)[0];
                            item.PrePilotReqDate = row[47].ToString().Split(null)[0];
                            item.PilotReqDate = row[48].ToString().Split(null)[0];

                            // lt
                            item.PreSiteInspectionLT = row[49].ToString();
                            item.PreMoveInLT = row[50].ToString();
                            item.PreESO1LT = row[51].ToString();
                            item.PreESO2LT = row[52].ToString();
                            item.PostESO2LT = row[53].ToString();
                            item.ProcessTuningLT = row[54].ToString();
                            item.PrePcrbLT = row[55].ToString();
                            item.PrePilotLT = row[56].ToString();
                            //item.QualDataReviewLT = row[57].ToString();

                            tools.Add(item);

                        }
                    }


                    return new UmiResponse
                    {
                        Data = tools,
                        Success = true
                    };
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                Logger.LogError("Error when uploading excel file (tool data) - " + ex.Message);
                return BadRequest();
            }
        }

        [HttpPost("excelImport/stageChecklist")]
        [DisableRequestSizeLimit]
        public async Task<ActionResult<UmiResponse>> ImportStageItemAsync()
        {
            try
            {
                var data = await ParseUploadFiles();

                if (data != null && data.Value.Count > 0)
                {
                    List<StageChecklist> stages = new List<StageChecklist>();


                    DataTable itemTable = data.Value[0]; // stage list

                    if (itemTable.Rows.Count > 1)
                    {
                        string stageName = ""; Guid stageId = Guid.Empty;
                        int seq = 1;

                        for (int i = 1; i < itemTable.Rows.Count; i++)
                        {
                            DataRow row = itemTable.Rows[i];

                            if (stageName == "" || stageName != row[0].ToString())
                            {
                                stageName = row[0].ToString();
                                var stage = await Repository.Stage.GetByConditionAsync(s => s.Name.ToUpper() == stageName.ToUpper());

                                if (stage != null && stage.Count() > 0)
                                {
                                    stageId = stage.FirstOrDefault().Id;
                                }

                                seq = 1;
                            }
                            

                            StageChecklist item = new StageChecklist();

                            item.StageId = stageId;
                            item.StageName = stageName;
                            item.Seq = String.IsNullOrEmpty(row[1].ToString()) ? seq : Int32.Parse(row[1].ToString());
                            item.Item = row[2].ToString();
                            item.InputType = row[3].ToString();
                            item.Owner = row[4].ToString();

                            stages.Add(item);

                            seq++;
                        }
                    }




                    return new UmiResponse
                    {
                        Data = stages,
                        Success = true
                    };
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                Logger.LogError("Error when uploading excel file (stage data) - " + ex.Message);
                return BadRequest();
            }
        }

        [HttpPost("excelImport/checklist")]
        [DisableRequestSizeLimit]
        public async Task<ActionResult<UmiResponse>> ImportChecklistAsync()
        {
            try
            {
                var data = await ParseUploadFiles();

                if (data != null && data.Value.Count > 0)
                {
                    List<ChecklistItem> items = new List<ChecklistItem>();

                    DataTable itemTable = data.Value.FirstOrDefault();

                    if (itemTable.Rows.Count > 1)
                    {
                        for (int i = 1; i < itemTable.Rows.Count; i++)
                        {
                            DataRow row = itemTable.Rows[i];
                            if (row[0].ToString().ToUpper() == "NO") continue;

                            ChecklistItem item = new ChecklistItem();

                            item.Seq = float.Parse(row[0].ToString());
                            item.Category = row[1].ToString();
                            item.SubSeq = float.Parse(row[2].ToString());
                            item.SubCategory = row[3].ToString();
                            item.InputType = row[4].ToString();
                            item.MaxLength = Int32.Parse(row[5].ToString());

                            items.Add(item);
                        }
                    }
                    

                    return new UmiResponse
                    {
                        Data = items,
                        Success = true
                    };
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                Logger.LogError("Error when uploading excel file - " + ex.Message);
                return BadRequest();
            }
        }

        [HttpPost("excelImport")]
        [DisableRequestSizeLimit]
        public async Task<ActionResult<UmiResponse>> ImportExcelAsync()
        {
            try
            {
                var formCollection = await Request.ReadFormAsync();
                var files = formCollection.Files.ToList();
                //// var fileCreateds = await _fileService.UploadSharedFile(files, ClaimsPrincipalExtensions.GetUserId<int>(User));
                //file = files[0];

                // Check the File is received

                if (files == null )
                    throw new Exception("File is Not Received...");

                var tmpFolder = Config["FileSettings:ImportFileFolder"];

                if (!Directory.Exists(tmpFolder))
                {
                    Directory.CreateDirectory(tmpFolder);
                }


                List<ChecklistItem> items = new List<ChecklistItem>();

                foreach ( var file in files)
                {
                    // MAke sure that only Excel file is used 
                    string dataFileName = Path.GetFileName(file.FileName);

                    string extension = Path.GetExtension(dataFileName);

                    string[] allowedExtsnions = new string[] { ".xls", ".xlsx" };

                    if (!allowedExtsnions.Contains(extension))
                        throw new Exception("Sorry! This file is not allowed.");

                    // Make a Copy of the Posted File from the Received HTTP Request
                    string saveToPath = Path.Combine(tmpFolder, dataFileName);

                    using (FileStream stream = new FileStream(saveToPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }

                    // USe this to handle Encodeing differences in .NET Core
                    System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

                    // read the excel file
                    using (var stream = new FileStream(saveToPath, FileMode.Open))
                    {
                        if (extension == ".xls")
                            reader = ExcelReaderFactory.CreateBinaryReader(stream);
                        else
                            reader = ExcelReaderFactory.CreateOpenXmlReader(stream);

                        DataSet ds = new DataSet();
                        ds = reader.AsDataSet();
                        reader.Close();

                        if (ds.Tables.Count > 0)
                        {
                            DataTable itemTable = ds.Tables[0];

                            for (int i = 0; i < itemTable.Rows.Count; i++)
                            {                                
                                DataRow row = itemTable.Rows[i];
                                if (row[0].ToString() == "N") continue;

                                ChecklistItem item = new ChecklistItem();

                                item.Seq = float.Parse(row[0].ToString());
                                item.Category = row[1].ToString();
                                item.SubSeq = float.Parse(row[2].ToString());
                                item.SubCategory = row[3].ToString();
                                item.InputType = row[4].ToString();
                                item.MaxLength = Int32.Parse(row[5].ToString());

                                items.Add(item);
                            }
                        }

                    }
                }
                

                
                return new UmiResponse { 
                    Data = items,
                    Success= true
                };
            }
            catch (Exception ex)
            {
                Logger.LogError("Error when uploading excel file - " + ex.Message);
                return BadRequest();
            }
        }
    }
}
