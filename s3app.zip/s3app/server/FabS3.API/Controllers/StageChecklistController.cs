﻿using AutoMapper;
using FabS3.API.Helpers;
using FabS3.Data.Services;
using FabS3.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace FabS3.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StageChecklistController : ControllerBase
    {
        public StageChecklistController(
            IRepositoryWrapper repositoryWrapper,
            IMapper mapper,
            ILogger<StageChecklistController> logger
            )
        {
            Repository = repositoryWrapper;
            Mapper = mapper;
            Logger = logger;
        }

        public IMapper Mapper { get; }
        public IRepositoryWrapper Repository { get; set; }
        public ILogger<StageChecklistController> Logger { get; set; }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<StageChecklist>>> GetStageChecklistsAsync()
        {
            var data = await Repository.StageChecklist.GetAllAsync();

            return Ok(new UmiResponse
            {
                Data = data.OrderBy(s => s.StageId).ToList(),
                Success = true,
                Status = 200
            });
        }

        [HttpGet("{stageChecklistId}", Name = nameof(GetStageChecklistAsync))]
        public async Task<ActionResult<StageChecklist>> GetStageChecklistAsync(Guid stageChecklistId)
        {
            var stage = await Repository.StageChecklist.GetByIdAsync(stageChecklistId);

            if (stage == null)
            {
                return NotFound();
            }

            return stage;
        }

        [HttpPost]
        public async Task<IActionResult> AddStageChecklistAsync(
            StageChecklist stageToCreate
            )
        {
            var stage = Mapper.Map<StageChecklist>(stageToCreate);

            Repository.StageChecklist.Create(stage);

            var result = await Repository.StageChecklist.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to create StageChecklist.");
            }

            return CreatedAtRoute(
                nameof(GetStageChecklistAsync),
                new
                {
                    stageChecklistId = stage.Id
                }, stage);
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteStageChecklistAsync([FromBody] JsonElement key)
        {
            var stageId = key.GetProperty("stageId").ToString();
            var stage = await Repository.StageChecklist.GetByIdAsync(Guid.Parse(stageId));

            if (stage == null)
            {
                return BadRequest();
            }

            Repository.StageChecklist.Delete(stage);

            var result = await Repository.StageChecklist.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to remove stage ", stage);
                return BadRequest();
            }

            return NoContent();

        }

        [HttpPut]
        public async Task<IActionResult> UpdateStageChecklistAsync(StageChecklist stageToUpdate)
        {
            var stage = await Repository.StageChecklist.GetByIdAsync(stageToUpdate.Id);

            if (stage == null)
            {
                return BadRequest();
            }

            Mapper.Map<StageChecklist, StageChecklist>(stageToUpdate, stage);

            Repository.StageChecklist.Update(stage);

            var result = await Repository.StageChecklist.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to update stage checklist ", stage);
                return BadRequest();
            }

            return NoContent();

        }
    }
}
