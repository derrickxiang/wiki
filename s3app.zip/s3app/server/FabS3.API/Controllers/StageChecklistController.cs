﻿using AutoMapper;
using FabS3.API.DTOs;
using FabS3.API.Helpers;
using FabS3.Data.Services;
using FabS3.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace FabS3.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StageChecklistController : ControllerBase
    {
        public StageChecklistController(
            IRepositoryWrapper repositoryWrapper,
            IMapper mapper,
            ILogger<StageChecklistController> logger
            )
        {
            Repository = repositoryWrapper;
            Mapper = mapper;
            Logger = logger;
        }

        public IMapper Mapper { get; }
        public IRepositoryWrapper Repository { get; set; }
        public ILogger<StageChecklistController> Logger { get; set; }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<StageChecklist>>> GetStageChecklistsAsync()
        {
            var data = await Repository.StageChecklist.GetAllAsync();

            return Ok(new UmiResponse
            {
                Data = data.OrderBy(s => s.StageId).ToList(),
                Success = true,
                Status = 200
            });
        }

        [Route("bystage")]
        [HttpGet]
        public async Task<ActionResult<UmiResponse>> GetChecklistByNameAsync(string stage)
        {
            var existStage = await Repository.Stage.GetByConditionAsync(s => s.Name.ToUpper() == stage.Replace('+',' ').ToUpper());

            if (existStage == null || existStage.Count() == 0) return BadRequest();

            var stageId = existStage.First().Id;

            var data = await Repository.StageChecklist.GetByConditionAsync(s => s.StageId == stageId);

            return Ok(new UmiResponse
            {
                Data = data.OrderBy(s=>s.Seq).ToList(),
                Success = true
            });
        }

        [HttpGet("{stageChecklistId}", Name = nameof(GetStageChecklistAsync))]
        public async Task<ActionResult<StageChecklist>> GetStageChecklistAsync(Guid stageChecklistId)
        {
            var stage = await Repository.StageChecklist.GetByIdAsync(stageChecklistId);

            if (stage == null)
            {
                return NotFound();
            }

            return stage;
        }

        [HttpPost]
        public async Task<IActionResult> AddStageChecklistAsync(
            StageChecklistDto stageToCreate
            )
        {
            var stage = Mapper.Map<StageChecklist>(stageToCreate);

            if (stage == null) return BadRequest();

            if (!String.IsNullOrEmpty(stageToCreate.TemplateId))
            {
                var template = await Repository.ChecklistTemplate.GetByIdAsync(Guid.Parse(stageToCreate.TemplateId));

                if (template != null)
                {
                    stageToCreate.ChecklistId = template.ChecklistId;
                    stageToCreate.TemplateVer = template.Version;
                }
            }

            var existStage = await Repository.StageChecklist.GetByConditionAsync(s => (s.StageId == stage.StageId && s.Item == stage.Item));

            if (existStage != null && existStage.Count() > 0)
            {
                var oldStage = existStage.First();

                Mapper.Map(stage, oldStage);

                Repository.StageChecklist.Update(oldStage);
            }
            else
            {
                Repository.StageChecklist.Create(stage);
            }

            var result = await Repository.StageChecklist.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to create StageChecklist.");
            }

            return CreatedAtRoute(
                nameof(GetStageChecklistAsync),
                new
                {
                    stageChecklistId = stage.Id
                }, stage);
        }

        [HttpPost("batch")]
        public async Task<IActionResult> AddStageChecklistsAsync(
            StageChecklistDto[] stagesToCreate
            )
        {
            try
            {
                foreach (StageChecklistDto stageToCreate in stagesToCreate)
                {
                    var stage = Mapper.Map<StageChecklist>(stageToCreate);

                    if (stage == null) return BadRequest();


                    if (!String.IsNullOrEmpty(stageToCreate.TemplateId))
                    {
                        var template = await Repository.ChecklistTemplate.GetByIdAsync(Guid.Parse(stageToCreate.TemplateId));

                        if (template != null)
                        {
                            stageToCreate.ChecklistId = template.ChecklistId;
                            stageToCreate.TemplateVer = template.Version;
                        }
                    }

                    var existStage = await Repository.StageChecklist.GetByConditionAsync(s => s.StageId == stage.StageId && s.Item == stage.Item);

                    if (existStage != null && existStage.Count() > 0)
                    {
                        var oldStage = existStage.First();

                        //Mapper.Map(stage, oldStage);
                        oldStage.UpdateBy = stage.UpdateBy;
                        oldStage.UpdateAt = stage.UpdateAt;
                        oldStage.Description = stage.Item;
                        oldStage.Owner = stage.Owner;
                        oldStage.Seq = stage.Seq;
                        oldStage.InputType = stage.InputType;
                        oldStage.TemplateId = stage.TemplateId;
                        oldStage.ChecklistId = stage.ChecklistId;

                        Repository.StageChecklist.Update(oldStage);
                    }
                    else
                    {
                        Repository.StageChecklist.Create(stage);
                    }


                    var result = await Repository.Stage.SaveAsync();

                    if (!result)
                    {
                        Logger.LogError("Fail to create Stage checklists.");
                    }
                }


                return Ok();
            }
            catch (Exception ex)
            {
                Logger.LogError("Error when adding stage - ", ex);
                return BadRequest();
            }

        }

        [HttpDelete]
        public async Task<IActionResult> DeleteStageChecklistAsync([FromBody] JsonElement key)
        {
            var stageId = key.GetProperty("stageId").ToString();
            var stage = await Repository.StageChecklist.GetByIdAsync(Guid.Parse(stageId));

            if (stage == null)
            {
                return BadRequest();
            }

            Repository.StageChecklist.Delete(stage);

            var result = await Repository.StageChecklist.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to remove stage ", stage);
                return BadRequest();
            }

            return NoContent();

        }

        [HttpPut]
        public async Task<IActionResult> UpdateStageChecklistAsync(StageChecklistDto stageToUpdate)
        {
            var stage = await Repository.StageChecklist.GetByIdAsync(Guid.Parse(stageToUpdate.Id));

            if (stage == null)
            {
                return BadRequest();
            }

            if (!String.IsNullOrEmpty(stageToUpdate.TemplateId))
            {
                var template = await Repository.ChecklistTemplate.GetByIdAsync(Guid.Parse(stageToUpdate.TemplateId));

                if (template != null)
                {
                    stageToUpdate.ChecklistId = template.ChecklistId;
                    stageToUpdate.TemplateVer = template.Version;
                }
            }

            Mapper.Map<StageChecklistDto, StageChecklist>(stageToUpdate, stage);

            Repository.StageChecklist.Update(stage);

            var result = await Repository.StageChecklist.SaveAsync();

            if (!result)
            {
                Logger.LogError("Fail to update stage checklist ", stage);
                return BadRequest();
            }

            if (stageToUpdate.InputType == "Checklist" && !String.IsNullOrEmpty(stageToUpdate.ChecklistId))
            {
                var activeStageChecklist = await Repository.ToolChecklist.GetByConditionAsync(t =>
                            (String.IsNullOrEmpty(t.Status) || t.Status == "Processing")
                            && t.StageId == Guid.Parse(stageToUpdate.StageId)
                            && t.Seq == stageToUpdate.Seq);

                if (activeStageChecklist != null)
                {
                    foreach(ToolChecklist checklist  in activeStageChecklist)
                    {
                        checklist.ChecklistId = stageToUpdate.ChecklistId;

                        Repository.ToolChecklist.Update(checklist);
                    }

                    await Repository.ToolChecklist.SaveAsync();
                }
            }

            return NoContent();

        }
    }
}
