﻿using AutoMapper;
using FabS3.API.Helpers;
using FabS3.Data.Services;
using FabS3.Domain;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace FabS3.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        public UserController(
            IRepositoryWrapper repositoryWrapper,
            UserManager<AppUser> userManager,
            IMapper mapper,
            ILogger<UserController> logger
            )
        {
            Repository = repositoryWrapper;
            UserManager = userManager;
            Mapper = mapper;
            Logger = logger;
        }

        public IMapper Mapper { get; }
        public IRepositoryWrapper Repository { get; set; }
        public ILogger<UserController> Logger { get; set; }
        public UserManager<AppUser> UserManager { get; }


        [Route("settings")]
        [HttpGet]
        public async Task<ActionResult<UmiResponse>> GetUserSettingsAsync()
        {
            var userId = User.FindFirstValue(ClaimTypes.Name);

            if (userId != null)
            {
                var userSetting = await Repository.UserSetting.GetByConditionAsync(
                     s => s.UserId == userId
                    );

                return new UmiResponse
                {
                    Data = userSetting,
                    Success = true
                };
            }

            return NotFound();

        }

        [Route("settings")]
        [HttpPost]
        public async Task<IActionResult> AddUserSettingsAsync(UserSetting setting)
        {
            if (setting == null) return BadRequest();

            var oldSetting = await Repository.UserSetting.GetByConditionAsync(u =>
                    (u.Name == setting.Name && u.UserId == setting.UserId));

            if (oldSetting != null && oldSetting.Count() > 0)
            {
                var settingToUpdate = oldSetting.First();

                settingToUpdate.Value = setting.Value;
                settingToUpdate.UpdateAt = DateTime.Now;

                Repository.UserSetting.Update(settingToUpdate);
            }
            else
            {
                Repository.UserSetting.Create(setting);
            }

            var result = await Repository.UserSetting.SaveAsync();

            if (!result)
            {
                Logger.LogError("Error, fail to save user setting.", setting);

                return BadRequest();
            }

            return Ok();
        }
    }
}
