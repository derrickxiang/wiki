﻿using AutoMapper;
using FabS3.API.DTOs;
using FabS3.API.Helpers;
using FabS3.Data.Services;
using FabS3.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace FabS3.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ToolChecklistController : ControllerBase
    {
        public ToolChecklistController(
            IRepositoryWrapper repositoryWrapper,
            IMapper mapper,
            ILogger<ToolChecklistController> logger
            )
        {
            Repository = repositoryWrapper;
            Mapper = mapper;
            Logger = logger;
        }

        public IMapper Mapper { get; }
        public IRepositoryWrapper Repository { get; set; }
        public ILogger<ToolChecklistController> Logger { get; set; }

        [HttpGet]
        public async Task<ActionResult<UmiResponse>> GetAllToolChecklistsAsync()
        {
            var checklist = await Repository.ToolChecklist.GetAllAsync();

            return Ok(new UmiResponse
            {
                Data = checklist,
                Success = true
            });
        }


        [HttpGet("bytool")]
        public async Task<ActionResult<UmiResponse>> GetToolChecklistsByToolAsync(string toolId, string stageId)
        {
            var checklist = await Repository.ToolChecklist.GetByConditionAsync(t =>
                        (t.ToolId == Guid.Parse(toolId) && t.StageId == Guid.Parse(stageId) ));

            return Ok(new UmiResponse
            {
                Data = checklist,
                Success = true
            });
        }

        [HttpPut("item")]
        public async Task<IActionResult> UpdateToolChecklistItemAsync([FromBody] JsonElement key)
        {
            var itemId = key.GetProperty("itemId").ToString();
            var value = key.GetProperty("value").ToString();
            var chkId = key.GetProperty("checklistId").ToString();
            var user = key.GetProperty("user").ToString();

            if (String.IsNullOrEmpty(itemId) || String.IsNullOrEmpty(chkId))
            {
                return BadRequest("Invalid ID");
            }

            var item = await Repository.ToolChecklistItem.GetByConditionAsync(i => i.ChecklistItemId == Guid.Parse(itemId) && i.ToolChecklistId == Guid.Parse(chkId));

            if (item != null && item.Count() > 0)
            {
                var itemToUpdate = item.First();

                itemToUpdate.Value = value;
                itemToUpdate.UpdateBy = user;
                itemToUpdate.UpdateAt = DateTime.Now;

                Repository.ToolChecklistItem.Update(itemToUpdate);

                var success = await Repository.ToolChecklistItem.SaveAsync();

                if (!success)
                {
                    Logger.LogError("Fail to update checklist item.");
                    return BadRequest();
                }
            }

            return Ok();
        }

        [HttpPut]
        public async Task<IActionResult> UpdateToolChecklistItem([FromBody] JsonElement key)
        {
            var itemId = key.GetProperty("id").ToString();
            var value = key.GetProperty("value").ToString();
            var status = key.GetProperty("status").ToString();
            var user = key.GetProperty("user").ToString();

            if (String.IsNullOrEmpty(itemId))
            {
                return BadRequest("Invalid ID");
            }

            var item = await Repository.ToolChecklist.GetByIdAsync(Guid.Parse(itemId));

            item.Value = value;
            item.Status = status;
            item.UpdateBy = user;
            item.UpdateAt = DateTime.Now;

            Repository.ToolChecklist.Update(item);
            
            var success = await Repository.ToolChecklist.SaveAsync();

            if (success)
            {
                var toolStage = await Repository.ToolStage.GetByConditionAsync(t => t.ToolId == item.ToolId && t.StageId == item.StageId);

                if (toolStage != null)
                {
                    var stage = toolStage.First();
                    var completeItems = await Repository.ToolChecklist.GetByConditionAsync(c => c.ToolId == item.ToolId && c.StageId == item.StageId && !String.IsNullOrEmpty(c.Value));

                    if (completeItems != null)
                    {
                        stage.CompleteChecklist = completeItems.Count();
                        stage.Status = "Processing";

                        Repository.ToolStage.Update(stage);
                        await Repository.ToolStage.SaveAsync();
                    }
                    
                }
            }

            return Ok();

        }

        [HttpGet("items")]
        public async Task<ActionResult<UmiResponse>> GetToolChecklistItemsAsync(string toolChecklistId)
        {
            if (String.IsNullOrEmpty(toolChecklistId)) return BadRequest();

            var items = await Repository.ToolChecklistItem.GetByConditionAsync(c => c.ToolChecklistId == Guid.Parse(toolChecklistId));

            if (items == null || items.Count() == 0)
            {
                var toolChecklist = await Repository.ToolChecklist.GetByIdAsync(Guid.Parse(toolChecklistId));

                if (toolChecklist != null && !String.IsNullOrEmpty(toolChecklist.ChecklistId))
                {
                    var chkItems = await Repository.ChecklistItem.GetByConditionAsync(i => i.ChecklistId == toolChecklist.ChecklistId);

                    if (chkItems != null && chkItems.Count() > 0)
                    {
                        
                        foreach (var chkItem in chkItems)
                        {
                            ToolChecklistItem tcItem = new ToolChecklistItem();

                            tcItem.ChecklistItemId = chkItem.Id;
                            tcItem.ToolChecklistId = toolChecklist.Id;
                            tcItem.UpdateAt = DateTime.Now;

                            Repository.ToolChecklistItem.Create(tcItem);
                            
                        }

                        await Repository.ToolChecklistItem.SaveAsync();

                        items = await Repository.ToolChecklistItem.GetByConditionAsync(c => c.ToolChecklistId == Guid.Parse(toolChecklistId));
                    }
                    else
                    {
                        return NotFound("No checklist items");
                    }
                }
                else
                {
                    return NotFound("No checklist");
                }
                
            }

            List<ToolChecklistItemDto> result = new List<ToolChecklistItemDto>();

            foreach(var item in items)
            {
                var cItem = await Repository.ChecklistItem.GetByIdAsync(item.ChecklistItemId);

                result.Add(new ToolChecklistItemDto
                {
                    Id = item.Id,
                    ToolChecklistId = item.ToolChecklistId,
                    ChecklistItemId = item.ChecklistItemId,
                    Seq = cItem.Seq,
                    SubSeq = cItem.SubSeq,
                    Category = cItem.Category,
                    SubCategory = cItem.SubCategory,
                    InputType = cItem.InputType,
                    Value = item.Value,
                    Remark = item.Remark,
                    UpdateAt = item.UpdateAt,
                    UpdateBy = item.UpdateBy
                });
            }

            return Ok(new UmiResponse
            {
                Data = result,
                Success = true
            });

        }

        [HttpGet("{toolId}/{stageId}")]
        public async Task<ActionResult<UmiResponse>>  GetToolChecklistsAsync(string toolId, string stageId)
        {
            var checklist = await Repository.ToolChecklist.GetByConditionAsync(t =>
                        (t.ToolId == Guid.Parse(toolId) && t.StageId == Guid.Parse(stageId)));

            return Ok(new UmiResponse
            {
                Data = checklist,
                Success = true
            });
        }

        [HttpPost]
        public async Task<IActionResult> AddToolChecklistAsync(ToolChecklist checklist)
        {
            var existRecord = await Repository.ToolChecklist.GetByConditionAsync(t =>
                        t.ToolId == checklist.ToolId &&
                        t.StageId == checklist.StageId &&
                        t.Seq == checklist.Seq);

            if (existRecord != null && existRecord.Count() > 0)
            {
                var oldRecord = existRecord.First();

                oldRecord.Value = checklist.Value;
                oldRecord.InputType = checklist.InputType;
                oldRecord.ChecklistId = checklist.ChecklistId;
                oldRecord.UpdateAt = checklist.UpdateAt;
                oldRecord.UpdateBy = checklist.UpdateBy;

                Repository.ToolChecklist.Update(oldRecord);
            }
            else
            {
                Repository.ToolChecklist.Create(checklist);
            }

            var result = await Repository.ToolChecklist.SaveAsync();


            if (!result)
            {
                Logger.LogError("Fail to create ToolChecklist.");

                return BadRequest();
            }

            return Ok();
        }

        [HttpPost("batchUpdate")]
        public async Task<IActionResult> updateToolChecklistAsync(ToolChecklist[] checklists)
        {

            foreach(ToolChecklist checklist in checklists)
            {
                var existRecord = await Repository.ToolChecklist.GetByConditionAsync(t =>
                        t.ToolId == checklist.ToolId &&
                        t.StageId == checklist.StageId &&
                        t.Seq == checklist.Seq);

                if (existRecord != null && existRecord.Count() > 0)
                {
                    var oldRecord = existRecord.First();

                    oldRecord.Value = checklist.Value;
                    oldRecord.InputType = checklist.InputType;
                    oldRecord.Item = checklist.Item;
                    oldRecord.ChecklistId = checklist.ChecklistId;
                    oldRecord.Status = checklist.Status;
                    oldRecord.ApprovalStatus = checklist.ApprovalStatus;
                    oldRecord.UpdateAt = checklist.UpdateAt;
                    oldRecord.UpdateBy = checklist.UpdateBy;

                    Repository.ToolChecklist.Update(oldRecord);
                }
                else
                {
                    Repository.ToolChecklist.Create(checklist);
                }

                var result = await Repository.ToolChecklist.SaveAsync();


                if (!result)
                {
                    Logger.LogError("Fail to create ToolChecklist.");

                    return BadRequest();
                }

            }

            await RefreshTooChecklistItemsAsync();

            return Ok();
        }

        private async Task<IActionResult> RefreshTooChecklistItemsAsync()
        {
            var checklists = await Repository.ToolChecklist.GetByConditionAsync(t => t.InputType == "Checklist" && !String.IsNullOrEmpty(t.ChecklistId));

            if (checklists != null && checklists.Count() > 0)
            {
                foreach(ToolChecklist checklist in checklists)
                {
                    var existItems = await Repository.ToolChecklistItem.GetByConditionAsync(i => i.ToolChecklistId == checklist.Id);

                    if (existItems != null && existItems.Count() > 0) continue;

                    var items = await Repository.ChecklistItem.GetByConditionAsync(c => c.ChecklistId == checklist.ChecklistId);

                    if (items != null && items.Count() > 0)
                    {
                        
                        foreach (ChecklistItem item in items)
                        {
                            ToolChecklistItem tItem = new ToolChecklistItem();

                            tItem.ToolChecklistId = checklist.Id;
                            tItem.ChecklistItemId = item.Id;

                            Repository.ToolChecklistItem.Create(tItem);
                        }

                        await Repository.ToolChecklistItem.SaveAsync();
                    }
                }
            }

            return NoContent();
        }
    }
}
