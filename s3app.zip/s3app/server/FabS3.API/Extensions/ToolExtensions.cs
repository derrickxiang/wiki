﻿using FabS3.Data;
using FabS3.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FabS3.API.Extensions
{
    public static class ToolExtensions
    {
        public static void AddStages(this Tool tool, S3Context context)
        {
            var existStages = context.ToolStages.Where(s => s.ToolId == tool.Id);

            var newStages = context.Stages.Where(s => !existStages.Where(e => e.StageId == s.Id).Any());

            if (newStages.Count() > 0)
            {
                ToolStage[] newToolStages = new ToolStage[newStages.Count()];

                int i = 0;

                foreach (Stage s in newStages)
                {
                    newToolStages[i++] = new ToolStage
                    {
                        ToolId = tool.Id,
                        StageId = s.Id,
                        Status = "Init"                        
                    };
                }

                context.ToolStages.AddRange(newToolStages);
                context.SaveChanges();
            }

            // init the tool stage checklist
            var existChks = context.ToolChecklists.Where(s => s.ToolId == tool.Id);

            if (existChks != null && existChks.Count() > 0)
            {
                context.ToolChecklists.RemoveRange(existChks);
                context.SaveChanges();
            }

            var stages = context.ToolStages.Where(s => s.ToolId == tool.Id);

            if (stages.Count() > 0)
            {
                foreach (ToolStage stage in stages)
                {
                    var checklists = context.StageChecklists.Where(s => s.StageId == stage.StageId);
                    List<ToolChecklist> tChecklists = new List<ToolChecklist>();

                    foreach (StageChecklist chk in checklists)
                    {
                        ToolChecklist tchk = new ToolChecklist();
                        tchk.ToolId = tool.Id;
                        tchk.StageId = stage.StageId;
                        tchk.Seq = chk.Seq;
                        tchk.Item = chk.Item;
                        tchk.InputType = chk.InputType;
                        tchk.Owner = chk.Owner;
                        tchk.ChecklistId = chk.ChecklistId;
                        tchk.TemplateId = chk.TemplateId;
                        tchk.TemplateVer = chk.TemplateVer;

                        tChecklists.Add(tchk);
                    }

                    context.ToolChecklists.AddRange(tChecklists);
                    context.SaveChanges();

                    stage.TotalChecklist = tChecklists.Count();
                    stage.CompleteChecklist = 0;

                    context.ToolStages.Update(stage);
                    context.SaveChanges();
                }

            }

        }

        public static void AddChecklist(this Tool tool, S3Context context)
        {
            var existChks = context.ToolChecklists.Where(s => s.ToolId == tool.Id);

            if (existChks != null && existChks.Count() > 0)
            {
                context.ToolChecklists.RemoveRange(existChks);
                context.SaveChanges();
            }

            var stages = context.ToolStages.Where(s => s.ToolId == tool.Id);

            if (stages.Count() > 0)
            {
                foreach(ToolStage stage in stages)
                {
                    var checklists = context.StageChecklists.Where(s => s.StageId == stage.StageId);
                    List<ToolChecklist> tChecklists = new List<ToolChecklist>();

                    foreach(StageChecklist chk in checklists)
                    {
                        ToolChecklist tchk = new ToolChecklist();
                        tchk.ToolId = tool.Id;
                        tchk.StageId = stage.StageId;
                        tchk.Seq = chk.Seq;
                        tchk.Item = chk.Item;
                        tchk.InputType = chk.InputType;
                        tchk.Owner = chk.Owner;
                        tchk.ChecklistId = chk.ChecklistId;
                        tchk.TemplateId = chk.TemplateId;
                        tchk.TemplateVer = chk.TemplateVer;

                        tChecklists.Add(tchk);
                    }

                    context.ToolChecklists.AddRange(tChecklists);
                    context.SaveChanges();

                    // update checklist items
                    var chkForms = context.ToolChecklists.Where(t => t.ToolId == tool.Id && t.InputType == "Checklist");

                    if (chkForms != null && chkForms.Count() > 0)
                    {
                        foreach (ToolChecklist chkForm in chkForms)
                        {
                            if (!String.IsNullOrEmpty(chkForm.ChecklistId))
                            {
                                // check exists
                                var exisItems = context.ToolChecklistItems.Where(c => c.ToolChecklistId == chkForm.Id);

                                if (exisItems != null && exisItems.Count() > 0)
                                {
                                    
                                    context.ToolChecklistItems.RemoveRange(exisItems);
                                    context.SaveChanges();
                                }

                                var tempItems = context.ChecklistItems.Where(c => c.ChecklistId == chkForm.ChecklistId);

                                if (tempItems != null && tempItems.Count() > 0)
                                {
                                    foreach (ChecklistItem item in tempItems)
                                    {
                                        ToolChecklistItem tItem = new ToolChecklistItem();

                                        tItem.ToolChecklistId = chkForm.Id;
                                        tItem.ChecklistItemId = item.Id;

                                        context.ToolChecklistItems.Add(tItem);
                                    }

                                    context.SaveChanges();
                                }
                            }
                        }
                    }
                }
                
            }
        }
    }
}
