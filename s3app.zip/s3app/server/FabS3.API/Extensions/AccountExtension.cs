﻿using FabS3.Data;
using FabS3.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FabS3.API.Extensions
{
    public static class AccountExtension
    {
        public static string GetRoles(this AppUser appUser, S3Context context)
        {
            var roles = (from u in context.UserRoles
                         join r in context.Roles
                         on u.RoleId equals r.Id
                         where u.UserId == appUser.Id
                         select r.Name
                         ).ToArray();

            return String.Join(',', roles);
        }

        public static string[] GetRolesArray(this AppUser appUser, S3Context context)
        {
            return (from u in context.UserRoles
                    join r in context.Roles
                    on u.RoleId equals r.Id
                    where u.UserId == appUser.Id
                    select r.Name
                         ).ToArray();
        }
    }
}
