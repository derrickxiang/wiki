﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FabS3.Data.Migrations
{
    public partial class updateSignoff2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_SignOffs_ToolChecklists_ChecklistId",
                table: "SignOffs");

            migrationBuilder.DropIndex(
                name: "IX_SignOffs_ChecklistId",
                table: "SignOffs");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_SignOffs_ChecklistId",
                table: "SignOffs",
                column: "ChecklistId");

            migrationBuilder.AddForeignKey(
                name: "FK_SignOffs_ToolChecklists_ChecklistId",
                table: "SignOffs",
                column: "ChecklistId",
                principalTable: "ToolChecklists",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
