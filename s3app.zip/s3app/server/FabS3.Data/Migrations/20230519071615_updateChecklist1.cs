﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace FabS3.Data.Migrations
{
    public partial class updateChecklist1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ToolChecklists_ChecklistTemplates_TemplateId",
                table: "ToolChecklists");

            migrationBuilder.DropIndex(
                name: "IX_ToolChecklists_TemplateId",
                table: "ToolChecklists");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "ToolChecklists",
                newName: "ApprovalStatus");

            migrationBuilder.RenameColumn(
                name: "ChecklistTemplateVer",
                table: "ToolChecklists",
                newName: "TemplateVer");

            migrationBuilder.AddColumn<DateTime>(
                name: "ApprovalAt",
                table: "ToolChecklists",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "ApprovalBy",
                table: "ToolChecklists",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "TemplateId",
                table: "StageChecklists",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<int>(
                name: "TemplateVer",
                table: "StageChecklists",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ApprovalAt",
                table: "ToolChecklists");

            migrationBuilder.DropColumn(
                name: "ApprovalBy",
                table: "ToolChecklists");

            migrationBuilder.DropColumn(
                name: "TemplateId",
                table: "StageChecklists");

            migrationBuilder.DropColumn(
                name: "TemplateVer",
                table: "StageChecklists");

            migrationBuilder.RenameColumn(
                name: "TemplateVer",
                table: "ToolChecklists",
                newName: "ChecklistTemplateVer");

            migrationBuilder.RenameColumn(
                name: "ApprovalStatus",
                table: "ToolChecklists",
                newName: "Name");

            migrationBuilder.CreateIndex(
                name: "IX_ToolChecklists_TemplateId",
                table: "ToolChecklists",
                column: "TemplateId");

            migrationBuilder.AddForeignKey(
                name: "FK_ToolChecklists_ChecklistTemplates_TemplateId",
                table: "ToolChecklists",
                column: "TemplateId",
                principalTable: "ChecklistTemplates",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
