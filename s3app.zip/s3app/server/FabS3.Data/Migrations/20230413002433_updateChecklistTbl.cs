﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FabS3.Data.Migrations
{
    public partial class updateChecklistTbl : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Category",
                table: "ChecklistTemplates",
                newName: "SubTitle");

            migrationBuilder.AddColumn<string>(
                name: "Applicant",
                table: "ChecklistTemplates",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ChecklistId",
                table: "ChecklistTemplates",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "FooterFields",
                table: "ChecklistTemplates",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "HeaderFields",
                table: "ChecklistTemplates",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SignOff",
                table: "ChecklistTemplates",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Applicant",
                table: "ChecklistTemplates");

            migrationBuilder.DropColumn(
                name: "ChecklistId",
                table: "ChecklistTemplates");

            migrationBuilder.DropColumn(
                name: "FooterFields",
                table: "ChecklistTemplates");

            migrationBuilder.DropColumn(
                name: "HeaderFields",
                table: "ChecklistTemplates");

            migrationBuilder.DropColumn(
                name: "SignOff",
                table: "ChecklistTemplates");

            migrationBuilder.RenameColumn(
                name: "SubTitle",
                table: "ChecklistTemplates",
                newName: "Category");
        }
    }
}
