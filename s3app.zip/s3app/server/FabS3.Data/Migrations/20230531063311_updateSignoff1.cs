﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace FabS3.Data.Migrations
{
    public partial class updateSignoff1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "EqpId",
                table: "SignOffs",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "StageId",
                table: "SignOffs",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<string>(
                name: "StageName",
                table: "SignOffs",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "StageSeq",
                table: "SignOffs",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<Guid>(
                name: "ToolId",
                table: "SignOffs",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "EqpId",
                table: "SignOffs");

            migrationBuilder.DropColumn(
                name: "StageId",
                table: "SignOffs");

            migrationBuilder.DropColumn(
                name: "StageName",
                table: "SignOffs");

            migrationBuilder.DropColumn(
                name: "StageSeq",
                table: "SignOffs");

            migrationBuilder.DropColumn(
                name: "ToolId",
                table: "SignOffs");
        }
    }
}
