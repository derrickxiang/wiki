﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace FabS3.Data.Migrations
{
    public partial class updateSignoff : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Category",
                table: "SignOffs",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Status",
                table: "SignOffs",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SubmitBy",
                table: "SignOffs",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "SubmitDate",
                table: "SignOffs",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Category",
                table: "SignOffs");

            migrationBuilder.DropColumn(
                name: "Status",
                table: "SignOffs");

            migrationBuilder.DropColumn(
                name: "SubmitBy",
                table: "SignOffs");

            migrationBuilder.DropColumn(
                name: "SubmitDate",
                table: "SignOffs");
        }
    }
}
