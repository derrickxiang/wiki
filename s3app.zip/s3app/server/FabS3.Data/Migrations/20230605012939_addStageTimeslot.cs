﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FabS3.Data.Migrations
{
    public partial class addStageTimeslot : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "BookTimeSlot",
                table: "Stages",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BookTimeSlot",
                table: "Stages");
        }
    }
}
