﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Data.Services
{
    public interface IRepositoryWrapper
    {
        IChecklistTemplateRepository ChecklistTemplate { get; }
        IChangeRepository Change { get; }
        IChecklistItemRepository ChecklistItem { get; }
        IProjectRepository Project { get; }
        IStageChecklistRepository StageChecklist { get; }
        IStageRepository Stage { get; }
        IToolStageRepository ToolStage { get;  }
        IToolRepository Tool { get; }
        IToolChecklistRepository ToolChecklist { get;  }
        IToolChecklistItemRepository ToolChecklistItem { get;  }
        IUserTxnRepository UserTxn { get; }
    }
}
