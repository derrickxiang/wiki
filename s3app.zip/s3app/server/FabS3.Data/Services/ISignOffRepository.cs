﻿using FabS3.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Data.Services
{
    public interface ISignOffRepository : IRepositoryBase<SignOff>, IRepositoryBase2<SignOff, Guid>
    {
    }

    public interface ISignOffGroupRepository: IRepositoryBase<SignOffGroup>, IRepositoryBase2<SignOffGroup, Guid>
    {

    }
}
