﻿using FabS3.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Data.Services
{
    public interface IChecklistTemplateRepository : IRepositoryBase<ChecklistTemplate>, IRepositoryBase2<ChecklistTemplate, Guid>
    {
    }

    public interface IChecklistItemRepository : IRepositoryBase<ChecklistItem>, IRepositoryBase2<ChecklistItem, Guid>
    {

    }

    public interface IToolChecklistRepository : IRepositoryBase<ToolChecklist>, IRepositoryBase2<ToolChecklist, Guid>
    {

    }

    public interface IToolChecklistItemRepository : IRepositoryBase<ToolChecklistItem>, IRepositoryBase2<ToolChecklistItem, Guid>
    {

    }
}
