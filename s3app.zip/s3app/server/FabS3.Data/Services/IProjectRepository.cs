﻿using FabS3.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Data.Services
{
    public interface IProjectRepository : IRepositoryBase<Project>, IRepositoryBase2<Project, Guid>
    {
        public void ClearProjectDefault();
    }
}
