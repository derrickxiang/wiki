﻿using FabS3.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Data.Services
{
    public interface IToolRepository : IRepositoryBase<Tool>, IRepositoryBase2<Tool, Guid>
    {

    }
}
