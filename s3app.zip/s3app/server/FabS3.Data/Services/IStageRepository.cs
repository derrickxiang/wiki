﻿using FabS3.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Data.Services
{
    public interface IStageRepository : IRepositoryBase<Stage>, IRepositoryBase2<Stage, Guid>
    {
    }

    public interface IStageChecklistRepository : IRepositoryBase<StageChecklist>, IRepositoryBase2<StageChecklist, Guid>
    {

    }

    public interface IToolStageRepository : IRepositoryBase<ToolStage>, IRepositoryBase2<ToolStage, Guid>
    {
        public Task<IEnumerable<ToolStage>> GetToolStagesAsync();
        public void InitToolStagesAsync(Guid toolId);

        public Task<Stage> GetNextStageAsync(Guid currentStageId);
    }
}
