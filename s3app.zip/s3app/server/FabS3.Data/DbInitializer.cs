﻿using FabS3.Domain;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Data
{
    public static class DbInitializer
    {
        public static async Task Initialize(S3Context context,
            UserManager<AppUser> userManager,
            RoleManager<AppRole> roleManager,
            ILogger logger)
        {
            if (!roleManager.Roles.Any())
            {
                var roles = new String[] { "Admin", "Committee", "User" };

                foreach (var roleName in roles)
                {

                    var result = await roleManager.CreateAsync(new AppRole { Name = roleName });

                    logger.LogDebug("Create role {0}: {1}", roleName, result.Succeeded);

                }
            }

            if (!context.SignOffGroups.Any())
            {
                var groups = new List<SignOffGroup>
                {
                    new SignOffGroup { Name="IE"},
                    new SignOffGroup { Name="IT"},
                    new SignOffGroup { Name="EQ"},
                    new SignOffGroup { Name="ESH"},
                    new SignOffGroup { Name="FOC"},
                    new SignOffGroup { Name="PE"},
                    new SignOffGroup { Name="QA"}
                };

                await context.SignOffGroups.AddRangeAsync(groups);
                await context.SaveChangesAsync();

                logger.LogDebug("Sign off groups init done.");
            }

            //if (!userManager.Users.Any())
            //{
            //    var users = new List<AppUser>
            //    {
            //        new AppUser
            //        {
            //            EmpId = "00072289",
            //            UserName = "Derrick",
            //            Email = "Derrick_xiang@umc.com"
            //        },
            //        new AppUser
            //        {
            //            EmpId = "00070001",
            //            UserName = "John",
            //            Email = "John@umc.com"
            //        }
            //    };

            //    foreach (var user in users)
            //    {
            //        var result = await userManager.CreateAsync(user, "Skynet001");

            //        if (!result.Succeeded)
            //        {
            //            Console.Out.WriteLine("Problem creating user account");

            //        }
            //        await userManager.AddToRolesAsync(user, new[] { "Admin", "User" });
            //    }

            //}
        }
    }
}
