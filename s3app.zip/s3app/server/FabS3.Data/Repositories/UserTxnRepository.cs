﻿using FabS3.Data.Services;
using FabS3.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Data.Repositories
{
    public class UserTxnRepository : RepositoryBase<UserTxn, Guid>, IUserTxnRepository
    {
        public UserTxnRepository(S3Context s3Context) : base(s3Context)
        {
        }
    }
}
