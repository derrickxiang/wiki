﻿using FabS3.Data.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Data.Repositories
{
    public class RepositoryBase<T, TId> : IRepositoryBase<T>, IRepositoryBase2<T, TId> where T: class
    {
        public S3Context S3Context { get; set;  }
        public RepositoryBase(S3Context s3Context)
        {
            S3Context = s3Context;
        }

        public void Create(T entity)
        {
            S3Context.Set<T>().Add(entity);
        }

        public void Delete(T entity)
        {
            S3Context.Set<T>().Remove(entity);
        }

        public void Update(T entity)
        {
            S3Context.Set<T>().Update(entity);
        }

        public Task<IEnumerable<T>> GetAllAsync()
        {
            return Task.FromResult(S3Context.Set<T>().AsEnumerable());
        }

        public Task<IEnumerable<T>> GetByConditionAsync(Expression<Func<T, bool>> expression)
        {
            return Task.FromResult(S3Context.Set<T>().Where(expression).AsEnumerable());
        }

        public async Task<bool> SaveAsync()
        {
            return await S3Context.SaveChangesAsync() > 0;
        }

        public async Task<T> GetByIdAsync(TId id)
        {
            return await S3Context.Set<T>().FindAsync(id);
        }

        public async Task<bool> IsExistAsync(TId id)
        {
            return await S3Context.Set<T>().FindAsync(id) != null;
        }
    }
}
