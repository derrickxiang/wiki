﻿using FabS3.Data.Services;
using FabS3.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Data.Repositories
{
    public class StageRepository : RepositoryBase<Stage, Guid>, IStageRepository
    {
        public StageRepository(S3Context s3Context) : base(s3Context)
        {
        }
    }

    public class ToolStageRepository : RepositoryBase<ToolStage, Guid>, IToolStageRepository
    {
        public ToolStageRepository(S3Context s3Context) : base(s3Context)
        {
        }


        public async Task<IEnumerable<ToolStage>> GetToolStagesAsync()
        {
            return await Task.FromResult<IEnumerable<ToolStage>>(S3Context.Set<ToolStage>()
                            .Include("Tool")
                            .Include("Stage")
                            .AsEnumerable());
        }

        public async void InitToolStagesAsync(Guid toolId)
        {
            var tool = await S3Context.Set<Tool>().FindAsync(toolId);

            if (tool == null) return;

            await S3Context.Set<Stage>().ForEachAsync(s =>
            {
                ToolStage toolStage = new ToolStage();
                toolStage.ToolId = toolId;
                toolStage.StageId = s.Id;
                toolStage.LeadTime = s.LeadTime;
                toolStage.Status = "Init";

                S3Context.ToolStages.AddAsync(toolStage);
            });

            var result = await S3Context.SaveChangesAsync();

           
        }
    }

    public class StageChecklistRepository : RepositoryBase<StageChecklist, Guid>, IStageChecklistRepository
    {
        public StageChecklistRepository(S3Context s3Context) : base(s3Context)
        {

        }
    }
}
