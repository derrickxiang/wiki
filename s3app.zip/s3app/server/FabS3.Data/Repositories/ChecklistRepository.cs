﻿using FabS3.Data.Services;
using FabS3.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Data.Repositories
{
    public class ChecklistTemplateRepository : RepositoryBase<ChecklistTemplate, Guid>, IChecklistTemplateRepository
    {
        public ChecklistTemplateRepository(S3Context s3Context) : base(s3Context)
        {
        }
    }

    public class ChecklistItemRepository : RepositoryBase<ChecklistItem, Guid>, IChecklistItemRepository
    {
        public ChecklistItemRepository(S3Context s3Context) : base(s3Context)
        {
        }
    }

    public class ToolChecklistItemRepository : RepositoryBase<ToolChecklistItem, Guid>, IToolChecklistItemRepository
    {
        public ToolChecklistItemRepository(S3Context s3Context) : base(s3Context)
        {
        }
    }

    public class ToolChecklistRepository : RepositoryBase<ToolChecklist, Guid>, IToolChecklistRepository
    {
        public ToolChecklistRepository(S3Context s3Context) : base(s3Context)
        {
        }
    }
}
