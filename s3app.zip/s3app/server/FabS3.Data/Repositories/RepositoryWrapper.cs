﻿using FabS3.Data.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Data.Repositories
{
    public class RepositoryWrapper : IRepositoryWrapper
    {
        private IChangeRepository _change = null;
        private IChecklistTemplateRepository _checklistTemplate = null;
        private IChecklistItemRepository _checklistItem = null;
        private IProjectRepository _projectRepository = null;
        private IStageChecklistRepository _stageChecklistRepository = null;
        private IStageRepository _stageRepository = null;
        private IToolStageRepository _toolStageRepository = null;
        private IToolRepository _toolRepository = null;
        private IToolChecklistRepository _toolChecklist = null;
        private IToolChecklistItemRepository _toolChecklistItem = null;
        private IUserTxnRepository _userTxnRepository = null;

        public RepositoryWrapper(S3Context myContext)
        {
            s3Context = myContext;
        }

        public IChangeRepository Change => _change ?? new ChangeRepository(s3Context);
        public IChecklistTemplateRepository ChecklistTemplate => _checklistTemplate ?? new ChecklistTemplateRepository(s3Context);
        public IChecklistItemRepository ChecklistItem => _checklistItem ?? new ChecklistItemRepository(s3Context);
        public IProjectRepository Project => _projectRepository ?? new ProjectRepository(s3Context);
        public IStageRepository Stage => _stageRepository ?? new StageRepository(s3Context);
        public IStageChecklistRepository StageChecklist => _stageChecklistRepository ?? new StageChecklistRepository(s3Context);
        public IToolStageRepository ToolStage => _toolStageRepository ?? new ToolStageRepository(s3Context);
        public IToolRepository Tool => _toolRepository ?? new ToolRepository(s3Context);
        public IToolChecklistRepository ToolChecklist => _toolChecklist ?? new ToolChecklistRepository(s3Context);
        public IToolChecklistItemRepository ToolChecklistItem => _toolChecklistItem ?? new ToolChecklistItemRepository(s3Context);
        public IUserTxnRepository UserTxn => _userTxnRepository ?? new UserTxnRepository(s3Context);

        public S3Context s3Context { get; }
    }
}
