﻿using FabS3.Data.Services;
using FabS3.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Data.Repositories
{
    public class ProjectRepository : RepositoryBase<Project, Guid>, IProjectRepository
    {
        public ProjectRepository(S3Context s3Context) : base(s3Context)
        {
        }

        public void ClearProjectDefault()
        {
            var proj = S3Context.Set<Project>().Where(p => p.IsDefault).FirstOrDefault();

            if (proj != null)
            {
                proj.IsDefault = false;
                S3Context.Set<Project>().Update(proj);
            }
        }
    }
}
