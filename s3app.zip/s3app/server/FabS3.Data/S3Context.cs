﻿using FabS3.Domain;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabS3.Data
{
    public class S3Context : IdentityDbContext<AppUser, AppRole, string>
    {
        public S3Context(DbContextOptions options): base(options)
        {

        }

        public DbSet<Change> Changes { get; set; }
        public DbSet<ChecklistItem> ChecklistItems { get; set; }
        public DbSet<ChecklistTemplate> ChecklistTemplates { get; set; }
        public DbSet<Project> Projects { get; set; }
        public DbSet<RefreshToken> RefreshTokens { get; set; }
        public DbSet<SignOff> SignOffs { get; set; }
        public DbSet<Stage> Stages { get; set; }
        public DbSet<StageChecklist> StageChecklists { get; set; }
        public DbSet<Tool> Tools { get; set; }
        public DbSet<ToolChecklist> ToolChecklists { get; set; }
        public DbSet<ToolChecklistItem> ToolChecklistItems { get; set; }
        public DbSet<ToolStage> ToolStages { get; set; }
        public DbSet<UserTxn> UserTxns { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }
    }
}
