﻿using System;

namespace FabS3.Application
{
    public class Class1
    {
    }
}
