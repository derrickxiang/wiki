﻿using FabS3.Data;
using FabS3.Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FabS3.Application.Account
{
    public class AdminList
    {
        public class Query : IRequest<Result<List<AppUser>>>
        {

        }

        public class Handler : IRequestHandler<Query, Result<List<AppUser>>>
        {
            private readonly S3Context _context;

            public Handler(S3Context context)
            {
                _context = context;
            }

            public async Task<Result<List<AppUser>>> Handle(Query request, CancellationToken cancellationToken)
            {
                try
                {
                    var sql = @"SELECT anu.EmpId, anu.Dept, anu.Name
                                  FROM [AspNetUserRoles] anur
                                  JOIN AspNetUsers anu
                                  ON anu.Id = anur.UserId
                                  JOIN AspNetRoles anr
                                  ON anur.RoleId = anr.Id
                                  WHERE anr.Name = 'Admin'
                                  ORDER BY anu.EmpId";

                    using (var command = _context.Database.GetDbConnection().CreateCommand())
                    {
                        command.CommandText = sql;
                        command.CommandType = System.Data.CommandType.Text;

                        _context.Database.OpenConnection();

                        using (var res = await command.ExecuteReaderAsync())
                        {
                            List<AppUser> users = new List<AppUser>();

                            while (res.Read())
                            {
                                AppUser user = new AppUser();

                                user.EmpId = res.GetString("EmpId");
                                user.Name = res.GetString("Name");
                                user.Dept = res.GetString("Dept");

                                users.Add(user);
                            }

                            return Result<List<AppUser>>.Success(value: users);
                        }
                    }

                }
                catch (Exception ex)
                {

                    return Result<List<AppUser>>.Failure("Failed to fetch admin users.");
                }
            }
        }
    }
}
