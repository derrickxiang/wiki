﻿using FabS3.Data;
using FabS3.Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FabS3.Application.Account
{
    public class Detail
    {
        public class Query : IRequest<Result<AppUser>>
        {
            public string EmpId { get; set; }
        }

        public class Handler : IRequestHandler<Query, Result<AppUser>>
        {
            private readonly S3Context _context;

            public Handler(S3Context context)
            {
                _context = context;
            }

            public async Task<Result<AppUser>> Handle(Query request, CancellationToken cancellationToken)
            {
                try
                {
                    var user = await _context.Users.FindAsync(request.EmpId);

                    if (user == null)
                    {
                        //string query = @"select e.ID as Id, e.[Name] as UserName, e.Email, ID as EmpId, e.[Name], e.Dept, e.Section, e.UsrLevel as [Level],
                        //        [NormalizedUserName],[NormalizedEmail],[EmailConfirmed],[PasswordHash],[SecurityStamp],[ConcurrencyStamp],[PhoneNumber]
                        //          ,[PhoneNumberConfirmed],[TwoFactorEnabled],[LockoutEnd],[LockoutEnabled],[AccessFailedCount],[Ext],[MgrId]
                        //        from F12IESIMSDB.WEB.dbo.EQD_Users e left outer join dbo.AspNetUsers u
                        //     on e.ID = u.Id collate Chinese_Taiwan_Stroke_CS_AS
                        //         where ID = '{0}' and Status = 'Y'";

                        string query = @"SELECT e.EMPNO AS Id, e.ENAME AS UserName, e.EMAIL AS Email, e.EMPNO AS EmpId, e.ENAME AS Name, e.DEPT_1 AS Division, e.DEPT_2 AS Dept, e.DEPT_3 AS Section, e.LEVELS AS Level,
                                [NormalizedUserName],[NormalizedEmail],[EmailConfirmed],[PasswordHash],[SecurityStamp],[ConcurrencyStamp],[PhoneNumber]
                                  ,[PhoneNumberConfirmed],[TwoFactorEnabled],[LockoutEnd],[LockoutEnabled],[AccessFailedCount],[Ext],[MgrId]
                                FROM OPENQUERY(UEDA, 'select * from notes_person@sdb where dept_1 in (''12i_Fab1'', ''12i_Fab2'', ''FOC'', ''GRM&ESH'',''OP'',''QA'',''IT'') 
                                and  status = ''Y'' and empno like ''000%''') e left outer join dbo.AspNetUsers u
	                            on e.EMPNO = u.Id  where EMPNO = '{0}'";

                        query = String.Format(query, request.EmpId);

                        using (var command = _context.Database.GetDbConnection().CreateCommand())
                        {
                            command.CommandText = query;
                            command.CommandType = System.Data.CommandType.Text;

                            _context.Database.OpenConnection();

                            using (var result = command.ExecuteReader())
                            {
                                user = new AppUser();

                                if (result.Read())
                                {
                                    user.Id = result.GetString("Id");
                                    user.Name = result.GetString("Name");
                                    user.UserName = result.GetString("EmpId");
                                    user.Email = result.GetString("Email");
                                    user.Level = result.GetString("Level");
                                    user.Division = result.GetString("Division");
                                    user.Dept = result.GetString("Dept");
                                    user.Section = (result["Section"] != DBNull.Value) ? result.GetString("Section") : "";
                                    user.EmpId = result.GetString("EmpId");
                                    user.NormalizedUserName = user.Name.ToUpper();
                                    user.NormalizedEmail = user.Email.ToUpper();
                                }
                                else
                                {
                                    return Result<AppUser>.Failure("User not found.");
                                }
                            }
                        }

                        await _context.Users.AddAsync(user);

                        await _context.SaveChangesAsync();
                    }

                    return Result<AppUser>.Success(value: user);
                }
                catch (Exception ex)
                {
                    return Result<AppUser>.Failure("Failed to login, please contact ESI support @8771.");
                }
            }
        }
    }
}
