﻿using FabS3.Data;
using FabS3.Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FabS3.Application.Account
{
    public class UserTxns
    {
        public class Query : IRequest<Result<List<UserTxn>>>
        {
            public string UserId { get; set; }
        }

        public class Create : IRequest<Result<UserTxn>>
        {
            public UserTxn newTxn { get; set; }
        }

        public class Handler : IRequestHandler<Query, Result<List<UserTxn>>>
        {
            private readonly S3Context _context;

            public Handler(S3Context context)
            {
                this._context = context;
            }

            public async Task<Result<List<UserTxn>>> Handle(Query request, CancellationToken cancellationToken)
            {
                var results = await _context.UserTxns.Where(a => a.UserId == request.UserId).ToListAsync();

                return Result<List<UserTxn>>.Success(value: results);

            }
        }

        public class CreateHandler : IRequestHandler<Create, Result<UserTxn>>
        {
            private readonly S3Context _context;

            public CreateHandler(S3Context context)
            {
                this._context = context;
            }

            public async Task<Result<UserTxn>> Handle(Create request, CancellationToken cancellationToken)
            {
                var txn = request.newTxn;

                if (txn != null && !String.IsNullOrEmpty(txn.UserId))
                {
                    _context.UserTxns.Add(txn);

                    var success = await _context.SaveChangesAsync() > 0;

                    if (success) return Result<UserTxn>.Success(value: txn);
                }

                return Result<UserTxn>.Failure("Fail to add user txn.");
            }
        }
    }
}
