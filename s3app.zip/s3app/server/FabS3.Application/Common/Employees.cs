﻿using FabS3.Data;
using FabS3.Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FabS3.Application.Common
{
    public class Employees
    {
        public class Query : IRequest<Result<List<Node>>>
        {
            public string Division { get; set; }
        }

        public class QueryDept : IRequest<Result<List<Node>>>
        {
            public string Dept { get; set; }
        }

        public class Handler : IRequestHandler<Query, Result<List<Node>>>
        {
            private readonly S3Context _context;

            public Handler(S3Context context)
            {
                _context = context;
            }

            public async Task<Result<List<Node>>> Handle(Query request, CancellationToken cancellationToken)
            {
                try
                {
                    List<Node> results = new List<Node>();


                    string query = @"SELECT DEPT_1, DEPT_2, DEPT_3, EMPNO, ENAME
            FROM OPENQUERY(UEDA, 'select distinct dept_1, dept_2, dept_3, EMPNO, ENAME from notes_person@sdb where dept_1 = ''{0}'' 
                                and  status = ''Y'' and empno like ''0007%''') e ORDER BY 1,2,3,4";

                    query = String.Format(query, request.Division);

                    using (var command = _context.Database.GetDbConnection().CreateCommand())
                    {
                        command.CommandText = query;
                        command.CommandType = System.Data.CommandType.Text;

                        _context.Database.OpenConnection();

                        using (var result = command.ExecuteReader())
                        {

                            string division = "", dept = "", section = "";
                            Node node = new Node();
                            Node node2 = new Node();
                            Node node3 = new Node();
                            Node node4 = new Node();

                            while (result.Read())
                            {
                                var dept_1 = result.GetString("DEPT_1");
                                var empId = result.GetString("EMPNO");
                                var empName = result.GetString("ENAME");


                                if (division == "")
                                {
                                    //1st time
                                    node = new Node();

                                    node.Title = dept_1;
                                    node.Value = dept_1;

                                    division = dept_1;
                                }

                                // check if got dept
                                if (result["DEPT_2"] != DBNull.Value)
                                {
                                    var dept_2 = result.GetString("DEPT_2");

                                    // for 1st time
                                    if (dept == "")
                                    {
                                        node2 = new Node();

                                        node2.Title = dept_2;
                                        node2.Value = division + "/" + dept_2;
                                        dept = dept_2;
                                    }

                                    if (dept != dept_2)
                                    {
                                        if (node.Children == null)
                                        {
                                            node.Children = new List<Node>();
                                        }

                                        node.Children.Add(node2);
                                        node2 = new Node();

                                        node2.Title = dept_2;
                                        node2.Value = division + "/" + dept_2;

                                        dept = dept_2;
                                    }

                                    // check if got section
                                    if (result["DEPT_3"] != DBNull.Value)
                                    {
                                        var dept_3 = result.GetString("DEPT_3");

                                        // for 1st time
                                        if (section == "")
                                        {
                                            node3 = new Node();

                                            node3.Title = dept_3;
                                            node3.Value = division + "/" + dept_2 + "/" + dept_3;
                                            section = dept_3;
                                        }

                                        if (section != dept_3)
                                        {
                                            if (node2.Children == null)
                                            {
                                                node2.Children = new List<Node>();
                                            }

                                            node2.Children.Add(node3);

                                            node3 = new Node();

                                            node3.Title = dept_3;
                                            node3.Value = division + "/" + dept + "/" + dept_3;
                                        }

                                    } else
                                    {
                                        node3 = null;
                                    }

                                    node4 = new Node();
                                    node4.Title = empName;
                                    node4.Value = empId;

                                    if (node3 != null)
                                    {
                                        if (node3.Children == null)
                                        {
                                            node3.Children = new List<Node>();
                                        }

                                        node3.Children.Add(node4);
                                    }
                                    else if (node2 != null)
                                    {
                                        if (node2.Children == null)
                                        {
                                            node2.Children = new List<Node>();
                                        }
                                        node2.Children.Add(node4);
                                    }
                                }

                                if (division != dept_1)
                                {

                                    if (node != null)
                                    {
                                        results.Add(node);
                                    }

                                    node = new Node();

                                    node.Title = dept_1;
                                    node.Value = dept_1;

                                    division = dept_1;

                                }

                            }

                            if (node != null)
                            {
                                results.Add(node);
                            }

                        }
                    }


                    return Result<List<Node>>.Success(value: results);
                }
                catch (Exception ex)
                {
                    return Result<List<Node>>.Failure("Failed to get the section list.");
                }
            }
        }

        public class DeptHandler : IRequestHandler<QueryDept, Result<List<Node>>>
        {
            private readonly S3Context _context;

            public DeptHandler(S3Context context)
            {
                _context = context;
            }

            public async Task<Result<List<Node>>> Handle(QueryDept request, CancellationToken cancellationToken)
            {
                try
                {
                    List<Node> results = new List<Node>();


                    string query = @"SELECT EMPNO, ENAME
            FROM OPENQUERY(UEDA, 'select distinct EMPNO, ENAME from notes_person@sdb where deptname = ''{0}'' 
                                and  status = ''Y'' and empno like ''0007%''') e ORDER BY 1,2";

                    query = String.Format(query, request.Dept);

                    using (var command = _context.Database.GetDbConnection().CreateCommand())
                    {
                        command.CommandText = query;
                        command.CommandType = System.Data.CommandType.Text;

                        _context.Database.OpenConnection();

                        using (var result = command.ExecuteReader())
                        {

                            while (result.Read())
                            {
                                Node node = new Node();
                                var empId = result.GetString("EMPNO");
                                var empName = result.GetString("ENAME");

                                node.Title = empName;
                                node.Value = empId;

                                results.Add(node);

                            }

                        }
                    }


                    return Result<List<Node>>.Success(value: results);
                }
                catch (Exception ex)
                {
                    return Result<List<Node>>.Failure("Failed to get the section list.");
                }
            }
        }
    }
}
