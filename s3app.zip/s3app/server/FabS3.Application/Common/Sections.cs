﻿using FabS3.Data;
using FabS3.Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FabS3.Application.Common
{
    public class Sections
    {
        public class Query: IRequest<Result<List<Node>>>
        {
            
        }

        public class EqQuery: IRequest<Result<List<Node>>> { }

        public class Handler : IRequestHandler<Query, Result<List<Node>>>
        {
            private readonly S3Context _context;

            public Handler(S3Context context)
            {
                _context = context;
            }

            public async Task<Result<List<Node>>> Handle(Query request, CancellationToken cancellationToken)
            {
                try
                {
                    List<Node> results = new List<Node>();

                   
                        string query = @"SELECT DEPT_1, DEPT_2, DEPT_3
                                FROM OPENQUERY(UEDA, 'select distinct dept_1, dept_2, dept_3 from notes_person@sdb where dept_1 in (''12i_Fab1'', ''12i_Fab2'', ''FOC'', ''GRM&ESH'',''OP'',''QA'') 
                                and  status = ''Y'' and empno like ''0007%''') e ORDER BY 1,2,3";


                    using (var command = _context.Database.GetDbConnection().CreateCommand())
                    {
                        command.CommandText = query;
                        command.CommandType = System.Data.CommandType.Text;

                        _context.Database.OpenConnection();

                        using (var result = command.ExecuteReader())
                        {

                            string division = "", dept = "";
                            Node node = new Node();
                            Node node2 = new Node();
                            Node node3 = new Node();

                            while (result.Read())
                            {
                                var dept_1 = result.GetString("DEPT_1");

                                if (division == "")
                                {
                                    //1st time
                                    node = new Node();

                                    node.Title = dept_1;
                                    node.Value = dept_1;

                                    division = dept_1;
                                }

                                // check if got dept
                                if (result["DEPT_2"] != DBNull.Value)
                                {
                                    var dept_2 = result.GetString("DEPT_2");

                                    // for 1st time
                                    if (dept == "")
                                    {
                                        node2 = new Node();

                                        node2.Title = dept_2;
                                        node2.Value = division + "/" + dept_2;
                                        dept = dept_2;
                                    }

                                    if (dept != dept_2)
                                    {
                                        if (node.Children == null)
                                        {
                                            node.Children = new List<Node>();
                                        }

                                        node.Children.Add(node2);
                                        node2 = new Node();

                                        node2.Title = dept_2;
                                        node2.Value = division + "/" + dept_2;

                                        dept = dept_2;
                                    }

                                    // check if got section
                                    if (result["DEPT_3"] != DBNull.Value)
                                    {
                                        var dept_3 = result.GetString("DEPT_3");

                                        node3 = new Node();

                                        node3.Title = dept_3;
                                        node3.Value = division + "/" + dept + "/" + dept_3;

                                        if (node2.Children == null)
                                        {
                                            node2.Children = new List<Node>();
                                        }

                                        node2.Children.Add(node3);

                                    }

                                   
                                }

                                if (division != dept_1)
                                {

                                    if (node != null)
                                    {
                                        results.Add(node);
                                    }

                                    node = new Node();

                                    node.Title = dept_1;
                                    node.Value = dept_1;

                                    division = dept_1;

                                }

                            }

                            if (node != null)
                            {
                                results.Add(node);
                            }

                        }
                    }


                    return Result<List<Node>>.Success(value: results);
                }
                catch (Exception ex)
                {
                    return Result<List<Node>>.Failure("Failed to get the section list.");
                }
            }
        }

        public class EqHandler : IRequestHandler<EqQuery, Result<List<Node>>>
        {
            private readonly S3Context _context;

            public EqHandler(S3Context context)
            {
                _context = context;
            }

            public async Task<Result<List<Node>>> Handle(EqQuery request, CancellationToken cancellationToken)
            {
                try
                {
                    List<Node> results = new List<Node>();


                    string query = @"SELECT DISTINCT Area,t.Section
                                FROM S3Data.dbo.Tools t
                                ORDER BY 1, 2";


                    using (var command = _context.Database.GetDbConnection().CreateCommand())
                    {
                        command.CommandText = query;
                        command.CommandType = System.Data.CommandType.Text;

                        _context.Database.OpenConnection();

                        using (var result = command.ExecuteReader())
                        {

                            string division = "", dept = "";
                            Node node = new Node();
                            Node node2 = new Node();
                            Node node3 = new Node();

                            while (result.Read())
                            {
                                var dept_1 = result.GetString("Area");

                                if (division == "")
                                {
                                    //1st time
                                    node = new Node();

                                    node.Title = dept_1;
                                    node.Value = dept_1;

                                    division = dept_1;
                                }

                                // check if got dept
                                if (result["Section"] != DBNull.Value)
                                {
                                    var dept_2 = result.GetString("Section");

                                    // for 1st time
                                    if (dept == "")
                                    {
                                        node2 = new Node();

                                        node2.Title = dept_2;
                                        node2.Value = division + "/" + dept_2;
                                        dept = dept_2;
                                    }

                                    if (dept != dept_2)
                                    {
                                        if (node.Children == null)
                                        {
                                            node.Children = new List<Node>();
                                        }

                                        node.Children.Add(node2);
                                        node2 = new Node();

                                        node2.Title = dept_2;
                                        node2.Value = division + "/" + dept_2;

                                        dept = dept_2;
                                    }

                                }

                                if (division != dept_1)
                                {

                                    if (node != null)
                                    {
                                        results.Add(node);
                                    }

                                    node = new Node();

                                    node.Title = dept_1;
                                    node.Value = dept_1;

                                    division = dept_1;

                                }

                            }

                            if (node != null)
                            {
                                results.Add(node);
                            }

                        }
                    }


                    return Result<List<Node>>.Success(value: results);
                }
                catch (Exception ex)
                {
                    return Result<List<Node>>.Failure("Failed to get the eq section list.");
                }
            }
        }
    }
}
