﻿/**
 * @name umi 的路由配置
 * @description 只支持 path,component,routes,redirect,wrappers,name,icon 的配置
 * @param path  path 只支持两种占位符配置，第一种是动态参数 :id 的形式，第二种是 * 通配符，通配符只能出现路由字符串的最后。
 * @param component 配置 location 和 path 匹配后用于渲染的 React 组件路径。可以是绝对路径，也可以是相对路径，如果是相对路径，会从 src/pages 开始找起。
 * @param routes 配置子路由，通常在需要为多个路径增加 layout 组件时使用。
 * @param redirect 配置路由跳转
 * @param wrappers 配置路由组件的包装组件，通过包装组件可以为当前的路由组件组合进更多的功能。 比如，可以用于路由级别的权限校验
 * @param name 配置路由的标题，默认读取国际化文件 menu.ts 中 menu.xxxx 的值，如配置 name 为 login，则读取 menu.ts 中 menu.login 的取值作为标题
 * @param icon 配置路由的图标，取值参考 https://ant.design/components/icon-cn， 注意去除风格后缀和大小写，如想要配置图标为 <StepBackwardOutlined /> 则取值应为 stepBackward 或 StepBackward，如想要配置图标为 <UserOutlined /> 则取值应为 user 或者 User
 * @doc https://umijs.org/docs/guides/routes
 */
export default [  
  {
    path: '/user',
    layout: false,
    routes: [
      {
        name: 'login',
        path: '/user/login',
        component: './User/Login',
      },
    ],
  },
  {
    path: '/account',
    routes: [
      // {
      //   name: 'User Center',
      //   path: '/account/center',
      //   component: './account/center',
      // },
      {
        path: '/account',
        redirect: '/account/settings',
      },
      {
        name: 'User Settings',
        path: '/account/settings',
        icon: 'user',
        component: './account/setting',
      },
    ],
  },
  {
    path: '/dashboard',
    name: 'Dashboard',
    icon: 'dashboard',
    component: './dashboard',
  },
  {
    path: '/setup',
    name: 'Setup',
    icon: 'unorderedList',
    routes: [
      {
        path: '/setup',
        redirect: '/setup/project',
      },
      {
        name: 'Project Setup',
        icon: 'project',
        path: '/setup/project',
        component: './setup/project',
      },
      {
        name: 'Stage Setup',
        icon: 'link',
        path: '/setup/stage',
        routes: [
          {
            path: '/setup/stage',
            redirect: '/setup/stage/list',
          },
          {
            name: 'Stage Setup',
            icon: 'link',
            path: '/setup/stage/list',
            component: './setup/stage',
          },
          {
            name: 'Stage Checklist Setup',
            icon: 'link',
            path: '/setup/stage/checklist',
            component: './setup/stageChecklist'
          },
        ],
      },
      {
        name: 'Tool Setup',
        icon: 'deploymentUnit',
        path: '/setup/tool',
        routes: [
          {
            path: '/setup/tool',
            redirect: '/setup/tool/list',
          },
          {
            name: 'Tool Data Init',
            icon: 'deploymentUnit',
            path: '/setup/tool/list',
            component: './setup/tool',
          },
          {
            name: 'Tool Data Import',
            icon: 'deploymentUnit',
            path: '/setup/tool/import',
            component: './setup/tool/import',
          },
          {
            path: '/setup/tool/stage',
            name: 'Tool Stage Setup',
            component: './setup/toolStage',
          },
        ]
      },
      {
        name: 'Checklist Setup',
        icon: 'checkSquare',
        path: '/setup/checklist',
        routes: [
          {
            path: '/setup/checklist',
            redirect: '/setup/checklist/template'
          },
          {
            name: 'Checklist Template',
            icon: 'checkSquare',
            path: '/setup/checklist/template',
            component: './setup/checklist',  
          },
          {
            path: '/setup/checklist/import',
            name: 'Checklist Import',
            component: './setup/import',
            icon: 'import',
          },
        ]     
      },
      
    ],
  },
  {
    path: '/plan',
    name: 'Plan',
    icon: 'appstore',
    routes: [
      {
        path: '/plan',
        redirect: '/plan/keydates'
      },
      {
        name: 'Key Dates Update',
        icon: 'calendar',
        path: '/plan/keydates',
        component: './plan/keydates',
      },
    ]
  },
  {
    path: '/execute',
    name: 'Complete',
    icon: 'control',
    routes: [
      {
        path: '/execute',
        redirect: '/execute/checklist',
      },
      
      {
        name: 'Checklist Update',
        icon: 'check',
        path: '/execute/checklist',
        component: './execute/checklist',
      },
    ],
  },  
  {
    path: '/admin',
    name: 'Sign Off',
    icon: 'audit',
    access: 'canAdmin',
    routes: [
      {
        path: '/admin',
        redirect: '/admin/request',
      },
      {
        path: '/admin/request',
        name: 'Pending Requests',
        component: './admin/request',
        icon: 'orderedList',
      },
      
    ],
  },
  {
    path: '/report',
    name: 'Report',
    icon: 'fundView',
    routes: [
      {
        path: '/report/calendar',
        name: 'Event Calendar',
        icon: 'schedule',
      },
      {
        path: '/report/masterPlan',
        name: 'Master Plan',
        icon: 'carryOut',
      },
      {
        path: '/report/tool',
        name: 'Tool Query',
        icon: 'retweet',
      },
      {
        path: '/report',
        redirect: '/report/calendar',
      }
    ]
  }, 
  {
    path: '/',
    redirect: '/dashboard',
  },
  {
    path: '*',
    layout: false,
    component: './404',
  },
];
