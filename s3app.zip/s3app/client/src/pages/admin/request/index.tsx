import { PageContainer } from "@ant-design/pro-components"

const PendingRequest = () => {

    return (
        <PageContainer
      header={{
        title: 'Pending Requests',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'admin',
              title: 'Admin',
            },
            {
              path: '',
              title: 'Pending Requests',
            },
          ],
        },
      }}
      content={'Pending request list for your review'}
    ></PageContainer>
    )


}

export default PendingRequest;