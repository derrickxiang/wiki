import { PageContainer } from "@ant-design/pro-components"
import ChecklistRequest from "./components/ChecklistRequest";
import RequestList from "./components/RequestList";

const PendingRequest = () => {

    return (
        <PageContainer
      header={{
        title: 'Pending Requests',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'admin',
              title: 'Sign Off',
            },
            {
              path: '',
              title: 'Pending Requests',
            },
          ],
        },
      }}
      content={'Pending request list for your review'}
      tabList={
        [
          {
            tab: 'Stage Completion Request',
            key: 'stageComplete',
            children: (
              <>
              <RequestList />
              </>
            )
          },
          {
          tab: 'Checklist Form Request',
          key: 'toolChecklist',
          children: (
            <>
            <ChecklistRequest />
            </>
          )
        },

        ]
      }
    ></PageContainer>
    )


}

export default PendingRequest;