import { toolChecklistsByToolId } from '@/pages/execute/checklist/services';
import { Stage } from '@/pages/setup/stage/data';
import { stages } from '@/pages/setup/stage/services';
import { StageChecklist } from '@/pages/setup/stageChecklist/data';
import { Tool } from '@/pages/setup/tool/data';
import { nextStage, tools } from '@/pages/setup/tool/services';
import { ToolStage } from '@/pages/setup/toolStage/data';
import { toolStages, updateToolStage } from '@/pages/setup/toolStage/services';
import { addUserTxn } from '@/services/ant-design-pro/api';
import { ProColumns, ProList, ProTable, useToken } from '@ant-design/pro-components';
import { history, useAccess, useModel, useRequest } from '@umijs/max';
import {
  Alert,
  Avatar,
  Button,
  Card,
  Col,
  DatePicker,
  message,
  Modal,
  Popconfirm,
  Row,
  Space,
  Table,
  Tag,
} from 'antd';
import moment from 'moment';
import { useEffect, useState } from 'react';
import { SignOff } from '../data';
import { signOffs, updateSignOff } from '../services';

const { RangePicker } = DatePicker;

const valueEnum = {
  0: 'close',
  1: 'running',
  2: 'online',
  3: 'error',
};

const ProcessMap = {
  close: 'normal',
  running: 'active',
  online: 'success',
  error: 'exception',
};

const handleUpdateRequest = async (signOff: SignOff) => {
  const hide = message.loading('Updating ...');

  try {
    await updateSignOff({ ...signOff });
    hide();
    message.success('Request update successful');
    return true;
  } catch (error) {
    hide();
    message.error('Failed to update request, pls try again!');
    return false;
  }
};

const handleUpdateToolStage = async (toolStage: ToolStage) => {
  const hide = message.loading('Updating tool stage ...');

  try {
    await updateToolStage({ ...toolStage });
    hide();
    message.success('Tool stage update successful');
    return true;
  } catch (error) {
    hide();
    message.error('Failed to update tool stage, pls try again!');
    return false;
  }
};

const moveToNext = async (toolId: string, user: string) => {
  const hide = message.loading('Updating tool stage ...');

  try {
    await nextStage({ toolId: toolId, user: user });
    hide();
    message.success('Tool has moved to the next stage.');
    return true;
  } catch (error) {
    hide();
    message.error('Failed to update tool current stage, pls try again!');
    return false;
  }
};

const RequestList = () => {
  const [requestList, setRequestList] = useState<SignOff[]>([]);
  const { data: allRequests } = useRequest(signOffs);
  const { data: allTools } = useRequest(tools);
  const { data: allStages } = useRequest(stages);
  const { data: allToolStages } = useRequest(toolStages);
  const [showRequest, setShowRequest] = useState(false);
  const [checklists, setChecklists] = useState<StageChecklist[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedTool, setSelectedTool] = useState<Tool>({});
  const [selectedStage, setSelectedStage] = useState<Stage>({});
  const [selectedRequest, setSelectedRequest] = useState<SignOff>({});
  const [submitBy, setSubmitBy] = useState('');
  const [submitAt, setSubmitAt] = useState('');
  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};

  const access = useAccess();
  //console.log(access);

  const { data: toolChecklists, run } = useRequest(toolChecklistsByToolId, {
    manual: true,
  });

  const handleSelect = (row: SignOff) => {
    const tool = allTools?.find((t) => t.eqpId === row.eqpId);

    if (tool) {
      setSelectedTool(tool);
      setSubmitBy(row.submitBy!);
      setSubmitAt(row.submitDate!);
      run({ toolId: tool.id, stageId: row.stageId });
      setShowRequest(true);
    }

    const stage = allStages?.find((s) => s.id === row.stageId);

    if (stage) {
      setSelectedStage(stage);
    }

    setSelectedRequest(row);
  };

  const columns: ProColumns<SignOff>[] = [
    {
      title: 'EQPID',
      width: 120,
      dataIndex: 'eqpId',
      fixed: 'left',
      render: (_, row) => (
        <a
          onClick={() => {
            handleSelect(row);
          }}
        >
          {_}
        </a>
      ),
    },
    {
      title: 'Stage',
      width: 120,
      dataIndex: 'stageName',
      align: 'left',
      fixed: 'left',
      search: false,
      sorter: (a, b) => a.stageName?.localeCompare(b.stageName!),
    },
    {
      title: 'Category',
      width: 140,
      align: 'left',
      dataIndex: 'category',
    },
    {
      title: 'Status',
      width: 120,
      dataIndex: 'status',
    },
    {
      title: 'Submit By',
      dataIndex: 'submitBy',
      width: 120,
    },
    {
      title: 'Submit Date',
      width: 140,
      dataIndex: 'submitDate',
      valueType: 'date',
      sorter: (a, b) => a.submitDate - b.submitDate,
    },
    {
      title: 'Owner',
      dataIndex: 'owner',
      width: 120,
    },
    {
      title: 'Remark',
      dataIndex: 'remark',
      ellipsis: true,
      search: false,
    },
    {
      title: 'Sign By',
      dataIndex: 'signBy',
      width: 120,
    },
    {
      title: 'Sign Date',
      width: 140,
      dataIndex: 'signDate',
      valueType: 'date',
      sorter: (a, b) => a.signDate - b.signDate,
    },
    {
      title: 'Action',
      width: 140,
      key: 'option',
      valueType: 'option',
      fixed: 'right',
      render: (_, row) => [
        <Popconfirm
          title="Please confirm!"
          disabled={row.status !== 'Submitted'}
          onConfirm={() => {
            setSelectedRequest(row);
            handleApprove(row);
          }}
          description="Are you sure to Approve the request? take note it is not reversable"
        >
          <Button key="approve" type="link" size="small" disabled={row.status !== 'Submitted'}>
            Approve
          </Button>
        </Popconfirm>,
        <Popconfirm
          title="Please confirm!"
          disabled={row.status !== 'Submitted'}
          onConfirm={() => {
            setSelectedRequest(row);
            handleReject(row);
          }}
          description="Are you sure to Reject the request? take note it is not reversable"
        >
          <Button key="approve" type="link" size="small" disabled={row.status !== 'Submitted'}>
            Reject
          </Button>
        </Popconfirm>,
      ],
    },
  ];

  const handleApprove = async (value: SignOff) => {
    setLoading(true);
    console.log(value);

    if (value) {
      value.status = 'Approved';
      value.signBy = currentUser?.empId;
      value.signDate = moment().format('YYYY-MM-DDTHH:mm:ss');

      const success = await handleUpdateRequest(value);

      console.log(success);
      if (success) {
        const txn: API.UserTxn = {
          userId: currentUser?.empId,
          txnType: 'Info',
          message: `User has approved stage completion request ${value.eqpId}@${value.stageName}`,
          txnTime: moment().format('YYYY-MM-DDTHH:mm:ss'),
        };

        await addUserTxn(txn);

        moveToNext(value.toolId!, currentUser?.empId!);

        // send notification
      }
    }
    setShowRequest(false);
    setLoading(false);
  };

  const handleReject = async (value: SignOff) => {
    setLoading(true);
    if (value) {
      value.status = 'Rejected';
      value.signBy = currentUser?.empId;
      value.signDate = moment().format('YYYY-MM-DDTHH:mm:ss');

      const success = await handleUpdateRequest(value);

      if (success) {
        const txn: API.UserTxn = {
          userId: currentUser?.empId,
          txnType: 'Info',
          message: `User has rejected stage completion request ${value.eqpId}@${value.stageName}`,
          txnTime: moment().format('YYYY-MM-DDTHH:mm:ss'),
        };

        await addUserTxn(txn);

        let currentToolStage = allToolStages?.find(
          (s) => s.toolId === value.toolId && s.stageId === value.stageId,
        );

        if (currentToolStage) {
          currentToolStage.status = 'Processing';

          await updateToolStage(currentToolStage);
        }

        // send notification
      }
    }
    setShowRequest(false);
    setLoading(false);
  };

  const { token } = useToken();
  const contentStyle: React.CSSProperties = {
    lineHeight: '30px',
    textAlign: 'left',
    color: token.colorTextTertiary,
    backgroundColor: token.colorSuccessBg,
    borderRadius: token.borderRadiusLG,
    border: `1px dashed ${token.colorBorder}`,
    marginTop: 5,
    minHeight: '30px',
    width: '200px',
    padding: '5px 10px',
  };

  useEffect(() => {
    if (allRequests) {
      setRequestList(
        allRequests
            .map((s)  => ({...s, 
                owner: allStages?.find(t=>t.id===s.stageId)?.owner,
                dept: allTools?.find(t=>t.id === s.toolId)?.area,
                section: allTools?.find(t=>t.section === s.section)?.section}))
            .filter((r) => r.category === 'Stage Completion' && r.status === 'Submitted')
            .filter((s) => (access.canAdmin 
                      || (access.isIEguy && s.owner === "IE")
                      || (access.isESHguy && s.owner === "ESH")
                      || (access.isFOCguy && s.owner === "FOC")
                      || (access.isQAguy && s.owner === "QA")
                      || (access.isITguy && s.owner === "IT")
                      || (s.owner === "EQ" && currentUser?.dept === s.dept && currentUser?.section === s.section)
                      || (s.owner === "PE" && currentUser?.dept === s.dept && currentUser?.section?.includes("PE"))
                      )),
      );
    }
  }, [allRequests]);

  return (
    <>
      <ProTable<SignOff>
        columns={columns}
        rowSelection={{
          // 自定义选择项参考: https://ant.design/components/table-cn/#components-table-demo-row-selection-custom
          // 注释该行则默认不显示下拉选项
          selections: [Table.SELECTION_ALL, Table.SELECTION_INVERT],
          defaultSelectedRowKeys: [],
        }}
        tableAlertRender={({ selectedRowKeys, selectedRows, onCleanSelected }) => {
          //console.log(selectedRowKeys, selectedRows);
          return (
            <Space size={24}>
              <span>
                Already selected {selectedRowKeys.length} records
                <a style={{ marginInlineStart: 8 }} onClick={onCleanSelected}>
                  Cancel Selection
                </a>
              </span>
            </Space>
          );
        }}
        tableAlertOptionRender={() => {
          return (
            <Space size={16}>
              <a>Approve All</a>
              <a>Reject All</a>
            </Space>
          );
        }}
        dataSource={requestList}
        scroll={{ x: 1300 }}
        options={false}
        search={false}
        pagination={{
          pageSize: 10,
        }}
        rowKey="id"
        headerTitle="Stage Completion Request"
        toolBarRender={() => [
          <Button onClick={() => history.push('/admin/closedRequest')}>Closed Requests</Button>,
        ]}
      />
      <Modal
        title="Request Detail"
        open={showRequest}
        onCancel={() => setShowRequest(false)}
        width={800}
        footer={[
          <Button key="cancel" onClick={() => setShowRequest(false)}>
            Cancel
          </Button>,
          <Popconfirm
            title="Please confirm!"
            disabled={selectedRequest.status !== 'Submitted'}
            onConfirm={() => handleApprove(selectedRequest)}
            description="Are you sure to Approve the request? Take note the action is not reversable!"
          >
            <Button
              key="submit"
              type="primary"
              disabled={selectedRequest.status !== 'Submitted'}
              loading={loading}
            >
              Approve
            </Button>
          </Popconfirm>,
          <Popconfirm
            title="Please confirm!"
            disabled={selectedRequest.status !== 'Submitted'}
            onConfirm={() => handleReject(selectedRequest)}
            description="Are you sure to Reject the request? Take note the action is not reversable!"
          >
            <Button
              key="reject"
              type="primary"
              loading={loading}
              disabled={selectedRequest.status !== 'Submitted'}
              danger
            >
              Reject
            </Button>
          </Popconfirm>,
        ]}
      >
        <Space direction="vertical" size={4} style={{ width: '100%' }}>
          <Card>
            <Space direction="vertical" size={4} style={{ width: '100%' }}>
              <Alert
                message={`The request was submitted by ${submitBy} at ${submitAt}`}
                type="info"
              />
              {selectedRequest.status != 'Submitted' ? (
                <Alert
                  message={`The request was ${selectedRequest.status} by ${selectedRequest.signBy} at ${selectedRequest.signDate}`}
                  type={selectedRequest.status === 'Approved' ? 'success' : 'error'}
                />
              ) : (
                <></>
              )}
            </Space>
          </Card>
          <Card>
            <Row>
              <Col span={24}>
                <ProList<StageChecklist>
                  headerTitle={`Stage Checklist: ${selectedTool.eqpId}@${selectedStage.name}`}
                  rowKey={'seq'}
                  dataSource={toolChecklists}
                  metas={{
                    title: {
                      dataIndex: 'item',
                    },
                    avatar: {
                      dataIndex: 'seq',
                      render: (v) => {
                        return <Avatar>{v}</Avatar>;
                      },
                    },
                    description: {
                      dataIndex: 'description',
                    },
                    subTitle: {
                      dataIndex: 'inputType',
                      render: (v) => {
                        return (
                          <Space size={0}>
                            <Tag color="blue">{v}</Tag>
                          </Space>
                        );
                      },
                    },
                    actions: {
                      render: (text, row) => {
                        return [
                          <Space direction="vertical" size={1}>
                            {row.inputType === 'Notes Link' && (
                              <Button type="link" href={row.value} target="_blank">
                                View in Notes
                              </Button>
                            )}
                            {row.inputType == 'Checklist' && (
                              <Button type="link" href={row.value} target="_blank">
                                Open Checklist
                              </Button>
                            )}
                            {row.inputType !== 'Notes Link' && row.inputType !== 'Checklist' && (
                              <div style={contentStyle}>{row.value}</div>
                            )}
                          </Space>,
                        ];
                      },
                    },
                  }}
                />
              </Col>
            </Row>
          </Card>
        </Space>
      </Modal>
    </>
  );
};

export default RequestList;
