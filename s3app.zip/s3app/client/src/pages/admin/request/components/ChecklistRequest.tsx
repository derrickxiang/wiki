import { ToolChecklist, ToolChecklistItem } from '@/pages/execute/checklist/data';
import {
  toolChecklistItems,
  toolChecklists,
  updateToolChecklistItem,
} from '@/pages/execute/checklist/services';
import { Stage } from '@/pages/setup/stage/data';
import { stages } from '@/pages/setup/stage/services';
import { Tool } from '@/pages/setup/tool/data';
import { tools } from '@/pages/setup/tool/services';
import { addUserTxn } from '@/services/ant-design-pro/api';
import { ProColumns, ProList, ProTable, useToken } from '@ant-design/pro-components';
import { history, useAccess, useModel, useRequest } from '@umijs/max';
import {
  Alert,
  Avatar,
  Button,
  Card,
  Col,
  message,
  Modal,
  Popconfirm,
  Row,
  Space,
  Table,
  Tag,
} from 'antd';
import moment from 'moment';
import { useEffect, useState } from 'react';
import { SignOff } from '../data';
import { signOffs, updateSignOff } from '../services';

const handleItemUpdate = async (id: string, value: string, user: string) => {
  const hide = message.loading('Updating ...');

  try {
    await updateToolChecklistItem({ id: id, status: 'Updated', value: value, user: user });
    hide();

    message.success('Checklist item update successful', 1);

    return true;
  } catch (error) {
    hide();
    message.error('Failed to update request, pls try again!');
    return false;
  }
};

const ChecklistRequest = () => {
  const [requestList, setRequestList] = useState<SignOff[]>([]);
  const { data: allRequests } = useRequest(signOffs);
  const { data: allTools } = useRequest(tools);
  const { data: allStages } = useRequest(stages);
  const [showRequest, setShowRequest] = useState(false);
  const [loading, setLoading] = useState(false);
  const [selectedTool, setSelectedTool] = useState<Tool>({});
  const [selectedStage, setSelectedStage] = useState<Stage>({});
  const [selectedRequest, setSelectedRequest] = useState<SignOff>({});
  const [submitBy, setSubmitBy] = useState('');
  const [submitAt, setSubmitAt] = useState('');
  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};
  const [selectedChecklist, setSelectedChecklist] = useState<ToolChecklist>({});

  const { data: allToolChecklists } = useRequest(toolChecklists);

  const { data: allToolChecklistItems, run: getAllToolChecklistItems } = useRequest(
    (params) => {
      return toolChecklistItems(params);
    },
    {
      manual: true,
    },
  );

  const handleUpdateRequest = async (signOff: SignOff) => {
    const hide = message.loading('Updating ...');

    try {
      await updateSignOff({ ...signOff });
      hide();
      message.success('Request update successful');
      return true;
    } catch (error) {
      hide();
      message.error('Failed to update request, pls try again!');
      return false;
    }
  };
  const handleSelect = (row: SignOff) => {
    setSelectedRequest(row);

    setSelectedChecklist(allToolChecklists?.find((c) => c.id === row.checklistId)!);
    getAllToolChecklistItems({ toolChecklistId: row.checklistId });
    setSubmitBy(row.submitBy!);
    setSubmitAt(row.submitDate!);

    setShowRequest(true);
  };

  const access = useAccess();
  const { token } = useToken();
  const contentStyle: React.CSSProperties = {
    lineHeight: '30px',
    textAlign: 'left',
    color: token.colorTextTertiary,
    backgroundColor: token.colorSuccessBg,
    borderRadius: token.borderRadiusLG,
    border: `1px dashed ${token.colorBorder}`,
    marginTop: 5,
    minHeight: '30px',
    width: '200px',
    padding: '5px 10px',
  };

  const columns: ProColumns<SignOff>[] = [
    {
      title: 'EQPID',
      width: 120,
      dataIndex: 'eqpId',
      fixed: 'left',
      render: (_, row) => (
        <a
          onClick={() => {
            handleSelect(row);
          }}
        >
          {_}
        </a>
      ),
    },
    {
      title: 'Stage',
      width: 120,
      dataIndex: 'stageName',
      align: 'left',
      fixed: 'left',
      search: false,
      sorter: (a, b) => a.stageName?.localeCompare(b.stageName!),
    },
    {
      title: 'Category',
      width: 140,
      align: 'left',
      dataIndex: 'category',
    },
    {
      title: 'Status',
      width: 120,
      dataIndex: 'status',
    },
    {
      title: 'Submit By',
      dataIndex: 'submitBy',
      width: 120,
    },
    {
      title: 'Submit Date',
      width: 140,
      dataIndex: 'submitDate',
      valueType: 'date',
      sorter: (a, b) => a.submitDate - b.submitDate,
    },
    {
      title: 'Remark',
      dataIndex: 'remark',
      ellipsis: true,
      search: false,
    },
    {
      title: 'Sign By',
      dataIndex: 'signBy',
      width: 120,
    },
    {
      title: 'Sign Date',
      width: 140,
      dataIndex: 'signDate',
      valueType: 'date',
      sorter: (a, b) => a.signDate - b.signDate,
    },
    {
      title: 'Action',
      width: 140,
      key: 'option',
      valueType: 'option',
      fixed: 'right',
      render: (_, row) => [
        <Popconfirm
          title="Please confirm!"
          disabled={row.status !== 'Submitted'}
          onConfirm={async () => {
            setSelectedRequest(row);
            handleApprove(row);
          }}
          description="Are you sure to Approve the request? take note it is not reversable"
        >
          <Button key="approve" type="link" size="small" disabled={row.status !== 'Submitted'}>
            Approve
          </Button>
        </Popconfirm>,
        <Popconfirm
          title="Please confirm!"
          disabled={row.status !== 'Submitted'}
          onConfirm={async () => {
            setSelectedRequest(row);
            handleReject(row);
          }}
          description="Are you sure to Reject the request? take note it is not reversable"
        >
          <Button key="approve" type="link" size="small" disabled={row.status !== 'Submitted'}>
            Reject
          </Button>
        </Popconfirm>,
      ],
    },
  ];

  const handleApprove = async (value: SignOff) => {
    setLoading(true);
    console.log(value);

    if (value) {
      value.status = 'Approved';
      value.signBy = currentUser?.empId;
      value.signDate = moment().format('YYYY-MM-DDTHH:mm:ss');

      const success = await handleUpdateRequest(value);

      if (success) {
        const txn: API.UserTxn = {
          userId: currentUser?.empId,
          txnType: 'Info',
          message: `User has approved checklist completion request ${value.eqpId}@${value.stageName} -${value.checklistId}`,
          txnTime: moment().format('YYYY-MM-DDTHH:mm:ss'),
        };

        await addUserTxn(txn);
        // change status

        handleItemUpdate(value?.checklistId!, 'Approved', currentUser?.empId!);
      }
    }
    setShowRequest(false);
    setLoading(false);
  };

  const handleReject = async (value: SignOff) => {
    setLoading(true);
    if (value) {
      value.status = 'Rejected';
      value.signBy = currentUser?.empId;
      value.signDate = moment().format('YYYY-MM-DDTHH:mm:ss');

      const success = await handleUpdateRequest(value);

      if (success) {
        const txn: API.UserTxn = {
          userId: currentUser?.empId,
          txnType: 'Info',
          message: `User has rejected checklist completion request ${value.eqpId}@${value.stageName} -${value.checklistId}`,
          txnTime: moment().format('YYYY-MM-DDTHH:mm:ss'),
        };

        await addUserTxn(txn);

        handleItemUpdate(value?.checklistId!, 'Rejected', currentUser?.empId!);
      }
    }
    setShowRequest(false);
    setLoading(false);
  };

  useEffect(() => {
    if (allRequests) {
      setRequestList(
        allRequests
          .map((s) => ({
            ...s,
            owner: allStages?.find((t) => t.id === s.stageId)?.owner,
            dept: allTools?.find((t) => t.id === s.toolId)?.area,
            section: allTools?.find((t) => t.section === s.section)?.section,
          }))
          .filter((r) => r.category === 'Checklist Completion' && r.status === 'Submitted')
          .filter(
            (s) =>
              access.canAdmin ||
              (access.isIEguy && s.owner === 'IE') ||
              (access.isESHguy && s.owner === 'ESH') ||
              (access.isFOCguy && s.owner === 'FOC') ||
              (access.isQAguy && s.owner === 'QA') ||
              (access.isITguy && s.owner === 'IT') ||
              (s.owner === 'EQ' &&
                currentUser?.dept === s.dept &&
                currentUser?.section === s.section) ||
              (s.owner === 'PE' &&
                currentUser?.dept === s.dept &&
                currentUser?.section?.includes('PE')),
          ),
      );
    }
  }, [allRequests]);

  return (
    <>
      <ProTable<SignOff>
        columns={columns}
        rowSelection={{
          selections: [Table.SELECTION_ALL, Table.SELECTION_INVERT],
          defaultSelectedRowKeys: [],
        }}
        tableAlertRender={({ selectedRowKeys, selectedRows, onCleanSelected }) => {
          return (
            <Space size={24}>
              <span>
                Already selected {selectedRowKeys.length} records
                <a style={{ marginInlineStart: 8 }} onClick={onCleanSelected}>
                  Cancel Selection
                </a>
              </span>
            </Space>
          );
        }}
        tableAlertOptionRender={() => {
          return (
            <Space size={16}>
              <a>Approve All</a>
              <a>Reject All</a>
            </Space>
          );
        }}
        dataSource={requestList}
        scroll={{ x: 1300 }}
        options={false}
        search={false}
        pagination={{
          pageSize: 10,
        }}
        rowKey="id"
        headerTitle="Checklist Form Request"
        toolBarRender={() => [
          <Button onClick={() => history.push('/admin/closedRequest')}>Closed Requests</Button>,
        ]}
      />

      <Modal
        title="Request Detail"
        open={showRequest}
        onCancel={() => setShowRequest(false)}
        width={800}
        footer={[
          <Button key="cancel" onClick={() => setShowRequest(false)}>
            Cancel
          </Button>,
          <Popconfirm
            title="Please confirm!"
            disabled={selectedRequest.status !== 'Submitted'}
            onConfirm={() => handleApprove(selectedRequest)}
            description="Are you sure to Approve the request? Take note the action is not reversable!"
          >
            <Button
              key="submit"
              type="primary"
              disabled={selectedRequest.status !== 'Submitted'}
              loading={loading}
            >
              Approve
            </Button>
          </Popconfirm>,
          <Popconfirm
            title="Please confirm!"
            disabled={selectedRequest.status !== 'Submitted'}
            onConfirm={() => handleReject(selectedRequest)}
            description="Are you sure to Reject the request? Take note the action is not reversable!"
          >
            <Button
              key="reject"
              type="primary"
              loading={loading}
              disabled={selectedRequest.status !== 'Submitted'}
              danger
            >
              Reject
            </Button>
          </Popconfirm>,
        ]}
      >
        <Space direction="vertical" size={4} style={{ width: '100%' }}>
          <Card>
            <Space direction="vertical" size={4} style={{ width: '100%' }}>
              <Alert
                message={`The request was submitted by ${submitBy} at ${submitAt}`}
                type="info"
              />
              {selectedRequest.status != 'Submitted' ? (
                <Alert
                  message={`The request was ${selectedRequest.status} by ${selectedRequest.signBy} at ${selectedRequest.signDate}`}
                  type={selectedRequest.status === 'Approved' ? 'success' : 'error'}
                />
              ) : (
                <></>
              )}
            </Space>
          </Card>
          <Card>
            <Row>
              <Col span={24}>
                <ProList<ToolChecklistItem>
                  headerTitle={`Checklist Form: ${selectedChecklist.checklistId}`}
                  rowKey={'seq'}
                  dataSource={allToolChecklistItems}
                  metas={{
                    title: {
                      dataIndex: 'category',
                    },
                    avatar: {
                      dataIndex: 'subSeq',
                      render: (v) => {
                        return <Avatar>{v}</Avatar>;
                      },
                    },
                    description: {
                      dataIndex: 'subCategory',
                    },
                    subTitle: {
                      dataIndex: 'inputType',
                      render: (v) => {
                        return (
                          <Space size={0}>
                            <Tag color="blue">{v}</Tag>
                          </Space>
                        );
                      },
                    },
                    actions: {
                      render: (text, row) => {
                        return [
                          <Space direction="vertical" size={1}>
                            {row.inputType === 'Notes Link' && (
                              <Button type="link" href={row.value} target="_blank">
                                View in Notes
                              </Button>
                            )}
                            {row.inputType !== 'Notes Link' && (
                              <div style={contentStyle}>{row.value}</div>
                            )}
                          </Space>,
                        ];
                      },
                    },
                  }}
                />
              </Col>
            </Row>
          </Card>
        </Space>
      </Modal>
    </>
  );
};

export default ChecklistRequest;
