import { StageChecklist } from "@/pages/setup/stageChecklist/data";
import { Tool } from "@/pages/setup/tool/data";
import { ProList, useToken } from "@ant-design/pro-components";
import { Modal, Card, Row, Col, Avatar, Space, Tag } from "antd";



interface Props {
    open: boolean;
    selectedStage?: string;
  selectedTool?: Tool;
  handleApprove?: ()=> void;
  handleReject?: ()=> void;
  checklists?: StageChecklist[];
}

const RequestDetail = ({
    open, 
    selectedStage, 
    selectedTool, 
    handleApprove,
    handleReject,
    checklists }: Props) => {

        const { token } = useToken();
        const contentStyle: React.CSSProperties = {
            lineHeight: '30px',
            textAlign: 'left',
            color: token.colorTextTertiary,
            backgroundColor: token.colorSuccessBg,
            borderRadius: token.borderRadiusLG,
            border: `1px dashed ${token.colorBorder}`,
            marginTop: 5,
            minHeight: '30px',
            width: '260px',
            padding: '5px 10px',
          };

    return (
    <Modal
        title="Request Detail"
        open={open}
        onOk={handleApprove}
        onCancel={handleReject}
        okButtonProps={{ disabled: true }}
        cancelButtonProps={{ disabled: true }}
      >
        <Card>
      <Row>
        <Col span={24}>
          <ProList<StageChecklist>
            headerTitle="Review your Checklist"
            rowKey={'seq'}
            dataSource={checklists}
            metas={{
              title: {
                dataIndex: 'item',
              },
              avatar: {
                dataIndex: 'seq',
                render: (v) => {
                  return <Avatar>{v}</Avatar>;
                },
              },
              description: {
                dataIndex: 'description',
              },
              subTitle: {
                dataIndex: 'inputType',
                render: (v) => {
                  return (
                    <Space size={0}>
                      <Tag color="blue">{v}</Tag>
                    </Space>
                  );
                },
              },
              actions: {
                render: (text, row) => {
                  return [
                    <Space direction="vertical" size={1}>                         
                      <div style={contentStyle}>{row.value}</div>
                    </Space>,
                  ];
                },
              },
            }}
          />
        </Col>
      </Row>
    </Card>
    </Modal>
    )
}

export default RequestDetail;