import { request } from "@umijs/max";
import { SignOff } from "./data";

export async function signOffs (
    params?: Record<string, any>,
    options?: Record<string, any>,
) {
    return request<{
        data: SignOff[],
        success?: Boolean;
    }>('/api/signoff', {
        method: 'GET',
        params: {
            ...params,
        },
        ...(options || {}),
    });
}

export async function updateSignOff(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request('/api/signoff', {
        data,
        method: 'PUT',
        ...(options || {}),
    });
}

export async function addSignOffs(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: SignOff[];
    }>('/api/signoff/batchUpdate', {
        data,
        method: 'POST',
        ...(options || {}),
    });
}

export async function addChecklistSignOff(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: SignOff[];
    }>('/api/signoff/checklist', {
        data,
        method: 'POST',
        ...(options || {}),
    });
}