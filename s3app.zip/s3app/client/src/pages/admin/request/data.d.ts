export type SignOff = {
    id?: string;
    toolId?: string;
    checklistId?: string;
    stageId?: string;
    stageName?: string;
    eqpId?: string;
    stageSeq?: number;
    category?: string;
    item?: string;
    remark?: string;
    status?: string;
    submitDate?: string;
    submitBy?: string;
    signDate?: string;
    signBy?: string;
    owner?: string;
    dept?: string;
    section?: string;
}