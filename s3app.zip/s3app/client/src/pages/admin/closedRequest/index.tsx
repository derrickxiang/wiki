import { toolChecklistsByToolId } from '@/pages/execute/checklist/services';
import { Stage } from '@/pages/setup/stage/data';
import { stages } from '@/pages/setup/stage/services';
import { StageChecklist } from '@/pages/setup/stageChecklist/data';
import { Tool } from '@/pages/setup/tool/data';
import { tools } from '@/pages/setup/tool/services';
import { PageContainer, ProColumns, ProList, ProTable, useToken } from '@ant-design/pro-components';
import { history, useModel, useRequest } from '@umijs/max';
import { Alert, Avatar, Button, Card, Col, Modal, Row, Space, Tag } from 'antd';
import { useEffect, useState } from 'react';
import { SignOff } from '../request/data';
import { signOffs } from '../request/services';


const ClosedRequests = () => {
  const [requestList, setRequestList] = useState<SignOff[]>([]);
  const { data: allRequests } = useRequest(signOffs);
  const { data: allStages} = useRequest(stages);
  const {data: allTools} =useRequest(tools);
  const [selectedTool, setSelectedTool] = useState<Tool>({});
  const [selectedStage, setSelectedStage] = useState<Stage>({});
  const [selectedRequest, setSelectedRequest] = useState<SignOff>({});
  const [submitBy, setSubmitBy] = useState('');
  const [submitAt, setSubmitAt] = useState('');
  const { initialState } = useModel('@@initialState');
  const { currentUser} = initialState || {};
  
  const [showRequest, setShowRequest] = useState(false);

  const { data: toolChecklists, run } = useRequest(
    toolChecklistsByToolId,
    {
      manual: true,
    },
  );
  
  const handleSelect = (row: SignOff) => {
    const tool = allTools?.find(t => t.eqpId === row.eqpId );

        if (tool) {
            setSelectedTool(tool);
            setSubmitBy(row.submitBy!);
            setSubmitAt(row.submitDate!);
            run({toolId: tool.id, stageId: row.stageId});
            setShowRequest(true);
        }

        const stage = allStages?.find(s => s.id === row.stageId);

        if (stage) {
            setSelectedStage(stage);
        }

        setSelectedRequest(row);
  }

  const { token } = useToken();
        const contentStyle: React.CSSProperties = {
            lineHeight: '30px',
            textAlign: 'left',
            color: token.colorTextTertiary,
            backgroundColor: token.colorSuccessBg,
            borderRadius: token.borderRadiusLG,
            border: `1px dashed ${token.colorBorder}`,
            marginTop: 5,
            minHeight: '30px',
            width: '200px',
            padding: '5px 10px',
        };

  
const columns: ProColumns<SignOff>[] = [
  {
    title: 'EQPID',
    width: 120,
    dataIndex: 'eqpId',
    fixed: 'left',
    render: (_, row) => <a onClick={() =>{
      handleSelect(row);
       
      }}>{_}</a>,
  },
  {
    title: 'Stage',
    width: 120,
    dataIndex: 'stageName',
    align: 'left',
    fixed: 'left',
    search: false,
    sorter: (a, b) => a.stageName?.localeCompare(b.stageName!),
  },
  {
    title: 'Category',
    width: 140,
    align: 'left',
    dataIndex: 'category',
  },
  {
    title: 'Status',
    width: 120,
    dataIndex: 'status',
  },
  {
    title: 'Submit By',
    dataIndex: 'submitBy',
    width: 120,
  },
  {
    title: 'Submit Date',
    width: 140,
    dataIndex: 'submitDate',
    valueType: 'date',
    sorter: (a, b) => a.submitDate - b.submitDate,
  },
  {
    title: 'Sign By',
    dataIndex: 'signBy',
    width: 120,
  },
  {
    title: 'Sign Date',
    width: 140,
    dataIndex: 'signDate',
    valueType: 'date',
    sorter: (a, b) => a.signDate - b.signDate,
  },
  {
    title: 'Remark',
    dataIndex: 'remark',
    ellipsis: true,
    search: false,
  },
];

  useEffect(() => {
    if (allRequests) {
      setRequestList(allRequests.filter((r) => r.status !== 'Submitted'));
    }
  }, [allRequests]);

  return (
    <PageContainer
      header={{
        title: 'Closed Requests',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'admin',
              title: 'Sign Off',
            },
            {
              path: '',
              title: 'Closed Requests',
            },
          ],
        },
      }}
      content={'Closed request list for your review'}
    >
      <ProTable<SignOff>
        columns={columns}
        dataSource={requestList}
        scroll={{ x: 1300 }}
        options={false}
        search={false}
        pagination={{
          pageSize: 10,
        }}
        rowKey="id"
        headerTitle="Stage Completion Request"
        toolBarRender={() => [
          <Button onClick={() => history.push('/admin/request')}>Open Requests</Button>,
        ]}
      />

<Modal
        title="Request Detail"
        open={showRequest}
        onCancel={()=> setShowRequest(false)}
        width={800}
        footer={[
            <Button key="cancel" onClick={()=> setShowRequest(false)}>
              Close
            </Button>,
            
          ]}
      >
        <Space direction='vertical' size={4} style={{ width: '100%'}}>
           <Card>
           <Space direction='vertical' size={4} style={{ width: '100%'}}>
            <Alert message={`The request was submitted by ${submitBy} at ${submitAt}`} type='info' />
            {selectedRequest.status != 'Submitted' ? (
                <Alert message={`The request was ${selectedRequest.status} by ${selectedRequest.signBy} at ${selectedRequest.signDate}`} 
                type={selectedRequest.status === 'Approved'? 'success':'error'} />
            ): (
            <></> 
            )
            }
            </Space>
            </Card> 
        <Card>
      <Row>
        <Col span={24}>
          <ProList<StageChecklist>
            headerTitle={`Stage Checklist: ${selectedTool.eqpId}@${selectedStage.name}`}
            rowKey={'seq'}
            dataSource={toolChecklists}
            metas={{
              title: {
                dataIndex: 'item',
              },
              avatar: {
                dataIndex: 'seq',
                render: (v) => {
                  return <Avatar>{v}</Avatar>;
                },
              },
              description: {
                dataIndex: 'description',
              },
              subTitle: {
                dataIndex: 'inputType',
                render: (v) => {
                  return (
                    <Space size={0}>
                      <Tag color="blue">{v}</Tag>
                    </Space>
                  );
                },
              },
              actions: {
                render: (text, row) => {
                  return [
                    <Space direction="vertical" size={1}>    
                    {
                      row.inputType === "Notes Link" && (
                        <Button type='link' href={row.value} target="_blank">View in Notes</Button> 
                      )
                    }         
                    {
                      row.inputType !== "Notes Link" && (
                        <div style={contentStyle}>{row.value}</div>
                      )
                    }            
                     
                    </Space>,
                  ];
                },
              },
            }}
          />
        </Col>
      </Row>
    </Card>
        </Space>
    </Modal>
    </PageContainer>
  );
};

export default ClosedRequests;
