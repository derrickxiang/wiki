import { PageContainer } from '@ant-design/pro-components';

const UserCenter = () => {
  return (
    <PageContainer
      header={{
        title: 'User Info',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'account',
              title: 'Account',
            },
            {
              path: '',
              title: 'Account Center',
            },
          ],
        },
      }}
      content={'User info page'}
    ></PageContainer>
  );
};

export default UserCenter;
