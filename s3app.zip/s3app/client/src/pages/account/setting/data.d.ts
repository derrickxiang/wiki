
export type UserSetting = {
    name: string;
    value: string;
}