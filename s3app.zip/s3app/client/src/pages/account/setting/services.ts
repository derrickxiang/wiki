import { request } from "@umijs/max";


export async function addUserSetting(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request('/api/user/settings', {
        data,
        method: 'POST',
        ...(options || {}),
    });
}