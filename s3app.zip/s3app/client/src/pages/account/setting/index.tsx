import { ProjectSelect } from '@/components';
import { projects } from '@/pages/setup/project/services';
import { PageContainer, ProForm, ProFormItem, ProFormSelect } from '@ant-design/pro-components';
import { useModel, useRequest } from '@umijs/max';
import { Spin } from 'antd';

const UserSetting = () => {

  const { initialState, setInitialState } = useModel('@@initialState');
  const loading = (
    <span>
      <Spin
        size="small"
        style={{
          marginLeft: 8,
          marginRight: 8,
        }}
      />
    </span>
  );

  if (!initialState) {
    return loading;
  }

  const { currentUser } = initialState;
  const { data: allProject } = useRequest(projects);
  
  return (
    <PageContainer
      header={{
        title: 'User Settings',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'account',
              title: 'User',
            },
            {
              path: '',
              title: 'User Settings',
            },
          ],
        },
      }}
      content={'User settings page'}
    >

      <ProForm
       title='User Defaults'
      >
        <ProFormSelect
          label="Default project"
          name="defaultProject"
          options={allProject
            ?.filter((p) => p.isEnabled)
            .map((p) => {
              return { label: p.name, value: p.name };
            })}
          width="md"
          />
       
        
      </ProForm>
    </PageContainer>
  );
};

export default UserSetting;
