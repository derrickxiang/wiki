import { ChecklistTemplate } from '@/pages/setup/checklist/data';
import { request } from '@umijs/max';
import { ToolChecklist, ToolChecklistItem } from './data';

export async function toolChecklists(params?: Record<string, any>, options?: Record<string, any>) {
  return request<{
    data: ToolChecklist[];
    success?: Boolean;
  }>('/api/toolChecklist', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

export async function toolChecklistsByToolId(
  params?: Record<string, any>,
  options?: Record<string, any>,
) {
  return request<{
    data: ToolChecklist[];
    success?: Boolean;
  }>('/api/toolChecklist/bytool', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

export async function checklistTemplate(
  params: {
    checklistId?: string;
  },
  options?: Record<string, any>,
) {
  return request<{
    data: ChecklistTemplate;
    success?: Boolean;
  }>('/api/checklist/template/id', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

export async function toolChecklistItems(
  params: {
    currentPage?: number;
    pageSize?: number;
    templateId?: string;
    toolChecklistId?: string;
  },
  options?: Record<string, any>,
) {
  return request<{
    data: ToolChecklistItem[];
    total?: Number;
    success?: Boolean;
  }>('/api/toolchecklist/items', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

export async function updateToolChecklistItem(
  data: {
    [key: string]: any;
  },
  options?: {
    [key: string]: any;
  },
) {
  return request('/api/toolchecklist', {
    data,
    method: 'PUT',
    ...(options || {}),
  });
}

export async function updateToolChecklistFormItem(
  data: {
    [key: string]: any;
  },
  options?: {
    [key: string]: any;
  },
) {
  return request('/api/toolchecklist/item', {
    data,
    method: 'PUT',
    ...(options || {}),
  });
}

export async function batchUpdateToolChecklist(
  data: {
    [key: string]: any;
  },
  options?: {
    [key: string]: any;
  },
) {
  return request<{
    data: ToolChecklist[];
  }>('/api/toolChecklist/batchUpdate', {
    data,
    method: 'POST',
    ...(options || {}),
  });
}

export async function addToolChecklist(
  data: {
    [key: string]: any;
  },
  options?: {
    [key: string]: any;
  },
) {
  return request<{
    data: ToolChecklist[];
  }>('/api/toolChecklist', {
    data,
    method: 'POST',
    ...(options || {}),
  });
}
