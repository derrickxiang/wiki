export type ToolChecklist = {
    id?: string;
    toolId?: string;
    stageId?: string;
    stageName?: string;
    eqpId?: string;
    seq?: number;
    item?: string;
    checklistId?: string;
    inputType?: string;
    value?: string;
    owner?: string;
    totalItems?: number;
    completeItems?: number;
    templateId?: string;
    templateVer?: string;
    status?: string;
    approvalStatus?: string;
    updateAt?: string;
    updateBy?: string;
}

export type ToolChecklistItem = {
    id?: string;
    toolChecklistId?: string;
    checklistItemId?: string;
    seq?: number;
    subSeq?: string;
    category?: string;
    subCategory?: string;
    inputType?: string;
    value?: string;
    remark?: string;
    updateAt?: string;
    updateBy?: string;
}