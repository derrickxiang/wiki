import { Stage } from "@/pages/setup/stage/data";
import { Tool } from "@/pages/setup/tool/data";
import { Result, Button, Alert } from "antd";

interface Props {
    selectedStage: string;
    selectedTools: Tool[];
}

const SubmitResult = ({
    selectedStage,
    selectedTools
}: Props) => {
    return (
        <>
         <Result
    status="success"
    title="Submit the Stage Checklist Successful!"
    subTitle={<p style={{textAlign:'left', padding: '20px'}}><strong>Stage: </strong>{selectedStage}, <br/> <strong>Tools: </strong> {selectedTools.map(s=>s.eqpId).join()}.</p>}
    extra={[
        <Alert
        style={{textAlign: 'left'}}
        message="The update has been sent for approval!"
        description="If it's urgent, please contact the owner directly."
        type="info"
        showIcon
      />,
    ]}
  >
    </Result>
        </>
    )
}

export default SubmitResult;