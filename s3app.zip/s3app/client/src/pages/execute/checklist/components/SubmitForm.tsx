import { StageChecklist } from '@/pages/setup/stageChecklist/data';
import { Tool } from '@/pages/setup/tool/data';
import { ProList, useToken } from '@ant-design/pro-components';
import { Avatar, Button, Card, Col, Row, Space, Tag, Typography } from 'antd';
import { ToolChecklist } from '../data';

interface Props {
  selectedStage: string;
  selectedTools: Tool[];
  checklists: ToolChecklist[];
}

const SubmitForm = ({ selectedStage, selectedTools, checklists }: Props) => {
  console.log(checklists);
  const { token } = useToken();
  const contentStyle: React.CSSProperties = {
    lineHeight: '30px',
    textAlign: 'left',
    color: token.colorTextTertiary,
    backgroundColor: token.colorSuccessBg,
    borderRadius: token.borderRadiusLG,
    border: `1px dashed ${token.colorBorder}`,
    marginTop: 5,
    minHeight: '30px',
    width: '260px',
    padding: '5px 10px',
  };

  return (
    <>
      <Space direction="vertical" size="middle" style={{ display: 'flex' }}>
        <Card>
          <Row>
            <Col>
              Stage: <Tag color={'green'}> {selectedStage}</Tag>
            </Col>
            <Col>
              Tools:{' '}
              {selectedTools.map((t) => (
                <Tag color={'blue'}>{t.eqpId}</Tag>
              ))}
            </Col>
          </Row>
        </Card>
        <Card>
          <Row>
            <Col span={24}>
              <ProList<ToolChecklist>
                headerTitle="Review your Checklist"
                rowKey={'seq'}
                dataSource={checklists}
                metas={{
                  title: {
                    dataIndex: 'item',
                  },
                  avatar: {
                    dataIndex: 'seq',
                    render: (v) => {
                      return <Avatar>{v}</Avatar>;
                    },
                  },
                  description: {
                    dataIndex: 'description',
                  },
                  subTitle: {
                    dataIndex: 'inputType',
                    render: (v) => {
                      return (
                        <Space size={0}>
                          <Tag color="blue">{v}</Tag>
                        </Space>
                      );
                    },
                  },
                  actions: {
                    render: (text, row) => {
                      return [
                        <Space direction="vertical" size={1}>
                          <Typography>You have entered:</Typography>
                          <div style={contentStyle}>{
                          row.inputType === "Notes Link" && (
                            <Button type='link'
                            target={'_blank'}
                            href={row.value}
                            >Open in Notes</Button>
                          )
                    }
                           {row.inputType !== "Notes Link" && row.value}
                          </div>
                        </Space>,
                      ];
                    },
                  },
                }}
              />
            </Col>
          </Row>
        </Card>
      </Space>
    </>
  );
};

export default SubmitForm;
