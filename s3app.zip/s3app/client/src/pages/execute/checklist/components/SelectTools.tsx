import { stages } from '@/pages/setup/stage/services';
import { Tool } from '@/pages/setup/tool/data';
import { tools } from '@/pages/setup/tool/services';
import { ToolStage } from '@/pages/setup/toolStage/data';
import { toolStages } from '@/pages/setup/toolStage/services';
import { ProList } from '@ant-design/pro-components';
import { history, useModel, useRequest } from '@umijs/max';
import { Cascader, Form, Progress, Select, Tag } from 'antd';
import { DefaultOptionType } from 'antd/lib/select';
import { useEffect, useState } from 'react';

const { SHOW_CHILD } = Cascader;

interface Props {
  listData: string[];
  selectedStage: string;
  initTools: Tool[];
  currentToolStage: ToolStage | undefined;
  setListData: (v: any[]) => void;
  setSelectedStage: (v: string) => void;
  //setSelectedTools: (v: Tool[]) => void;
  setInitTools: (v: Tool[]) => void;
  setChecklists: (v: any[]) => void;
  nextStep: ()=> void;
  setToolStage: (v: ToolStage|undefined) => void;
}

const SelectTools = ({
  listData,
  setListData,
  selectedStage,
  initTools,
  currentToolStage,
  setToolStage,
  setSelectedStage,
  setChecklists,
  setInitTools,
  nextStep,
}: Props) => {
  const [toolTreeData, setToolTreeData] = useState<any[]>([]);
  const { data: allTools } = useRequest(tools);
  const { data: allStages } = useRequest(stages);
  const { data: allToolStages } = useRequest(toolStages);

  const [selectedTools, setSelectedTools] = useState<Tool[]>([]);
  
  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};

  const onChange = (value: string[]) => {
    console.log(value);
    if (value) {
      var res = allTools?.find((t) => t.eqpId === value[2]);

      if (res) {
        setSelectedTools([res]);
        setInitTools([res]);
        setSelectedStage(res.currentStage!);
      }

      setChecklists([]);
    }
  };

  const onStageChange = (value: string) => {
    setSelectedStage(value);

    //setInitTools(selectedTools.filter( s=> s.currentStage === value));

    // if (selectedTools) {
    //   setSelectedTools(selectedTools.filter(s => s.currentStage === value));
    // }
  };

  const filter = (inputValue: string, path: DefaultOptionType[]) =>
    path.some(
      (option) => (option.label as string).toLowerCase().indexOf(inputValue.toLowerCase()) > -1,
    );

  const params = new URLSearchParams(history.location.search);

  useEffect(() => {
    if (allTools) {
      setToolTreeData(
        [...new Set(allTools.map((t) => t.area))].map((d) => ({
          label: d,
          value: d,
          children: [...new Set(allTools.filter((t) => t.area === d).map((t) => t.section))].map(
            (s) => ({
              label: s,
              value: d + '-' + s,
              children: [
                ...new Set(
                  allTools
                    .filter((t) => t.area === d && t.section === s)
                    .map((t) => ({
                      label: t.eqpId,
                      value: t.eqpId,
                    })),
                ),
              ],
            }),
          ),
        })),
      );
    }
  }, [allTools]);

  useEffect(() => {
    
    if (initTools && selectedStage && initTools.length > 0 && initTools[0].currentStage !== selectedStage) {
      setInitTools([]);
    }

    if (initTools && initTools.length > 0 && allToolStages) {
      const tool = initTools[0];
      const toolStage = allToolStages.find(s => s.toolId == tool.id && s.stageName === tool.currentStage);

      if (toolStage) {
        console.log(toolStage);
        setToolStage(toolStage);
      }
    }

    //setInitTools(selectedTools.filter((s) => s.currentStage === selectedStage));
  }, [selectedStage, initTools, allToolStages]);

  useEffect(() => {
    if (initTools) {
      setListData(
        initTools
          .filter((s) => s.currentStage === selectedStage)
          .map((item) => ({
            title: item.eqpId,
            actions: [
              <a
                key="delete"
                onClick={() => {
                  setInitTools(initTools.filter((t) => t.eqpId !== item.eqpId));
                }}
              >
                Remove
              </a>,
            ],
            content: (
              <div
                style={{
                  flex: 1,
                }}
              >
                <div >
                  <Tag color="#5BD8A6">{item.currentStage}</Tag>
                  <Tag color={'geekblue-inverse'}>{ currentToolStage?.status}</Tag>
                  <Progress
                    percent={
                      currentToolStage? parseFloat(( currentToolStage.completeChecklist!* 100 / currentToolStage.totalChecklist!).toFixed(1))
                        : 0
                    }
                  />
                </div>
              </div>
            ),
            
          })),
      );

      //setInitTools(selectedTools);
    }
  }, [selectedTools, selectedStage, initTools, currentToolStage]);

  //console.log(selectedTools);
  //console.log(initTools);

  useEffect(() => {
    const myStage = params.get('stage');
    const myeq = params.get('eqpid');

    if (myStage) {
      setSelectedStage(myStage);
    }

    if (myeq && allTools) {
      const mytool = allTools?.find((t) => t.eqpId === myeq);

      if (mytool && (!selectedTools || selectedTools.findIndex((t) => t.id === mytool.id) === -1)) {
        console.log('test');
        setSelectedTools([...selectedTools, mytool]);
      }

      if (mytool) {
        setInitTools([mytool]);
      }
    }
  }, [allTools]);

  return (
    <>
      <Form
        name="basic"
        //style={{ paddingInline: 50, paddingBlock: 20 }}
        initialValues={{ remember: true }}
        onFinish={(record: any) => {
          console.log(record);
        }}
        autoComplete="off"
      >
        <Form.Item
          labelCol={{ span: 8 }}
          name="section"
          label="Which tool you want to update?"
          rules={[{ required: true, message: 'Please search or select tools you want to update' }]}
        >
          <Cascader
            options={toolTreeData}
            expandTrigger={'hover'}
            //multiple
            maxTagCount={'responsive'}
            style={{ width: 350, alignItems: 'start' }}
            showSearch={filter}
            onChange={onChange}
            showCheckedStrategy={SHOW_CHILD}
          />
        </Form.Item>
        <Form.Item
          labelCol={{ span: 8 }}
          name="stage"
          label="Which stage you want to update? "
          rules={[{ required: true, message: 'Please select a stage you want to update' }]}
        >
          <Select
            style={{ width: 350, alignItems: 'start' }}
            onChange={onStageChange}
            value={selectedStage}
            rules={[
              {
                required: true,
                message: 'Please select a stage',
              },
            ]}
            options={allStages
              ?.sort((a, b) => a.seq - b.seq)
              .map((s) => ({
                label: s.name,
                value: s.name,
              }))}
          />
        </Form.Item>
        <ProList<any>
          ghost={false}
          key={'eqpId'}
          pagination={{
            defaultPageSize: 8,
            showSizeChanger: false,
          }}
          style={{ width: '100%' }}
          rowSelection={{}}
          grid={{ gutter: 16, column: 4 }}
          onItem={(record: any) => {
            return {
              onClick: () => {
                console.log(record);
                nextStep();
              },
            };
          }}
          metas={{
            title: {},
            subTitle: {},
            content: {},
            actions: {},
          }}
          headerTitle={`Tool List - (count: ${listData.length}, current stage: ${selectedStage})`}
          dataSource={listData}
        />
      </Form>
    </>
  );
};

export default SelectTools;
