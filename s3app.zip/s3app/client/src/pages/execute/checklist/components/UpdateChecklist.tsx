import { SignOff } from '@/pages/admin/request/data';
import { addChecklistSignOff } from '@/pages/admin/request/services';
import { checklistItems } from '@/pages/setup/checklist/services';
import { Stage } from '@/pages/setup/stage/data';
import { stages } from '@/pages/setup/stage/services';
import { Tool } from '@/pages/setup/tool/data';
import { ToolStage } from '@/pages/setup/toolStage/data';
import {
  ModalForm,
  ProFormRadio,
  ProFormText,
  ProFormTextArea,
  ProList,
} from '@ant-design/pro-components';
import { useModel, useRequest } from '@umijs/max';
import { Alert, Avatar, Button, Card, Col, Form, message, Row, Space, Tag } from 'antd';
import moment from 'moment';
import { useEffect, useState } from 'react';
import { ToolChecklist, ToolChecklistItem } from '../data';
import { toolChecklistItems, toolChecklists, updateToolChecklistItem } from '../services';
import ChecklistForm from './ChecklistForm';

interface Props {
  selectedStage: string;
  selectedTools: Tool[];
  stepComplte: boolean;
  setStepComplete: (v: boolean) => void;
  checklists: ToolChecklist[];
  currentToolStage: ToolStage;
  setChecklists: (v: ToolChecklist[]) => void;
}

const options = [
  { label: 'Yes', value: 'yes' },
  { label: 'No', value: 'no' },
  { label: 'NA', value: 'na' },
];

const handleChecklistSubmit = async (fields: SignOff) => {
  const hide = message.loading('Submitting stage checklist ...');

  try {
    await addChecklistSignOff(fields);
    hide();
    message.success('Stage checklist submit successful', 1);
    return true;
  } catch (error) {
    hide();
    console.error(error);
    message.error('Failed to submit checklist, pls try again!');
    return false;
  }
};

const UpdateChecklist = ({
  selectedStage,
  selectedTools,
  stepComplte,
  setStepComplete,
  checklists,
  currentToolStage,
  setChecklists,
}: Props) => {
  const [checklistModalVisible, handleChecklistModalVisible] = useState(false);
  const { data: allStages } = useRequest(stages);
  const [currentStage, setCurrentStage] = useState<Stage>({});

  const [form] = Form.useForm();
  const values = Form.useWatch([], form);

  const [formRef] = Form.useForm();
  const itemValues = Form.useWatch([], formRef);

  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};

  const [selectedChecklist, setSelectedChecklist] = useState<string>();
  const [currentToolChecklist, setCurrentToolChecklist] = useState<ToolChecklist>();

  const { data: allToolChecklists } = useRequest(toolChecklists);
  const [allItems, setChecklistItems] = useState<ToolChecklistItem[]>([]);

  const [checklistComplete, setChecklistComplete] = useState<boolean>(false);

  const handleItemUpdate = async (id: string, value: string, user: string) => {
    const hide = message.loading('Updating ...');

    try {
      await updateToolChecklistItem({ id: id, status: 'Updated', value: value, user: user });
      hide();

      message.success('Checklist item update successful', 1);

      return true;
    } catch (error) {
      hide();
      message.error('Failed to update request, pls try again!');
      return false;
    }
  };

  useEffect(() => {
    if (allStages) {
      setCurrentStage(allStages.find((s) => s.name === selectedStage) || {});
    }
  }, [selectedStage, allStages]);

  useEffect(() => {
    if (checklists && checklists?.length > 0 && values) {
      setStepComplete(true);

      checklists.map((c) => {
        if (!values[c.id!]) {
          setStepComplete(false);
        } else {
          c.value = values[c.id!];
        }
      });

      if (currentToolStage.status === 'Approving') setStepComplete(false);

      setChecklists(checklists);
    }
  }, [values, checklists, currentToolStage]);

  const { data: allChecklistItems, run: getAllItems } = useRequest(checklistItems, {
    refreshDeps: [selectedChecklist],
    manual: true,
  });

  const { data: allToolChecklistItems, run: getAllToolChecklistItems } = useRequest(
    (params) => {
      return toolChecklistItems(params);
    },
    {
      manual: true,
    },
  );

  useEffect(() => {
    if (selectedTools.length === 1 && allToolChecklists) {
      setChecklists(
        allToolChecklists.filter(
          (c) => c.toolId === selectedTools[0].id && c.stageId === currentStage.id,
        ),
      );
    }
  }, [selectedTools, allToolChecklists, setChecklists, currentStage]);

  useEffect(() => {
    if (checklists) {
      checklists.map((c) => {
        form.setFieldValue(c.id!, c.value);
      });
    }
  }, [checklists]);

  // useEffect(() => {
  //   if (allChecklistItems && currentToolChecklist) {
  //     setChecklistItems(allChecklistItems.map(i => ({
  //       checklistItemId:i.id,
  //       toolChecklistId: currentToolChecklist.id,
  //       seq: i.seq,
  //       subSeq: i.subSeq,
  //       category:i.category,
  //       subCategory:i.subCategory,
  //       inputType:i.inputType
  //     }) as ToolChecklistItem));
  //   }
  // }, [allChecklistItems, currentToolChecklist]);

  useEffect(() => {
    if (allToolChecklistItems) {
      setChecklistItems(allToolChecklistItems);
    }
  }, [allToolChecklistItems]);

  return (
    <>
      <Space direction="vertical" size="middle" style={{ display: 'flex' }}>
        <Card>
          <Row>
            <Col>
              Stage: <Tag color={'green'}> {selectedStage}</Tag>
            </Col>
            <Col>
              Tools:{' '}
              {selectedTools
                ?.filter((t) => t.currentStage === selectedStage)
                .map((t) => (
                  <Tag color={'blue'}>{t.eqpId}</Tag>
                ))}
            </Col>
          </Row>
        </Card>

        <Card>
          {currentToolStage && currentToolStage.status === 'Approving' && (
            <Alert
              message="Warning! The stage checklist is under approval, no editing is allowed!"
              type="warning"
              closable
            />
          )}
          <Form
            form={form}
            name="checklistForm"
            disabled={currentToolStage && currentToolStage.status === 'Approving'}
            onFinish={(fields: any) => {
              if (Object.keys(fields).length === checklists?.length) setStepComplete(true);

              checklists?.map((s) => {
                if (s.inputType !== 'Checklist') {
                  if (!fields[s.id]) {
                    console.log('Bingle');
                    setStepComplete(false);
                  }
                }
              });

              console.log(stepComplte);
            }}
          >
            <ProList<ToolChecklist>
              headerTitle="Stage Checklist"
              rowKey={'seq'}
              dataSource={checklists}
              onSubmit={(fields) => {
                console.log(fields);
              }}
              key={'seq'}
              toolBarRender={() => {
                return [
                  // <Button
                  //   key="save"
                  //   type="primary"
                  //   onClick={(e) => {
                  //     form.submit();
                  //   }}
                  //   icon={<SaveOutlined />}
                  // >
                  //   Save
                  // </Button>,
                ];
              }}
              metas={{
                title: {
                  dataIndex: 'item',
                },
                avatar: {
                  dataIndex: 'seq',
                  render: (v) => {
                    return <Avatar>{v}</Avatar>;
                  },
                },
                description: {
                  dataIndex: 'description',
                },
                subTitle: {
                  dataIndex: 'inputType',
                  render: (v) => {
                    return (
                      <Space size={0}>
                        <Tag color="blue" key="inputtype">
                          {v}
                        </Tag>
                      </Space>
                    );
                  },
                },
                actions: {
                  render: (text, row) => {
                    //console.log(row);
                    if (row.inputType === 'Boolean') {
                      return [
                        <ProFormRadio.Group
                          name={row.id}
                          rules={[
                            {
                              required: true,
                              message: 'Please choose one option',
                            },
                          ]}
                          options={options}
                          initialValue={row.value}
                          radioType={'button'}
                          fieldProps={{
                            buttonStyle: 'solid',
                            onChange: async (e) => {
                              console.log(e.target.value);
                              await handleItemUpdate(row.id!, e.target.value, currentUser?.empId!);
                            },
                          }}
                        />,
                      ];
                    } else if (row.inputType === 'Checklist') {
                      return (
                        <Form.Item name={row.id}>
                          <Button
                            name={row.id}
                            type="link"
                            onClick={async () => {
                              console.log(row);
                              const checklistId = row.checklistId ? row.checklistId : row.item;
                              setSelectedChecklist(checklistId);
                              setCurrentToolChecklist(row);
                              await getAllToolChecklistItems({ toolChecklistId: row.id });
                              handleChecklistModalVisible(true);
                            }}
                          >
                            Open the form
                          </Button>
                          {!row.value ? <Tag>Undone</Tag> : <Tag color={'green'}>{row.value}</Tag>}
                        </Form.Item>
                      );
                    } else if (row.inputType === 'Notes Link') {
                      return (
                        <ProFormTextArea
                          name={row.id}
                          rules={[
                            {
                              required: true,
                              message: 'Please enter notes links',
                            },
                          ]}
                          width={260}
                          style={{ minWidth: 360 }}
                          fieldProps={{
                            autoSize: { minRows: 2, maxRows: 5 },
                            onBlur: async (e) => {
                              console.log(e.target.value);
                              await handleItemUpdate(row.id!, e.target.value, currentUser?.empId!);
                            },
                          }}
                          placeholder="Please copy your notes doc as URL link and paste here"
                          initialValue={row.value}
                        />
                      );
                    } else {
                      return [
                        <ProFormText
                          name={row.id}
                          rules={[
                            {
                              required: true,
                              message: 'This field is required',
                            },
                          ]}
                          width={260}
                          placeholder="Please enter"
                          allowClear
                          initialValue={row.value}
                          fieldProps={{
                            onBlur: async (e) => {
                              console.log(e.target.value);
                              await handleItemUpdate(row.id!, e.target.value, currentUser?.empId!);
                            },
                          }}
                        />,
                      ];
                    }

                    return [<></>];
                  },
                },
              }}
            />
          </Form>
        </Card>
      </Space>

      <ModalForm
        title={`Update Checklist - ${selectedChecklist}`}
        width={'800px'}
        form={formRef}
        open={checklistModalVisible}
        onOpenChange={handleChecklistModalVisible}
        onFinish={async (fields: any) => {
          console.log(fields);
          if (Object.keys(fields).length === allItems?.length) setChecklistComplete(true);

          let allItemsDone = true;
          allItems?.map((s) => {
            if (!s.value) {
              allItemsDone = false;
            }
          });

          setChecklistComplete(allItemsDone);

          if (allItemsDone) {
            const signOff: SignOff = {
              toolId: currentToolChecklist?.toolId,
              stageId: currentToolChecklist?.stageId,
              stageName: allStages?.find((s) => s.id == currentToolChecklist?.stageId)?.name,
              stageSeq: allStages?.find((s) => s.id == currentToolChecklist?.stageId)?.seq,
              eqpId: selectedTools[0]?.eqpId,
              category: 'Checklist Completion',
              submitDate: moment().format('YYYY-MM-DDTHH:mm:ss'),
              submitBy: currentUser?.empId,
              status: 'Submitted',
              checklistId: currentToolChecklist?.id,
            };

            console.log(signOff);
            const result = await handleChecklistSubmit(signOff);

            if (result) {
              message.success('Checklist submit successful!');
            } else {
              message.error('Fail to submit the checklist, pls try again!');
            }

            handleChecklistModalVisible(false);

            await handleItemUpdate(currentToolChecklist?.id!, 'Approving', currentUser?.empId!);
            return true;
          } else {
            message.error('Please complete all the items!');
            return false;
          }
        }}
        submitter={{
          searchConfig: {
            submitText: 'Submit for Approval',
          },
          submitButtonProps: {
            disabled: currentToolChecklist?.value === 'Approving' || currentToolChecklist?.value === 'Approved'
          },
          // render: (props, defaultDoms) => {
          //   return [
          //     ...defaultDoms,
          //     <Button
          //       key="save"
          //       onClick={(fields: any) => {

          //         handleChecklistModalVisible(false);
          //         return true;
          //       }}
          //     >
          //       Save to draft
          //     </Button>,
          //   ];
          // },
        }}
      >
        <ChecklistForm
          checklistId={selectedChecklist}
          checklistItems={allItems}
          setChecklistComplete={setChecklistComplete}
          setChecklistItems={setChecklistItems}
          currentToolChecklist={currentToolChecklist}
        />
      </ModalForm>
    </>
  );
};

export default UpdateChecklist;
