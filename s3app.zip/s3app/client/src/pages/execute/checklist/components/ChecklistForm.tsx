import { ChecklistTemplate } from '@/pages/setup/checklist/data';
import {
  ActionType,
  PageContainer,
  ProCard,
  ProColumns,
  ProFormInstance,
  ProFormItem,
  ProTable,
  useToken,
} from '@ant-design/pro-components';
import { Alert, Descriptions, Form, Input, message, Radio, RadioChangeEvent, Table, TableColumnsType } from 'antd';
import { useEffect, useRef, useState } from 'react';
import { checklistTemplate, toolChecklistItems, updateToolChecklistFormItem } from '../services';
//import '../index.css';
import styles from '../../../../global.less';
import { ToolChecklist, ToolChecklistItem } from '../data';
import { useModel, useRequest } from '@umijs/max';
import { SignOff } from '@/pages/admin/request/data';
import { addSignOffs } from '@/pages/admin/request/services';

interface Props {
  checklistId?: string;
  checklistVer?: string;
  //checklist?: ChecklistTemplate;
  checklistComplete?: boolean;
  checklistItems?: ToolChecklistItem[];
  currentToolChecklist?: ToolChecklist;
  setChecklistItems: (v: ToolChecklistItem[]) => void;
  setChecklistComplete: (v: boolean) => void;
}

const HeaderPanel: React.FC<{ field: string | undefined }> = ({ field }) => {
  const fields: string[] = (field && field.split(',')) || [];

  return (
    <Descriptions column={3} style={{ marginBlockEnd: -16 }}>
      {fields.map((item) => (
        <Descriptions.Item label={item}>{item}</Descriptions.Item>
      ))}
    </Descriptions>
  );
};


const handleItemUpdate = async (checklistId: string, itemId: string, value: string, user: string) => {
  //const hide = message.loading('Updating ...');

  try {
   
      await updateToolChecklistFormItem({ checklistId: checklistId, itemId: itemId, value: value, user: user });
      //hide();
      
      //message.success('Checklist item update successful', 1);
   
    
    return true;
  } catch (error) {
    //hide();
    message.error('Failed to update item, pls try again!');
    return false;
  }
}


const options = [
  { label: 'Yes', value: 'yes' },
  { label: 'No', value: 'no' },
  { label: 'NA', value: 'na' },
];

interface DataType {
  key: React.Key;
  seq?: number;
  category?: string;
}

interface ExpandedDataType {
  key: React.Key;
  id?: string;
  subSeq?: string;
  subCategory?: string;
  inputType?: string;
  value?: string;
}

const ChecklistForm = ({
  checklistId,
  checklistVer,
  checklistItems: allItems,
  setChecklistItems,
  setChecklistComplete,
  currentToolChecklist,
}: Props) => {


  const { initialState} = useModel('@@initialState');
  const { currentUser } = initialState || {};
  const [checklist, setChecklist] = useState<ChecklistTemplate>();

  const onChange = ({ target: { value } }: RadioChangeEvent) => {
    console.log('checked', value);
  };

  const { data: allToolChecklistItems, run: getAllToolChecklistItems} = useRequest((params) => {
    return toolChecklistItems(params);
  }, {
    manual: true,
  })

  const onDataInput = (e: any) => {
    console.log(e.target.value);
  };

  const [mainData, setMainData] = useState<DataType[]>([]);

  const actionRef = useRef<ActionType>();

  const columns: ProColumns[] = [
    {
      title: 'No',
      dataIndex: 'seq',
      key: 'seq',
      sorter: (a, b) => a.seq - b.seq,
    },
    {
      title: 'Category',
      dataIndex: 'category',
      key: 'category',
    },
  ];

  const { token } = useToken();
  const contentStyle: React.CSSProperties = {
    lineHeight: '30px',
    textAlign: 'left',
    color: token.colorTextTertiary,
    backgroundColor: token.colorSuccessBg,
    borderRadius: token.borderRadiusLG,
    border: `1px dashed ${token.colorBorder}`,
    marginTop: 5,
    minHeight: '30px',
    width: '260px',
    padding: '5px 10px',
  };

  const expandedRowRender = (row: DataType) => {
    const columns: TableColumnsType<ToolChecklistItem> = [
      { title: 'Sub No', dataIndex: 'subSeq', key: 'subSeq' },
      { title: 'Sub Category', dataIndex: 'subCategory', key: 'subCategory' },
      {
        title: 'Input',
        dataIndex: 'inputType',
        width: '150px',
        key: 'inputType',
        render: (_, record) => {
          
          if (record.inputType === 'Boolean') {
            return (
              <ProFormItem name={record.id} key='radioInput'>
              <Radio.Group
                options={options}
                optionType="button"
                buttonStyle="solid"
                disabled={currentToolChecklist?.value === "Approving" || currentToolChecklist?.value === "Approved"}
                size="small"
                value={record.value}
                onChange={async (e)=> {
                  await handleItemUpdate(record.toolChecklistId!, record.checklistItemId!, e.target.value, currentUser?.empId!)
                  getAllToolChecklistItems({toolChecklistId: currentToolChecklist?.id});
                }}
              />
              </ProFormItem>
            );
          } else {
            return (
              <ProFormItem name={record.id} key='textInput' initialValue={record.value}>
                { (currentToolChecklist?.value === "Approving" || currentToolChecklist?.value === "Approved") && (
                  <>
                  <div style={contentStyle}>
                   {record.value}
                  </div>
                  </>
                )}
                { (currentToolChecklist?.value !== "Approving" && currentToolChecklist?.value !== "Approved") && (
                <Input size="small" allowClear
                //value={record.value}
                onBlur={async (e) => {
                  console.log(record);
                  console.log(e.target.value);
                  await handleItemUpdate(record.toolChecklistId!, record.checklistItemId!, e.target.value, currentUser?.empId!)
                  getAllToolChecklistItems({toolChecklistId: currentToolChecklist?.id});
                }} />
                )}
              </ProFormItem>);
          }
        },
      },
    ];

    const items: ToolChecklistItem[] = [];

    allItems &&
      allItems
        .filter((s) => s.seq === row.seq)
        .map((c) => {
          items.push(c);
        });


    return <Table columns={columns} dataSource={items} pagination={false} />;
  };

  useEffect(() => {
    checklistTemplate({ checklistId: checklistId }).then((res) => {
      console.log(res);
      setChecklist(res.data);
    });

    // console.log(chk);
    // setChecklist(chk);
  }, [checklistId]);

  useEffect(() => {
    console.log(allItems);
    if (allItems) {

      const distinctData = allItems.filter(
        (item, index, selfArray) =>
          index === selfArray.findIndex((p) => p.seq === item.seq && p.category === item.category),
      );

      const records: DataType[] = [];

      distinctData.map((d) => {
        records.push({
          key: d.seq!,
          seq: d.seq,
          category: d.category,
        });
      });

      setMainData(records);
    }
  }, [allItems]);

  useEffect(()=> {

    if (allToolChecklistItems) 
    {
      setChecklistItems(allToolChecklistItems);
    }
  },[allToolChecklistItems])

  return (
    <div
      style={{
        background: '#F5F7FA',
        paddingInline: 0,
        paddingBlock: 0,
      }}
    >
      <PageContainer
        ghost
        title={checklist && checklist?.name}
        //subTitle={checklist && checklist?.subTitle}

        className={styles.myPageNoEdge}
      >
        
          <ProCard
            style={{ minHeight: 600, paddingInline: 0, paddingBlock: 0 }}
            className={styles.myCardNoEdge}
          >
            {  currentToolChecklist 
               && (currentToolChecklist.value === "Approving" || currentToolChecklist.value === "Approved")
               && (
            <Alert message={`Warning! This checklist form is of status ${currentToolChecklist.value}, no editing is allowed!`}
             type='warning' 
             closable
             />
          )} 
            <ProTable
              columns={columns}
              actionRef={actionRef}
              cardBordered
              params={{ checklistId: checklistId }}
              //request={checklistItems}
              dataSource={mainData}
              search={false}
              options={false}
              //pagination={{pageSize: 8,}}
              className={styles.myCardNoEdge}
              expandable={{ expandedRowRender }}
            />
          </ProCard>
      </PageContainer>
    </div>
  );
};

export default ChecklistForm;
