import { SignOff } from '@/pages/admin/request/data';
import { addSignOffs } from '@/pages/admin/request/services';
import { stages } from '@/pages/setup/stage/services';
import { StageChecklist } from '@/pages/setup/stageChecklist/data';
import { Tool } from '@/pages/setup/tool/data';
import { ToolStage } from '@/pages/setup/toolStage/data';
import { CoffeeOutlined, EditOutlined, FileDoneOutlined, SelectOutlined } from '@ant-design/icons';
import { PageContainer, useToken } from '@ant-design/pro-components';
import { history, useModel, useParams, useRequest } from '@umijs/max';
import { Button, Card, message, Steps } from 'antd';
import moment from 'moment';
import { useEffect, useState } from 'react';
import SelectTools from './components/SelectTools';
import SubmitForm from './components/SubmitForm';
import SubmitResult from './components/SubmitResult';
import UpdateChecklist from './components/UpdateChecklist';
import { ToolChecklist } from './data';
import { batchUpdateToolChecklist } from './services';

const handleUpdate = async (fields: ToolChecklist[]) => {
  const hide = message.loading('Adding new tool checklist ...');

  try {
    await batchUpdateToolChecklist(fields);
    hide();
    message.success('Tool checklist create successful',1);
    return true;
  } catch (error) {
    hide();
    console.error(error);
    message.error('Failed to create checklist, pls try again!');
    return false;
  }
};

const handleSubmit = async (fields: SignOff[]) => {
  const hide = message.loading('Submitting stage checklist ...');

  try {
    await addSignOffs(fields);
    hide();
    message.success('Stage checklist submit successful',1);
    return true;
  } catch (error) {
    hide();
    console.error(error);
    message.error('Failed to submit checklist, pls try again!');
    return false;
  }
};

const ChecklistUpdate = () => {
  const { token } = useToken();
  const [current, setCurrent] = useState(0);
  const [listData, setListData] = useState<any[]>([]);
  const [selectedStage, setSelectedStage] = useState<string>();
  const [checklistDone, setChecklistDone] = useState<boolean>(false);
  const [checklists, setChecklists] = useState<ToolChecklist[]>([]);
  const [currentToolStage, setToolStage] = useState<ToolStage | undefined>(undefined);


  const { data: allStages} = useRequest(stages);
  const [initTools, setInitTools] = useState<Tool[]>([]);
  const { initialState } = useModel('@@initialState');

  const { currentUser } = initialState || {};

  const next = () => {
    if (current === 0 && listData.length === 0) {
      message.error("There's no tool found, please select some tools to continue!");
    } else if (current === 1 && !checklistDone) {
      message.error('Please complete all the checklist items!');
    } else {
      setCurrent(current + 1);
    }
  };

  const prev = () => {
    setCurrent(current - 1);
  };

  const steps = [
    {
      title: 'Select',
      content: (
        <SelectTools
          listData={listData}
          selectedStage={selectedStage || ''}
          currentToolStage={currentToolStage}
          setToolStage={setToolStage}
          setListData={setListData}
          setSelectedStage={setSelectedStage}
          setChecklists={setChecklists}
          initTools={initTools}
          setInitTools={setInitTools}
          nextStep={next}
        />
      ),
      icon: <SelectOutlined />,
    },
    {
      title: 'Update',
      content: (
        <UpdateChecklist
          selectedStage={selectedStage || ''}
          selectedTools={initTools}
          stepComplte={checklistDone}
          currentToolStage={currentToolStage}
          setStepComplete={setChecklistDone}
          checklists={checklists}
          setChecklists={setChecklists}
        />
      ),
      icon: <EditOutlined />,
    },
    {
      title: 'Review',
      content: <SubmitForm 
                checklists={checklists}
                selectedStage={selectedStage || ''}
          selectedTools={initTools}
                 />,
      icon: <FileDoneOutlined />,
    },
    {
      title: 'Submit',
      content: <SubmitResult selectedStage={selectedStage || ''} selectedTools={initTools} />,
      icon: <CoffeeOutlined />,
    },
  ];

  

  const items = steps.map((item) => ({ key: item.title, title: item.title, icon: item.icon }));

  const contentStyle: React.CSSProperties = {
    lineHeight: '260px',
    textAlign: 'left',
    color: token.colorTextTertiary,
    backgroundColor: token.colorFillAlter,
    borderRadius: token.borderRadiusLG,
    border: `1px dashed ${token.colorBorder}`,
    marginTop: 16,
    minHeight: '280px',
    padding: '24px 20px',
  };


  return (
    <PageContainer
      header={{
        title: 'Stage Checklist Update',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'execute',
              title: 'Execute',
            },
            {
              path: '',
              title: 'Stage Checklist Update',
            },
          ],
        },
      }}
      content={'Owner to update checklist items for each tool stage.'}
    >
      <Card>
        <Steps current={current} items={items} />
        <div style={contentStyle}>{steps[current].content}</div>
        <div style={{ marginTop: 24 }}>
          {current < steps.length - 2 && (
            <Button
              type="primary"
              disabled={
                (current === 0 && listData.length === 0) || (current === 1 && !checklistDone)
              }
              onClick={() => next()}
            >
              Next
            </Button>
          )}
          {current === steps.length - 2 && (
            <Button
              type="primary"
              onClick={async () => {
                //console.log(checklists);

                // const data: ToolChecklist[] = [];

                // checklists.map((c) =>
                //   initTools.map((t) =>
                //     data.push({
                //       toolId: t.id,
                //       stageId: c.stageId,
                //       stageName: c.stageName,
                //       eqpId: t.eqpId,
                //       seq: c.seq,
                //       item: c.item,
                //       inputType: c.inputType,
                //       value: c.value,
                //       templateId: c.templateId,
                //       templateVer: c.templateVer,
                //       status: 'Updated',
                //       approvalStatus: 'Submitted',
                //       updateAt: moment().format('YYYY-MM-DDTHH:mm:ss'),
                //       updateBy: currentUser?.empId,
                //     }),
                //   ),
                // );

                //console.log(data);
                //const result = await handleUpdate(data);

                const signOffData: SignOff[] = initTools.map(t => ({
                  toolId: t.id,
                  stageId: allStages?.find(s => s.name === selectedStage)?.id,
                  stageName: allStages?.find(s=>s.name === selectedStage)?.name,
                  stageSeq: allStages?.find(s=>s.name === selectedStage)?.seq,
                  eqpId: t.eqpId,
                  category: 'Stage Completion',
                  submitDate: moment().format('YYYY-MM-DDTHH:mm:ss'),
                  submitBy: currentUser?.empId,
                  status: 'Submitted',
                }));

                console.log(signOffData);
                const result = await handleSubmit(signOffData);

                if (result) {
                  next();
                }
              }}
            >
              Confirm & Submit
            </Button>
          )}
          {current > 0 && current < steps.length - 1 && (
            <Button style={{ margin: '0 8px' }} onClick={() => prev()}>
              Previous
            </Button>
          )}
          {current === steps.length - 1 && (
            <Button
              onClick={() => {
                setSelectedStage('');
                setInitTools([]);
                setChecklists([]);
                setChecklistDone(false);

                setCurrent(0);
              }}
            >
              Fill Another Checklist
            </Button>
          )}
        </div>
      </Card>
    </PageContainer>
  );
};

export default ChecklistUpdate;
