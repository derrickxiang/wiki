import { PageContainer } from '@ant-design/pro-components';

const ChecklistUpdate = () => {
  return (
    <PageContainer
      header={{
        title: 'Stage Checklist Update',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'execute',
              title: 'Execute',
            },
            {
              path: '',
              title: 'Stage Checklist Update',
            },
          ],
        },
      }}
      content={'Update checklist items for each tool stage.'}
    ></PageContainer>
  );
};

export default ChecklistUpdate;
