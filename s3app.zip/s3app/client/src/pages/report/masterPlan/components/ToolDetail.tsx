import { stages } from '@/pages/setup/stage/services';
import { Tool } from '@/pages/setup/tool/data';
import { ToolStage } from '@/pages/setup/toolStage/data';
import { toolStage } from '@/pages/setup/toolStage/services';
import { AlertOutlined, CheckOutlined } from '@ant-design/icons';
import { ProColumns, ProDescriptions, ProDescriptionsItemProps } from '@ant-design/pro-components';
import { history, useRequest } from '@umijs/max';
import { Button, Card, message, Popconfirm, Space, StepProps, Steps } from 'antd';
import { useEffect, useState } from 'react';

interface Props {
  tool: Tool;
  toolStages: ToolStage[] | undefined;
}

const columns: ProColumns<Tool>[] = [
  {
    title: 'Area',
    dataIndex: 'area',
    width: '100px',
  },
  {
    title: 'Section',
    dataIndex: 'section',
    width: '120px',
  },
  {
    title: 'EQPID',
    dataIndex: 'eqpId',
    width: '100px',
  },
  {
    title: 'Priority',
    dataIndex: 'priority',
    width: '120px',
  },
  {
    title: 'Status',
    dataIndex: 'status',
    valueType: 'select',
    width: '150px',
    valueEnum: {
      Ongoing: { text: 'Ongoing', status: 'Processing' },
      Complete: { text: 'Complete', status: 'Success' },
      Delay: { text: 'Delay', status: 'Error' },
    },
  },
  {
    title: 'Tooltype',
    dataIndex: 'tooltype',
    width: '120px',
  },
  {
    title: 'Tool Model',
    dataIndex: 'toolModel',
    hideInTable: true,
  },
  {
    title: 'Supplier',
    dataIndex: 'supplier',
    hideInTable: true,
  },
  {
    title: 'Entity',
    dataIndex: 'entity',
    width: '130px',
  },
  {
    title: 'Stage',
    dataIndex: 'currentStage',
    width: '150px',
  },
  {
    title: 'Gap',
    dataIndex: 'stageGap',
    tooltip: 'Gap for the current stage, in days',
    width: '100px',
  },
  {
    title: 'Gap(all)',
    dataIndex: 'overallGap',
    tooltip: 'Gap for overall stages, in days',
    width: '100px',
  },
  {
    title: 'Move In',
    width: '120px',
    dataIndex: 'moveInReqDate',
    render: (_) => <span>{_?.toString().substring(0, 10)}</span>,
  },
  {
    title: 'EE Handover',
    width: '120px',
    dataIndex: 'eeHandoverReqDate',
    render: (_) => <span>{_?.toString().substring(0, 10)}</span>,
  },
  {
    title: 'Pilot',
    width: '120px',
    dataIndex: 'pilotReqDate',
    render: (_) => <span>{_?.toString().substring(0, 10)}</span>,
  },
  {
    title: 'PCRB Release',
    width: '120px',
    dataIndex: 'pcrbReqDate',
    render: (_) => <span>{_?.toString().substring(0, 10)}</span>,
  },
];

const ToolDetail = ({ tool, toolStages }: Props) => {
  const { data: allStages } = useRequest(stages);
  
  const [currentStageSeq, setCurrentStageSeq] = useState<number | undefined>(undefined);
  const [currentToolStage, setCurrentToolstage] = useState<ToolStage|undefined>(undefined);
  const [steps, setSteps] = useState<StepProps[]>([]);
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    if (toolStages && tool) {
        const stage = toolStages.find((s) => s.stageName === tool.currentStage);

        if (stage){ 
          setCurrentToolstage(stage);
          setCurrentStageSeq(stage.seq);
        }
    }
  }, [toolStages, tool]);

  console.log(toolStages);

  useEffect(() => {
    if (toolStages && tool) {
      const tmpArr: any[] = [];
      let i = 0;
      toolStages
        .sort((s1, s2) => s1.seq! - s2.seq!)
        .map((s) => {
         
            if (s.seq === currentStageSeq) {
              setCurrentStep(i);

              tmpArr.push({
                title: s.stageName,
                subTitle: (
                  <Space direction="horizontal" size={2}>
                    <Button
                      size="small"
                      icon={<CheckOutlined />}
                      type="primary"
                      onClick={() => history.push(`/execute/checklist?eqpid=${s.eqpId}&stage=${s.stageName}`)}
                    >
                      Complete
                    </Button>
                    <Popconfirm
                      title="Sure to escalte the tool to the committee?"
                      onConfirm={() => {
                        message.warning('The tool has been escalated to the committee!');
                      }}
                    >
                      {' '}
                      <Button size="small" icon={<AlertOutlined />} danger type="primary">
                        Escalate
                      </Button>
                    </Popconfirm>
                  </Space>
                ),
                description: (
                  <>
                    <Space>
                      {' '}
                      <span>Require date: {s.requireDate?.substring(0,10)}</span>
                    </Space>
                    <br />
                    <Space>
                      {' '}
                      <span>Plan date:  {s.planDate?.substring(0,10)}</span>
                      <Button
                        danger
                        type="dashed"
                        size="small"
                        onClick={() => message.success('Push email sent out!')}
                      >
                        Push
                      </Button>
                    </Space>
                  </>
                ),
              });
            } else {
              tmpArr.push({
                title: s.stageName,
                subTitle: s.seq! < currentStageSeq! ? 'Done' : '',
                description:
                s.seq! < currentStageSeq! ? (
                    <span>
                      Require date: {s.requireDate?.substring(0,10)} <br />
                      Plan date: {s.planDate?.substring(0,10)} <br/>
                      Actual date: {s.actualDate}
                    </span>
                  ) : (
                    <span>Require date: {s.requireDate?.substring(0,10)} <br />
                    Plan date: {s.planDate?.substring(0,10)} </span>
                  ),
              });
            }
            i += 1;
        });

      setSteps(tmpArr);
    }
  }, [toolStages, tool, currentStageSeq]);

  return (
    <>
      <ProDescriptions<Tool>
        column={2}
        title={tool?.eqpId}
        request={async () => ({
          data: tool || {},
        })}
        params={{
          id: tool?.eqpId,
        }}
        columns={columns as ProDescriptionsItemProps<Tool>[]}
      />

      <Card bordered={false} title="Current Progress" style={{ minHeight: 600 }}>
        <Steps 
        current={currentStep}
         percent={currentToolStage && parseFloat(( currentToolStage.completeChecklist!* 100 / currentToolStage.totalChecklist!).toFixed(1))} 
         direction="vertical" 
         items={steps} />
      </Card>
    </>
  );
};

export default ToolDetail;
