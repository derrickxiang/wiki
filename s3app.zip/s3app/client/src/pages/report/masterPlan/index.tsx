import { projects } from '@/pages/setup/project/services';
import { stages } from '@/pages/setup/stage/services';
import { Tool } from '@/pages/setup/tool/data';
import { tools } from '@/pages/setup/tool/services';
import { toolStage } from '@/pages/setup/toolStage/services';
import { PageContainer, ProColumns, ProTable } from '@ant-design/pro-components';
import { useModel, useRequest } from '@umijs/max';
import { Drawer, Select } from 'antd';
import { useEffect, useState } from 'react';
import ToolDetail from './components/ToolDetail';

const MasterPlan = () => {
  const { data: allTools } = useRequest(tools);
  const { data: allStages } = useRequest(stages);
  const { data: allProjects } = useRequest(projects);

  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};
  const [dept, setDept] = useState('');
  const [project, setProject] = useState('');
  const [section, setSection] = useState('');

  const [toolList, setToolList] = useState<Tool[] | undefined>([]);
  const [projectList, setProjectList] = useState<string[]>([]);
  const [deptList, setDeptList] = useState<string[]>([]);
  const [sectionList, setSectionList] = useState<string[]>([]);

  const [currentRow, setCurrentRow] = useState<Tool>();
  const [showDetail, setShowDetail] = useState<boolean>(false);

  const {
    data: toolStages,
    run,
    refresh,
  } = useRequest(
    (toolId) => {
      return toolStage({ toolId: toolId });
    },
    {
      manual: true,
    },
  );

  const [stageList, setStageList] = useState<{ title: string; description: string }[]>([]);

  const columns: ProColumns<Tool>[] = [
    {
      title: 'Area',
      dataIndex: 'area',
      width: '100px',
      fixed: 'left',
      filters: true,
    },
    {
      title: 'Section',
      dataIndex: 'section',
      width: '120px',
      fixed: 'left',
    },
    {
      title: 'EQPID',
      dataIndex: 'eqpId',
      width: '130px',
      fixed: 'left',
      render: (dom, entity) => {
        return (
          <a
            onClick={() => {
              setCurrentRow(entity);
              run(entity.id);
              setShowDetail(true);
            }}
          >
            {dom}
          </a>
        );
      },
    },
    {
      title: 'Priority',
      dataIndex: 'priority',
      width: '120px',
      sorter: (a, b) => a.priority - b.priority,
    },
    {
      title: 'Status',
      dataIndex: 'status',
      valueType: 'select',
      width: '150px',
      valueEnum: {
        Ongoing: { text: 'Ongoing', status: 'Processing' },
        Complete: { text: 'Complete', status: 'Success' },
        Delay: { text: 'Delay', status: 'Error' },
      },
    },
    {
      title: 'Tooltype',
      dataIndex: 'tooltype',
      width: '120px',
    },
    {
      title: 'Tool Model',
      dataIndex: 'toolModel',
      hideInTable: true,
    },
    {
      title: 'Supplier',
      dataIndex: 'supplier',
      hideInTable: true,
    },
    {
      title: 'Entity',
      dataIndex: 'entity',
      width: '130px',
    },
    {
      title: 'Stage',
      dataIndex: 'currentStage',
      width: '150px',
    },
    {
      title: 'Gap',
      dataIndex: 'stageGap',
      tooltip: 'Gap for the current stage, in days',
      width: '100px',
    },
    {
      title: 'Gap(all)',
      dataIndex: 'overallGap',
      tooltip: 'Gap for overall stages, in days',
      width: '100px',
    },
    {
      title: 'Move In',
      width: '120px',
      dataIndex: 'moveInReqDate',
      render: (_) => <span>{_?.toString().substring(0, 10)}</span>,
    },
    {
      title: 'EE Handover',
      width: '120px',
      dataIndex: 'eeHandoverReqDate',
      render: (_) => <span>{_?.toString().substring(0, 10)}</span>,
    },
    {
      title: 'Pilot',
      width: '120px',
      dataIndex: 'pilotReqDate',
      render: (_) => <span>{_?.toString().substring(0, 10)}</span>,
    },
    {
      title: 'PCRB Release',
      width: '120px',
      dataIndex: 'pcrbRelease',
      render: (_) => <span>{_?.toString().substring(0, 10)}</span>,
    },
  ];

  useEffect(() => {
    if (allTools) {
      setToolList(allTools);
    }
  }, [allTools]);

  useEffect(() => {
    if (toolList) {
      setDeptList([...new Set(toolList?.map((s) => s.area!))]);
    }
  }, [toolList]);

  useEffect(() => {
    if (dept) {
      setSectionList([...new Set(toolList?.filter((t) => t.area === dept).map((s) => s.section!))]);
    } else {
      setSection('');
    }
  }, [dept]);

  useEffect(() => {
    if (project) {
      setDeptList([...new Set(allTools?.map((s) => s.area!))]);
      setSectionList([...new Set(allTools?.filter((t) => t.area === dept).map((s) => s.section!))]);
    } else {
      setToolList(allTools);
    }
  }, [project]);

  useEffect(() => {
    if (allProjects) {
      setProjectList([...new Set(allProjects.map((p) => p.name))]);
    }
  }, [allProjects]);

  useEffect(() => {
    if (allStages) {
      setStageList([
        ...allStages
          ?.sort((a, b) => a.seq - b.seq)
          .map((t) => ({
            title: t.name!,
            description: t.description!,
          })),
      ]);
    }
  }, [allStages]);

  return (
    <PageContainer
      header={{
        title: 'Master Plan',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'report',
              title: 'Report',
            },
            {
              path: '',
              title: 'Master Plan',
            },
          ],
        },
      }}
      content={'The master plan of all tools.'}
      extra={[
        <Select
          value={project}
          onChange={(e) => {
            setDept('');
            setSection('');
            setProject(e);
          }}
          style={{ width: 120 }}
          dropdownMatchSelectWidth={false}
          placement={'bottomLeft'}
          options={[
            ...projectList.map((d) => ({
              label: d,
              value: d,
            })),
            {
              label: 'All Projects',
              value: '',
            },
          ]}
        />,
        <Select
          value={dept}
          onChange={(e) => {
            setSection('');
            setDept(e);
          }}
          style={{ width: 120 }}
          dropdownMatchSelectWidth={false}
          placement={'bottomLeft'}
          options={[
            ...deptList.map((d) => ({
              label: d,
              value: d,
            })),
            {
              label: 'All Depts',
              value: '',
            },
          ]}
        />,
        <Select
          value={section}
          onChange={(e) => setSection(e)}
          style={{ width: 120 }}
          dropdownMatchSelectWidth={false}
          placement={'bottomLeft'}
          options={[
            ...sectionList.map((d) => ({
              label: d,
              value: d,
            })),
            {
              label: 'All Sections',
              value: '',
            },
          ]}
        />,
      ]}
    >
      <ProTable<Tool>
        columns={columns}
        params={{ project: project, dept: dept, section: section }}
        request={tools}
        //cardProps={{ title: 'Master Plan', bordered: true }}
        search={false}
        options={{
          search: true,
          fullScreen: true,
        }}
        rowKey={'id'}
        scroll={{ x: 1800 }}
        pagination={{
          pageSize: 10,
          showSizeChanger: false,
        }}
        //toolBarRender={() =>}
      />

      <Drawer
        width={600}
        open={showDetail}
        onClose={() => {
          setCurrentRow(undefined);
          setShowDetail(false);
        }}
        closable={false}
      >
        <ToolDetail tool={currentRow!} toolStages={toolStages} />
      </Drawer>
    </PageContainer>
  );
};

export default MasterPlan;
