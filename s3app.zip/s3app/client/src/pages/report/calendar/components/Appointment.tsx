import localization from 'devextreme/localization';

const Appointment = (model: any) =>{
    const { toolData } = model.data;

    console.log(toolData);
    
    return (
      <div className="showtime-preview">
        <div> {toolData.text}</div>
        <div>
          EQPID : <strong>${ toolData.eqpId }</strong>
        </div>
        <div>
          {localization.formatDate(toolData.displayStartDate, 'shortTime')}
          {' - '}
          {localization.formatDate(toolData.displayEndDate, 'shortTime')}
        </div>
      </div>
    );
  }
  
  export default Appointment;