import { stages } from '@/pages/setup/stage/services';
import { tools } from '@/pages/setup/tool/services';
import { toolStages } from '@/pages/setup/toolStage/services';
import { NumberOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-components';
import { useRequest } from '@umijs/max';
import { Card, Col, Dropdown, type MenuProps, message, Row, Select, Space, Tag, Button } from 'antd';
import Scheduler, { Editing, Resource } from 'devextreme-react/scheduler';
import 'devextreme/dist/css/dx.light.css';
import { useCallback, useEffect, useRef, useState } from 'react';
import Appointment from './components/Appointment';

const colors = [
  '#191970',
  '#4169E1',
  '#1E90FF',
  '#5F9EA0',
  '#708090',
  '#008080',
  '#66CDAA',
  '#556B2F',
  '#9ACD32',
  '#8FBC8F',
  '#006400',
  '#2E8B57',
  '#32CD32',
  '#FF6347',
  '#FF8C00',
  '#CD5C5C',
  '#E9967A',
  '#4B0082',
  '#483D8B',
  '#8B008B',
  '#BA55D3',
];

const priOptions = [
    {
        label: 'Priority 1',
        value: '1',
    }, {
        label: 'Priority 2',
        value: '2',
    }, {
        label: 'Priority 3',
        value: '3',
    },{ 
        label: 'All',
        value: '',
    }];


const CalendarView = () => {
  const { data: allTools } = useRequest(tools);
  const { data: allStages } = useRequest(stages);
  const { data: allToolStages } = useRequest(toolStages);

  const [selectedStage, setSelectedStage] = useState('');
  const [selectedDept, setSelectedDept] = useState('');
  const [scheduleData, setScheduleData] = useState<
    {
      text: string;
      stage: string;
      stageId: number;
      startDate: Date;
      endDate: Date;
    }[]
  >([]);

  const [stageOptions, setStageOptions] = useState<
    {
      label: string;
      value: string;
    }[]
  >([]);

  const [deptOptions, setDeptOptions] = useState<
    {
      label: string;
      value: string;
    }[]
  >([]);

  const [priority, setPriority] = useState<string>();
  const [resourceData, setResourceData] = useState<
    {
      text: string;
      id: number;
      color: string;
    }[]
  >([]);

  const handleButtonClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    message.info('Click on left button.');
    console.log('click left button', e);
  };


 
  useEffect(() => {
    if (allTools) {

        //console.log(allTools);

      let tmpArr: any[] = [];
    //   if (selectedStage && selectedStage.length > 0) {
        allTools
          .filter((t) =>((!selectedStage || t.currentStage === selectedStage) &&
                        (!selectedDept || t.area === selectedDept) &&
                        (!priority || t.priority?.toString() === priority)))
          .map((t) => {
            var toolStage = allToolStages?.find(s => s.toolId === t.id && s.stageName === t.currentStage);

            tmpArr.push({
              text: t.eqpId + '@' + t.currentStage,
              stage: t.currentStage,
              priority: t.priority,
              stageId: allStages?.find((s) => s.name === t.currentStage)?.seq,
              startDate: toolStage?.planDate? new Date(toolStage?.planDate?.substring(0, 10) + 'T09:00:00') : new Date(t.createAt?.substring(0, 10) + 'T09:00:00'),
              endDate: toolStage?.planDate? new Date(toolStage?.planDate?.substring(0, 10) + 'T15:00:00') : new Date(t.createAt?.substring(0, 10) + 'T15:00:00'),
            });
          });
    //   } else {
    //     allTools.map((t) => {
    //       tmpArr.push({
    //         text: t.eqpId,
    //         stage: t.currentStage,
    //         stageId: allStages?.find((s) => s.name === t.currentStage)?.seq,
    //         startDate: new Date(t.createAt?.substring(0, 10) + 'T09:00:00'),
    //         endDate: new Date(t.createAt?.substring(0, 10) + 'T15:00:00'),
    //       });
    //     });
    //   }
      setScheduleData(tmpArr);
    }

    if (allTools) {
      let tmpArr: any[] = [];
      allStages?.map((s) => {
        tmpArr.push({
          label: s.name,
          value: s.name,
        });
      });

      tmpArr.push({
        label: 'All Stages',
        value: '',
      });

      setStageOptions(tmpArr);

      tmpArr = [];
      Array.from(new Set(allTools.map((t) => t.area))).map((t) => {
        tmpArr.push({
          label: t,
          value: t,
        });
      });

      tmpArr.push({
        label: 'All Depts',
        value: '',
      });

      setDeptOptions(tmpArr);
    }
  }, [allTools, allStages, selectedStage, selectedDept, priority]);

  useEffect(() => {
    let tmpArr: any[] = [];

    if (allStages) {
      allStages.sort((s1,s2)=> s1?.seq-s2?.seq).map((s) => {
        tmpArr.push({
          text: s.name,
          id: s.seq,
          color: colors[s.seq! - 1],
        });
      });
    }

    setResourceData(tmpArr);
  }, [allStages]);

  //console.log(scheduleData);

  return (
    <>
      <PageContainer
        header={{
          title: 'Calendar View',
          ghost: false,
          breadcrumb: {
            items: [
              {
                path: 'report',
                title: 'Report',
              },
              {
                path: '',
                title: 'Calendar',
              },
            ],
          },
        }}
        content={'The calendar view of all tools progress.'}
        extra={[
          <Select
            placeholder="Select Stage"
            style={{ width: 180 }}
            options={stageOptions}
            value={selectedStage}
            onChange={(v) => setSelectedStage(v)}
          />,
          <Select
            placeholder="Select Dept"
            style={{ width: 160 }}
            options={deptOptions}
            value={selectedDept}
            onChange={(v) => setSelectedDept(v)}
          />,
          <Select
            placeholder="Priority"
            style={{ width: 100 }}
            options={priOptions}
            value={priority}
            onChange={(v) => setPriority(v)}
          />,
        ]}
      >
        <Space direction='vertical'>
        <Card>
          <Scheduler
            timeZone="Asia/Singapore"
            defaultCurrentView={'month'}
            views={['week', 'workWeek', 'month']}
            dataSource={scheduleData}
            startDayHour={8}
            endDayHour={18}
            height={650}
            showAllDayPanel={false}
            //appointmentComponent={Appointment}
            appointmentRender={(model) => {
              console.log(model);
              return (
                <>                
                  <i>{model.appointmentData.text}</i>
                  <p>{model.appointmentData.text}</p>
                </>
              );
            }}
          >
            <Editing
              allowAdding={false}
              allowDeleting={false}
              allowDragging={false}
              allowResizing={false}
              allowUpdating={false}
            />
            <Resource
              dataSource={resourceData}
              fieldExpr="stageId"
              label="Stage"
              useColorAsDefault={true}
            />
          </Scheduler>
        </Card>
        <Card>
            <Row style={{ padding: 2}}>
            {allStages?.sort((s1,s2)=>s1.seq-s2.seq).map((s, index) => (
              <Space direction='horizontal' size={1}>
              <Button style={{backgroundColor: colors[index], color: 'white'}}
                onClick={()=> setSelectedStage(s.name)
                }
              >{s.name}</Button>
                </Space>
            ))}
            </Row>
        </Card>
        </Space>
      </PageContainer>
    </>
  );
};

export default CalendarView;
