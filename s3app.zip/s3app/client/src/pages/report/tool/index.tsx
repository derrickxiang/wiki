import { stages } from '@/pages/setup/stage/services';
import { Tool } from '@/pages/setup/tool/data';
import { tools } from '@/pages/setup/tool/services';
import { toolStage } from '@/pages/setup/toolStage/services';
import { AlertOutlined } from '@ant-design/icons';
import {
  PageContainer,
  ProColumns,
  ProDescriptions,
  ProForm,
  ProFormCheckbox,
  ProFormDateRangePicker,
  ProFormDependency,
  ProFormItem,
  ProFormText,
  ProList,
} from '@ant-design/pro-components';
import { Link, useRequest } from '@umijs/max';
import { Button, Card, Checkbox, Col, Divider, Drawer, message, Popconfirm, Row, Space, Steps, Tag } from 'antd';
import { CheckboxChangeEvent } from 'antd/es/checkbox';
import { CheckboxValueType } from 'antd/es/checkbox/Group';
import dayjs from 'dayjs';
import moment from 'moment';
import { useEffect, useState } from 'react';
import ToolDetail from '../masterPlan/components/ToolDetail';
import { SearchOptions } from './data';

const ToolQuery = () => {
  const { data: allTools } = useRequest(tools);
  const { data: allStages } = useRequest(stages);

  const [stageOptions, setStageOptions] = useState<string[]>([]);
  const [entityOptions, setEntityOptions] = useState<string[]>([]);

  const [deptOptions, setDeptOptions] = useState<
    {
      label: string;
      value: string;
    }[]
  >([]);

  const {
    data: toolStages,
    run,
    refresh,
  } = useRequest(
    (toolId) => {
      return toolStage({ toolId: toolId });
    },
    {
      manual: true,
    },
  );


  const [searchOptions, setSearchOptions] = useState<SearchOptions>({});

  const [showDetail, setShowDetail] = useState<boolean>(false);
  const [currentRow, setCurrentRow] = useState<Tool>();

  const [checkedList, setCheckedList] = useState<CheckboxValueType[]>([]);
  const [entityList, setEntityList] = useState<CheckboxValueType[]>([]);
  const [indeterminate, setIndeterminate] = useState(true);
  const [checkAll, setCheckAll] = useState(false);

  const onChange = (list: CheckboxValueType[]) => {
    setCheckedList(list);
    setIndeterminate(!!list.length && list.length < stageOptions.length);
    setCheckAll(list.length === stageOptions.length);
  };

  const onEntityChange = (list: CheckboxValueType[]) => {
    setEntityList(list);
  }

  const onCheckAllChange = (e: CheckboxChangeEvent) => {
    setCheckedList(e.target.checked ? stageOptions : []);
    setIndeterminate(false);
    setCheckAll(e.target.checked);
  };

  const [searchResult, setSearchResult] = useState<Tool[]>([]);

  useEffect(() => {
    if (allTools) {
      let tmpArr: any[] = [];
      allStages?.map((s) => {
        tmpArr.push(s.name);
      });

      setStageOptions(tmpArr);

      tmpArr = [];
      Array.from(new Set(allTools.map((t) => t.area))).map((t) => {
        tmpArr.push({
          label: t,
          value: t,
        });
      });

      setDeptOptions(tmpArr);

      tmpArr = [];
      Array.from(new Set(allTools.filter((t) => t.entity).map((t) => t.entity))).map((t) => {
        tmpArr.push(t);
      });

      setEntityOptions(tmpArr);
    }
  }, [allTools, allStages]);

  return (
    <>
      <PageContainer
        header={{
          title: 'Tool Query',
          ghost: false,
          breadcrumb: {
            items: [
              {
                path: 'report',
                title: 'Report',
              },
              {
                path: '',
                title: 'Tool Query',
              },
            ],
          },
        }}
        content={'The complete tool query page.'}
      >
        <Space direction="vertical" size={'small'}>
          <Card title="Search Your Tool" >
            <ProForm
              labelCol={{ span: 4 }}
              wrapperCol={{ span: 20 }}
              layout={'horizontal'}
              title="Search Tool"
              onFinish={async (values: any) => {
                console.log(values);
               // console.log(moment(values.moveInRequired[0]).format('YYYY-MM-DD'));

                values.stage = checkedList.map((s) => s.toString());

                if (allTools) {
                  setSearchResult(
                    allTools.filter((t) => {
                      return (
                        (!values.eqpId || values.eqpId === t.eqpId) &&
                        (!values.area || !values.area.length || values.area.includes(t.area)) &&
                        (!values.section ||
                          !values.section.length ||
                          values.section.includes(t.section)) &&
                        (!values.stage ||
                          !values.stage.length ||
                          values.stage.includes(t.currentStage)) &&
                        (!values.toolClass ||
                          !values.toolClass.length ||
                          values.toolClass.includes(t.toolClass)) &&
                        (!values.priority ||
                          !values.priority.length ||
                          values.priority.includes(t.priority?.toString())) &&
                        (!values.entity ||
                          !values.entity.length ||
                          values.entity.includes(t.entity)) &&
                        (!values.moveInRequired ||
                          (!t.moveInReqDate &&
                           // moment(t.moveInReqDate!).isBetween(moment(values.moveInRequired[0]), moment(values.moveInRequired[1]),'day','[]')))
                           t.moveInReqDate! >= values.moveInRequired[0] && t.moveInReqDate! <= values.moveInRequired[1]))
                      );
                    }),
                  );
                }

                return true;
              }}
            >
              <ProFormCheckbox.Group label="Area" name={'area'} options={deptOptions} />
              <ProFormDependency name={['area']}>
                {({ area }) => {
                  if (area) {
                    const sections = Array.from(
                      new Set(allTools?.filter((s) => area.includes(s.area)).map((s) => s.section)),
                    );

                    return (
                      <ProFormCheckbox.Group label="Section" name="section" options={sections} />
                    );
                  }

                  return <ProFormCheckbox.Group label="Section" name="section" options={[]} />;
                }}
              </ProFormDependency>
              <ProFormItem label="Current Stage" name={'stage'}>
                <Checkbox
                  indeterminate={indeterminate}
                  onChange={onCheckAllChange}
                  checked={checkAll}
                >
                  All Stages
                </Checkbox>
                <Divider />
                <Checkbox.Group value={checkedList} onChange={onChange}>
                  <Row>
                    {stageOptions.map((s) => (
                      <Col span={5}>
                        <Checkbox value={s} key={s}>
                          {s}
                        </Checkbox>
                      </Col>
                    ))}
                  </Row>
                </Checkbox.Group>
              </ProFormItem>
              <ProFormCheckbox.Group label="Priority" name="priority" options={['1', '2', '3']} />
              <ProFormCheckbox.Group
                label="Type"
                name="toolClass"
                options={['FE', 'BE', 'MFE', 'MBE']}
              />
              {/* <ProFormItem
                label="Entity"
                name={'entity'}
                >
                  <Checkbox.Group value={entityList} onChange={onEntityChange}>
                    <Row>
                      { entityOptions.map((e)=> (
                        <Col span={5}>
                          <Checkbox value={e} key={e}>
                            {e}
                          </Checkbox>
                        </Col>
                      ))}
                    </Row>
                  </Checkbox.Group>
                </ProFormItem> */}
              

              <ProFormDateRangePicker label="Move In Date" name={'moveInRequired'} fieldProps={{format: 'YYYY-MM-DD'}} />
              <ProFormDateRangePicker label="PCRB Release" name={'pcrbRelease'} />
              <ProFormText name="eqpId" label="EQPID" width={250} />
            </ProForm>
          </Card>
          <Card>
            <ProList<Tool>
              rowKey="name"
              dataSource={searchResult}
              pagination={{
                defaultPageSize: 20,
                showSizeChanger: true,
              }}
              metas={{
                title: {
                  dataIndex: 'eqpId',
                  render: (text, row) => (
                    <a style={{color:'#454545'}} onClick={()=> {
                      setCurrentRow(row);
                      run(row.id);
                      setShowDetail(true);
                  }}>{row.eqpId}</a>
                  ),
                },
                description: {
                  dataIndex: 'tooltype',
                  render: (text, row) => (
                    <div>
                      {row.area}-{row.section}-{row.tooltype}-{row.entity}
                      <br /> {row.toolModel}
                    </div>
                  ),
                },
                subTitle: {
                  render: (text, row) => {
                    return (
                      <Space size={0}>
                        <Tag color="blue">Move In: {row.moveInReqDate}</Tag>
                        <Tag color="#5BD8A6">PCRB: {row.pcrbRelease}</Tag>
                      </Space>
                    );
                  },
                },
                content: {
                  dataIndex: 'eqpid',
                  render: (t, row) => (
                    <div key="label" style={{ display: 'flex', justifyContent: 'space-around' }}>
                      <div key="priority">
                        <div style={{ color: '#00000073' }}>Priority</div>
                        <div style={{ color: '#000000D9' }}>{row.priority}</div>
                      </div>
                      <div key="owner">
                        <div style={{ color: '#00000073' }}>Owner</div>
                        <div style={{ color: '#000000D9' }}>{row.eeOwner}</div>
                      </div>

                      <div key="current">
                        <div style={{ color: '#00000073' }}>Current Stage</div>
                        <div style={{ color: '#000000D9' }}>{row.currentStage}</div>
                      </div>

                      <div key="gap">
                        <div style={{ color: '#00000073' }}>Gap</div>
                        <div style={{ color: '#000000D9' }}>{row.stageGap}</div>
                      </div>
                    </div>
                  ),
                },
                actions: {
                  render: (text, row) => [
                    <a onClick={()=> {
                        setCurrentRow(row);
                        run(row.id);
                        setShowDetail(true);
                    }} key="detail">
                      View
                    </a>,
                    <Link to={`/execute/checklist?eqpid=${row.eqpId}&stage=${row.currentStage}`}>
                      Complete
                    </Link>,
                  ],
                },
              }}
            />
          </Card>
        </Space>

        <Drawer
        width={600}
        open={showDetail}
        onClose={() => {
          setCurrentRow(undefined);
          setShowDetail(false);
        }}
        closable={false}
      >
        <ToolDetail tool={currentRow!} toolStages={toolStages} />
      </Drawer>
      </PageContainer>
    </>
  );
};

export default ToolQuery;
