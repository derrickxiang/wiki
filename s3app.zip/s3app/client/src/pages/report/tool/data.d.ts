export type SearchOptions = {
    area?: string[];
    section?: string[];
    stage?: string[];
    priority?: string[];
    toolClass?: string[];
    entity?: string[];
    moveInRequired?: string[];
    pcrbRelease?: string[];
    eqpId?: string;
}