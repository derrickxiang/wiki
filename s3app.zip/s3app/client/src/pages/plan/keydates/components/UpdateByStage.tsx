import { stages } from '@/pages/setup/stage/services';
import { tools } from '@/pages/setup/tool/services';
import { ToolStage } from '@/pages/setup/toolStage/data';
import { toolStages, updateToolStage } from '@/pages/setup/toolStage/services';
import { ExclamationCircleFilled } from '@ant-design/icons';
import { ProForm, ProFormCheckbox, ProFormDatePicker } from '@ant-design/pro-components';
import { useModel, useRequest } from '@umijs/max';
import { Card, Col, Collapse, message, Modal, Row, Select, Tag } from 'antd';
import { useEffect, useState } from 'react';

const { Panel } = Collapse;

const handleUpdate = async (fields: ToolStage[]) => {
  const hide = message.loading('Updating ...');

  console.log(fields);

  try {
    fields.map((t) => {
      updateToolStage({ ...t });
    });

    hide();
    message.success('Stage setting update successful');
    return true;
  } catch (error) {
    hide();
    message.error('Failed to update Stage setting, pls try again!');
    return false;
  }
};

const UpdateByStage = () => {
  const { data: allTools } = useRequest(tools);
  const { data: allStages } = useRequest(stages);
  const { data: allToolStages } = useRequest(toolStages, { cacheKey: 'toolStage' });

  const [expandedKeys, setExpandedKeys] = useState<React.Key[]>([]);
  const [checkedKeys, setCheckedKeys] = useState<React.Key[]>([]);
  const [selectedKeys, setSelectedKeys] = useState<React.Key[]>([]);
  const [autoExpandParent, setAutoExpandParent] = useState<boolean>(true);

  const [toolTreeData, setToolTreeData] = useState<any[]>([]);
  const [selectedTools, setSelectedTools] = useState<string[]>([]);

  const [dept, setDept] = useState<string>();
  const [deptList, setDeptList] = useState<string[]>([]);

  const onExpand = (expandedKeysValue: React.Key[]) => {
    console.log('onExpand', expandedKeysValue);
    // if not set autoExpandParent to false, if children expanded, parent can not collapse.
    // or, you can remove all expanded children keys.
    setExpandedKeys(expandedKeysValue);
    setAutoExpandParent(false);
  };

  const onCheck = (checkedKeysValue: React.Key[]) => {
    console.log('onCheck', checkedKeysValue);
    setCheckedKeys(checkedKeysValue);
    setSelectedTools(checkedKeysValue.filter((t) => t.toString().startsWith('E_')) as string[]);
  };

  const onSelect = (selectedKeysValue: React.Key[], info: any) => {
    console.log('onSelect', info);
    setSelectedKeys(selectedKeysValue);
  };

  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};

  const [modal, contextHolder] = Modal.useModal();

  useEffect(() => {
    if (allTools) {
      setDeptList([...new Set(allTools.map((t) => t.area!))]);
    }
  }, [allTools]);

  return (
    <Row>
      <Col span={24}>
        <Card
          title="Stage List"
          style={{ minHeight: 600 }}
          extra={[
            <Select
              value={dept}
              onChange={(e) => setDept(e)}
              style={{ width: 120 }}
              dropdownMatchSelectWidth={false}
              placement={'topLeft'}
              options={[
                ...deptList.map((d) => ({
                  label: d,
                  value: d,
                })),
                {
                  label: 'All Depts',
                  value: '',
                },
              ]}
            />,
          ]}
        >
          <Collapse defaultActiveKey={[1]}>
            {allStages
              ?.sort((a, b) => a.seq - b.seq)
              .map((s) => (
                <Panel header={s.seq + '. ' + s.name} key={s.seq!}>
                  <ProForm
                    onFinish={(value: any) => {
                      value.stageId = s.id;
                      console.log(value);

                      if (value.tools) {
                        modal.confirm({
                          title: 'Confirm update the plan dates',
                          icon: <ExclamationCircleFilled />,
                          content: (
                            <p>
                              Pelease confirm to update the Plan Date for the below tools -
                              <br />
                              <br />
                              {value.tools.map((t) => (
                                <Tag key={'inner' + t} color={'volcano'}>
                                  {t}
                                </Tag>
                              ))}
                            </p>
                          ),
                          okText: 'Confirm Update',
                          cancelText: 'Cancel',
                          onOk() {
                            console.log('confirmed');
                            console.log(value);

                            let toolsToUpdate: ToolStage[] = [];

                            value.tools.map((t) => {
                              let toolStage = allToolStages?.find(
                                (s) => s.stageId === value.stageId && s.eqpId === t,
                              );

                              if (toolStage) {
                                toolsToUpdate.push({
                                  ...toolStage,
                                  planDate:
                                    value.planDate && value.planDate.length == 10
                                      ? value.planDate
                                      : value.planDate.format('YYYY-MM-DD'),
                                  planDateBy: currentUser?.empId,
                                });
                              }

                              //console.log(toolStage);
                            });

                            if (toolsToUpdate.length > 0) {
                              handleUpdate(toolsToUpdate);
                            } else {
                              message.warning('The tools have no such stage to update, pls check!');
                            }
                          },
                        });
                      }
                    }}
                  >
                    <ProFormCheckbox.Group
                      label="Select tools"
                      name="tools"
                      options={[
                        ...new Set(
                          allToolStages
                            ?.filter((t) => t.stageId === s.id && (dept === '' || dept === t.area))
                            .map((ts) => ts.eqpId!),
                        ),
                      ]}
                      rules={[
                        {
                          required: true,
                          message: 'Please select tool',
                        },
                      ]}
                    />

                    <ProFormDatePicker
                      label="Set plan date"
                      name={'planDate'}
                      fieldProps={{
                        format: (value) => value.format('YYYY-MM-DD'),
                      }}
                      rules={[
                        {
                          required: true,
                          message: 'Please set date',
                        },
                      ]}
                    />

                    {contextHolder}
                  </ProForm>
                </Panel>
              ))}
          </Collapse>
        </Card>
      </Col>
    </Row>
  );
};

export default UpdateByStage;
