import { Stage } from '@/pages/setup/stage/data';
import { stages } from '@/pages/setup/stage/services';
import { tools } from '@/pages/setup/tool/services';
import { ToolStage } from '@/pages/setup/toolStage/data';
import { toolStages, updateToolStage } from '@/pages/setup/toolStage/services';
import { ConsoleSqlOutlined, ExclamationCircleFilled } from '@ant-design/icons';
import { ProCard, ProForm, ProFormDatePicker, ProFormSelect } from '@ant-design/pro-components';
import { useModel, useRequest } from '@umijs/max';
import { Button, Card, Col, message, Modal, Row, Tag, Tree } from 'antd';
import React, { useEffect, useState } from 'react';

interface Props {
  tools: string[];
  stage: Stage | undefined;
}


const handleUpdate = async (fields: ToolStage[]) => {
    const hide = message.loading('Updating ...');
  
    console.log(fields);

    try {
        fields.map(t => {
            updateToolStage({ ...t });
        })
      
      hide();
      message.success('Stage setting update successful');
      return true;
    } catch (error) {
      hide();
      message.error('Failed to update Stage setting, pls try again!');
      return false;
    }
  };

const ToolCards = ({ tools, stage }: Props) => {
  const { data: allToolStages } = useRequest(toolStages, 
    {
        pollingInterval: 5000,
        cacheKey: 'toolStage'
    });

  return (
    <ProCard key={'toolCards'} style={{ paddingInline: 0, padding: 0 }} gutter={[8, 8]} wrap>
      {tools.map((t) => (
        <ProCard
          key={t.replace('E_', '')}
          title={t.replace('E_', '')}
          colSpan={{ md:8, lg: 6, sm: 12}}
          style={{ paddingInline: 0 }}
          size={'small'}
          extra={<Tag color={allToolStages?.find((s)=> s.eqpId=== t.replace('E_','') && s.stageId === stage?.id) && 'cyan'}>{stage?.name}</Tag>}
          bordered
        >
          <b>R. Date:</b>{' '} 
          {allToolStages &&
            stage &&
            allToolStages
              .find((s) => s.eqpId === t.replace('E_', '') && s.stageId === stage.id)
              ?.requireDate?.substring(0, 10)}
          <br />
          <b>P. Date:</b>{' '}
          {allToolStages &&
            stage &&
            allToolStages
              .find((s) => s.eqpId === t.replace('E_', '') && s.stageId === stage.id)
              ?.planDate?.substring(0, 10)}
        </ProCard>
      ))}
    </ProCard>
  );
};

const UpdateByTool = () => {
  const { data: allTools } = useRequest(tools);
  const { data: allStages } = useRequest(stages);
  const { data: allToolStages } = useRequest(toolStages);

  const [expandAll, setExpandAll] = useState(false);
  const [expandedKeys, setExpandedKeys] = useState<React.Key[]>([]);
  const [checkedKeys, setCheckedKeys] = useState<React.Key[]>([]);
  const [selectedKeys, setSelectedKeys] = useState<React.Key[]>([]);
  const [allToolKeys, setAllToolKeys] = useState<React.Key[]>([]);
  const [autoExpandParent, setAutoExpandParent] = useState<boolean>(true);

  const [toolTreeData, setToolTreeData] = useState<any[]>([]);
  const [selectedTools, setSelectedTools] = useState<string[]>([]);
  const [selectedStage, setSelectedStage] = useState<string>('');

  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};

  const onExpand = (expandedKeysValue: React.Key[]) => {
    console.log('onExpand', expandedKeysValue);
    // if not set autoExpandParent to false, if children expanded, parent can not collapse.
    // or, you can remove all expanded children keys.
    setExpandedKeys(expandedKeysValue);
    setAutoExpandParent(false);
  };

  const onCheck = (checkedKeysValue: React.Key[]) => {
    console.log('onCheck', checkedKeysValue);
    setCheckedKeys(checkedKeysValue);
    setSelectedTools(checkedKeysValue.filter((t) => t.toString().startsWith('E_')) as string[]);
  };

  const onSelect = (selectedKeysValue: React.Key[], info: any) => {
    console.log('onSelect', info);
    setSelectedKeys(selectedKeysValue);
  };

  const [modal, contextHolder] = Modal.useModal();

  const confirmUpdate = () => {
    modal.confirm({
        title: 'Confirm update the plan dates',
        icon: <ExclamationCircleFilled />,
        content: 'Pelease confirm to update the Plan Date for the below tools - ' + selectedTools.join(),
        okText: 'Confirm Update',
        cancelText: 'Cancel',
        onOk: ()=> {
            
        }
    })
  }

  useEffect(() => {
    if (allTools) {
      setToolTreeData(
        [...new Set(allTools.map((t) => t.area))].map((d) => ({
          title: d,
          key: 'D_' + d,
          children: [...new Set(allTools.filter((t) => t.area === d).map((t) => t.section))].map(
            (s) => ({
              title: s,
              key: 'D_' + d + '_S_' + s,
              children: [...new Set(allTools.filter((t) => t.area === d && t.section === s))].map(
                (t) => ({
                  title: t.eqpId,
                  key: 'E_' + t.eqpId,
                }),
              ),
            }),
          ),
        })),
      );

      setAllToolKeys([
        ...new Set(allTools.map((t) => 'D_' + t.area)),
        ...new Set(allTools.map((t) => 'D_' + t.area + '_S_' + t.section)),
        ...new Set(allTools.map((t) => 'E_' + t.eqpId)),
      ]);
    }
  }, [allTools]);

  return (
    <Row gutter={8}>
      <Col span={6}>
        <Card
          title="Select Tools"
          style={{ minHeight: 600 }}
          extra={[
            <Button
              type="link"
              onClick={() => {
                if (expandAll) {
                  setExpandedKeys([]);
                } else {
                  setExpandedKeys(allToolKeys);
                }
                setExpandAll(!expandAll);
              }}
            >
              {expandAll ? 'Collapse all' : 'Expand all'}
            </Button>,
          ]}
        >
          <Tree
            checkable
            onExpand={onExpand}
            showLine={true}
            expandedKeys={expandedKeys}
            autoExpandParent={autoExpandParent}
            onCheck={onCheck}
            checkedKeys={checkedKeys}
            onSelect={onSelect}
            selectedKeys={selectedKeys}
            treeData={toolTreeData}
          />
        </Card>
      </Col>
      <Col span={18}>
        <Card
          title="Update Plan Date"
          extra={
            <>
              Selected tools: <Tag color={'orange-inverse'}>{selectedTools.length}</Tag>
            </>
          }
          style={{ minHeight: 600 }}
        >
          <ToolCards
            tools={selectedTools}
            stage={allStages && allStages.find((s) => s.id === selectedStage)}
          />

          <ProForm 
          style={{ marginTop: 8 }} 
          disabled={selectedTools.length === 0}
          onFinish={async (value: any) =>{

            modal.confirm({
                title: 'Confirm update the plan dates',
                icon: <ExclamationCircleFilled />,
                content: (<p>Pelease confirm to update the Plan Date for the below tools - 
                    <br/><br/> 
                    {selectedTools.map(t => (
                        <Tag key={'inner'+t} color={'volcano'}>{t.replace('E_','')}</Tag>
                    ))} 
                    </p>),
                okText: 'Confirm Update',
                cancelText: 'Cancel',
                onOk(){
                    console.log('confirmed');
                    console.log(value);

                    let toolsToUpdate : ToolStage[] = [];
                    
                    selectedTools.map(t => {
                        let toolStage = allToolStages?.find(s => s.stageId === value.stageId && s.eqpId === t.replace('E_',''));

                        if (toolStage) {
                            toolsToUpdate.push({...toolStage, 
                                planDate:( value.planDate && value.planDate.length == 10) ? value.planDate : value.planDate.format('YYYY-MM-DD'),
                                planDateBy: currentUser?.empId,
                            });
                        }
                        
                        //console.log(toolStage);
                    });

                    if (toolsToUpdate.length > 0) {
                        handleUpdate(toolsToUpdate);
                    } else {
                        message.warning("The tools have no such stage to update, pls check!");
                    }
                }
            })

          }}
          
          >
            <ProFormSelect
              label="Stage"
              name={'stageId'}
              width={'sm'}
              fieldProps={{
                onChange: (e) => setSelectedStage(e),
                value: selectedStage,
              }}
              rules={[
                {
                  required: true,
                  message: 'Please select a stage',
                },
              ]}
              options={allStages
                ?.sort((a, b) => a.seq - b.seq)
                .map((s) => ({
                  label: s.name,
                  value: s.id,
                }))}
            />
            <ProFormDatePicker
              label="Update Plan Date"
              name={'planDate'}
              dataFormat='YYYY-MM-DD'
              rules={[
                {
                  required: true,
                  message: 'Please select a date',
                },
              ]}
            ></ProFormDatePicker>
          </ProForm>
          {contextHolder}
        </Card>
      </Col>
    </Row>
  );
};

export default UpdateByTool;
