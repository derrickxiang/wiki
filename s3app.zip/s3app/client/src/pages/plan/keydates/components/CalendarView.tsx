import { Stage } from "@/pages/setup/stage/data";
import { stages } from "@/pages/setup/stage/services";
import { Tool } from "@/pages/setup/tool/data";
import { tools } from "@/pages/setup/tool/services";
import ToolChecklistSetup from "@/pages/setup/toolChecklist";
import { ToolStage } from "@/pages/setup/toolStage/data";
import { toolStages } from "@/pages/setup/toolStage/services";
import { useRequest } from "@umijs/max";
import { Badge, BadgeProps, Button, Calendar, Card, Col, Modal, Row, Select, Space, Tag } from "antd";
import type { Dayjs } from 'dayjs';
import type { CellRenderInfo } from 'rc-picker/lib/interface';
import React, { ReactElement, useEffect, useState } from "react";



const CalendarView = () => {

    const { data: allTools} = useRequest(tools);
    const { data: allStages } = useRequest(stages);
    const { data: allToolStages } = useRequest(toolStages);

    const getListData = (value: Dayjs) => {
        let listData: { tool: Tool|undefined, stage: Stage|undefined, toolStage: ToolStage}[] = [];
        console.log(value.format('YYYY-MM-DD'));
    
        let stages = allToolStages?.filter(s =>(s.planDate?.substring(0,10) === value.format('YYYY-MM-DD')));

        if (dept) {
          stages = stages?.filter(s => s.area === dept);
        }

        if (stages) {
            stages.map(t => {
                listData.push({
                        tool: allTools?.find(a=>a.eqpId === t.eqpId),
                        stage: allStages?.find(s=>s.id === t.stageId),
                        toolStage: t
                    })                
                  })
        }
    
        
        return listData || [];
      };

    const dateCellRender = (value: Dayjs) => {
        const listData = getListData(value);
        return (
          <ul style={{ paddingLeft: 0}}>
            {listData.map((item) => (
              <li key={item.toolStage.id}>
                <Tag color={'blue'}>{item.tool?.eqpId}</Tag>
              </li>
            ))}
          </ul>
        );
      };

    const cellRender = (current: Dayjs, info: CellRenderInfo<Dayjs>) => {
        if (info.type === 'date') return dateCellRender(current);
        return info.originNode;
      };

    const onSelect = (value: Dayjs) => {

        setModalTitle("Detail Info");

        const listData = getListData(value);

        if (listData.length > 0) {
          setModalBody(
            <Space direction="vertical">
                <p>There are {listData.length} tool(s) scheduled today ({value.format('YYYY-MM-DD')}) :
                </p>
    
                {
                    listData.map(s => 
                      <>
                        <Tag key={'cal'+s.tool?.eqpId} color={'volcano'}>{s.tool?.eqpId}</Tag> 
                        </>
                    )
                }
            </Space>)
            showModal();
        }
       
    }

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [modalTitle, setModalTitle] = useState('');
    const [modalBody, setModalBody] = useState<ReactElement>();

    const [dept, setDept] = useState<string>();
  const [deptList, setDeptList] = useState<string[]>([]);


  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleOk = () => {
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  useEffect(() => {
    if (allTools) {
      setDeptList([...new Set(allTools.map((t) => t.area!))]);
    }
  }, [allTools]);

    return (
        <Card 
        title="Calendar view"
        extra={[
          <Select
            value={dept}
            onChange={(e) => setDept(e)}
            style={{ width: 120 }}
            dropdownMatchSelectWidth={false}
            placement={'topLeft'}
            options={[
              ...deptList.map((d) => ({
                label: d,
                value: d,
              })),
              {
                label: 'All Depts',
                value: '',
              },
            ]}
          />,
        ]}
        >
            <Row>
                <Col span="24">
                    <Calendar onSelect={onSelect} cellRender={cellRender} />
                </Col>
            </Row>

            <Modal title={modalTitle} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
       {modalBody}
      </Modal>
        </Card>

    )
}

export default CalendarView;