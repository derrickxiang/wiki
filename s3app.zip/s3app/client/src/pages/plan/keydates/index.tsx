import { PageContainer } from '@ant-design/pro-components';
import CalendarView from './components/CalendarView';
import UpdateByStage from './components/UpdateByStage';
import UpdateByTool from './components/UpdateByTool';

const KeyDatesUpdate = () => {
  return (
    <PageContainer
      header={{
        title: 'Stage Plan Date Update',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'execute',
              title: 'Plan',
            },
            {
              path: '',
              title: 'Stage Plan Date Update',
            },
          ],
        },
      }}
      content={'Update tool release stage plan dates.'}
      tabList={[
        {
          tab: 'Update By Tool',
          key: 'byTool',
          children: <UpdateByTool />,
        },
        {
          tab: 'Update By Stage',
          key: 'byStage',
          children: <UpdateByStage />,
        },
        {
          tab: 'Calendar View',
          key: 'calendar',
          children: <CalendarView />,
        },
      ]}
    ></PageContainer>
  );
};

export default KeyDatesUpdate;
