import { request } from "umi";
import { Stage } from "./data";


export async function stages (
    params: {
        currentPage?: number;
        pageSize?: number;
        name?: string;
        tier?: string;
        category?: string;
    },
    options?: Record<string, any>,
    ) {
        return request<{
            data: Stage[];
            total?: Number;
            success?: Boolean;
        }>('/api/stage', {
            method: 'GET',
            params: {
                ...params,
            },
            ...(options || {}),
        });
    }

export async function addStage(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: Stage[];
    }>('/api/stage', {
        data,
        method: 'POST',
        ...(options || {}),
    });
}

export async function removeStage(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: Stage[];
    }>('/api/stage', {
        data,
        method: 'DELETE',
        ...(options || {}),
    });
}

export async function updateStage(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<Stage>('/api/stage', {
        data,
        method: 'PUT',
        ...(options || {}),
    });
}

export async function getSignOffGroups(
    params: {
      currentPage?: number;
      pageSize?: number;
    },
    options?: Record<string, any>,
  ) {
    return request<{
      data: any[];
      success?: Boolean;
    }>('/api/signoff/groups', {
      method: 'GET',
      params: {
        ...params,
      },
      ...(options || {}),
    });
  }