import { getDeptEmployee, getSections } from '@/components/PeopleSelect/services';
import { PlusOutlined } from '@ant-design/icons';
import {
  ActionType,
  ModalForm,
  PageContainer,
  ProColumns,
  ProFormDependency,
  ProFormDigit,
  ProFormGroup,
  ProFormRadio,
  ProFormSelect,
  ProFormText,
  ProFormTextArea,
  ProFormTreeSelect,
  ProTable,
} from '@ant-design/pro-components';
import { FormattedMessage, useModel, useRequest } from '@umijs/max';
import { Button, Divider, message, Popconfirm } from 'antd';
import moment from 'moment';
import { useEffect, useRef, useState } from 'react';
import { Stage, StageParam } from './data';
import { addStage, getSignOffGroups, removeStage, stages, updateStage } from './services';

const handleAdd = async (fields: Stage) => {
  const hide = message.loading('Adding new stage ...');

  try {
    await addStage({ ...fields });
    hide();
    message.success('Stage create successful');
    return true;
  } catch (error) {
    hide();
    message.error('Failed to create stage, pls try again!');
    return false;
  }
};

const handleUpdate = async (fields: Stage) => {
  const hide = message.loading('Updating ...');

  try {
    await updateStage({ ...fields });
    hide();
    message.success('Stage update successful');
    return true;
  } catch (error) {
    hide();
    message.error('Failed to update prject, pls try again!');
    return false;
  }
};

const handleDelete = async (selectedRow: Stage) => {
  const hide = message.loading('Deleting ...');
  try {
    await removeStage({ stageId: selectedRow.id });
    hide();
    message.success('Stage delete successful');

    return true;
  } catch (error) {
    hide();
    message.error('Failed to delete stage, pls try again!');
    return false;
  }
};

const SetupStage = () => {
  const [createModalVisible, handleModalVisible] = useState(false);
  const [updateModalVisible, handleUpdateModalVisible] = useState(false);
  const { data: allStage } = useRequest(stages);

  const [stageOwner, setStageOwner] = useState<string>();
  const [stageSignoff, setStageSignoff] = useState<string>();
  const { data: signOffGroups } = useRequest(getSignOffGroups);

  const [selectedStage, setSelectedStage] = useState<Stage>();
  const actionRef = useRef<ActionType>();

  const [queryParam, setQueryParam] = useState<StageParam>();

  const columns: ProColumns<Stage>[] = [
    {
      title: 'Name',
      dataIndex: 'name',
    },
    {
      title: 'Description',
      dataIndex: 'description',
      hideInSearch: true,
    },
    {
      title: 'Tier',
      dataIndex: 'tier',
      filters: true,
      onFilter: true,
      valueType: 'select',
      valueEnum: {
        0: { text: '0' },
        1: { text: '1' },
        2: { text: '2' },
      },
      sorter: (a, b) => {
        return a.tier - b.tier;
      },
    },
    {
      title: 'Category',
      dataIndex: 'category',
      valueType: 'select',
      valueEnum: {
        main: { text: 'Main' },
        sub: { text: 'Sub' },
      },
    },
    {
      title: 'SEQ',
      dataIndex: 'seq',
      hideInSearch: true,
      sorter: (a, b) => a.seq - b.seq,
    },
    {
      title: 'Lead Time(Day)',
      dataIndex: 'leadTime',
      hideInSearch: true,
    },
    {
      title: 'Stage Owner',
      dataIndex: 'owner',
      hideInSearch: true,
    },
    {
      title: 'Sign off',
      dataIndex: 'signOff',
      hideInSearch: true,
    },
    {
      title: 'Timeslot',
      dataIndex: 'bookTimeSlot',
      hideInSearch: true,
    },
    {
      title: 'Create At',
      dataIndex: 'createAt',
      hideInSearch: true,
    },
    {
      title: 'Create By',
      dataIndex: 'createBy',
      hideInSearch: true,
    },
    {
      title: 'Action',
      dataIndex: 'option',
      valueType: 'option',
      sorter: false,
      render: (_, record: Stage) => [
        <a
          key={'config'}
          onClick={async () => {
            setSelectedStage(record);
            handleUpdateModalVisible(true);
          }}
        >
          Edit
        </a>,
        <Popconfirm
          title="Delete the Stage"
          description="Are you sure to delete this stage?"
          onConfirm={async (e: React.MouseEvent<HTMLElement>) => {
            handleDelete(record);

            setSelectedStage(undefined);

            if (actionRef.current) {
              actionRef.current?.reload();
            }
          }}
          okText="Yes"
          cancelText="No"
        >
          <a key="remove">Remove</a>
        </Popconfirm>,
      ],
    },
  ];

  const [allStages, setAllStages] = useState<{ label: string; value: string }[]>([]);

  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};

  useEffect(() => {
    if (allStage) {
      setAllStages(
        allStage?.map(({ name }) => ({
          label: name!,
          value: name!,
        })),
      );
    }
  }, [allStage]);
  return (
    <PageContainer
      header={{
        title: 'Stage Setup',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'setup',
              title: 'Setup',
            },
            {
              path: '',
              title: 'Stage Setup',
            },
          ],
        },
      }}
      content={'A stage indicates a tool release phase.'}
    >
      <ProTable<Stage, StageParam>
        headerTitle="Stage Info"
        rowKey={'id'}
        actionRef={actionRef}
        columns={columns}
        request={stages}
        search={{
          labelWidth: 'auto',
        }}
        toolBarRender={() => [
          <Button
            type="primary"
            key={'add'}
            onClick={() => {
              handleModalVisible(true);
            }}
          >
            <PlusOutlined /> New
          </Button>,
        ]}
      />

      <ModalForm
        title="Create new Stage"
        width={600}
        open={createModalVisible}
        onOpenChange={handleModalVisible}
        onFinish={async (value: Stage) => {
          console.log(value);

          value.createAt = moment().format('YYYY-MM-DDTHH:mm:ss');
          // value.owner = stageOwner;
          // value.signOff = stageSignoff;

          if (currentUser) value.createBy = currentUser?.userId;

          const success = await handleAdd(value);
          if (success) {
            handleModalVisible(false);

            if (actionRef.current) {
              actionRef.current.reload();
            }
          }
        }}
      >
        <ProFormText
          label="Name"
          width={'md'}
          name="name"
          rules={[
            {
              required: true,
              message: (
                <FormattedMessage
                  id="pages.setup.stage.name"
                  defaultMessage="Stage name is required!"
                />
              ),
            },
          ]}
        />
        <ProFormTextArea label="Description" name="description" />

        <ProFormRadio.Group
          name="category"
          label={'Category'}
          initialValue="main"
          options={[
            {
              label: 'Main Stage',
              value: 'main',
            },
            {
              label: 'Sub Stage',
              value: 'sub',
            },
          ]}
        />
        <ProFormSelect
          name={'tier'}
          label="Tier"
          rules={[
            {
              required: true,
              message: 'Tier no is required!',
            },
          ]}
          options={[
            {
              label: '0',
              value: 0,
            },
            {
              label: '1',
              value: 1,
            },
            {
              label: '2',
              value: 2,
            },
            {
              label: '3',
              value: 3,
            },
          ]}
        />
        <ProFormDigit
          name={'seq'}
          label="Sequence"
          min={1}
          max={100}
          tooltip={'A number to indicate the stage sequence.'}
          rules={[
            {
              required: true,
              message: 'Seq no is required!',
            },
          ]}
        />
        <ProFormDigit name={'leadTime'} label="Lead Time (days)" min={0} max={100} />

        <ProFormRadio.Group
          name={'bookTimeSlot'}
          label="Need book time slot?"
          initialValue={'N'}
          options={[
            {
              label: 'Required',
              value: 'Y',
            },
            {
              label: 'Not Required',
              value: 'N',
            },
          ]}
        />

        <Divider orientation="left">Assign Stage Owner</Divider>
        <ProFormSelect
          name={'owner'}
          placeholder="Please select"
          width={200}
          secondary
          options={signOffGroups?.map((s) => ({ label: s.name, value: s.name }))}
        />
        {/* <ProFormGroup direction="horizontal">
          <ProFormTreeSelect
            name="section"
            placeholder="Please select dept"
            allowClear
            width={200}
            secondary
            request={getSections}
            treeline={true}
            // tree-select args
            fieldProps={{
              showArrow: true,
              filterTreeNode: true,
              showSearch: true,
              dropdownMatchSelectWidth: false,
              labelInValue: false,
              autoClearSearchValue: true,
              multiple: false,
              treeNodeFilterProp: 'title',
              fieldNames: {
                label: 'title',
              },
            }}
          />

          <ProFormDependency name={['section']}>
            {({ section }) => {
              if (section) {
                return (
                  <ProFormSelect
                    name={'people'}
                    mode="multiple"
                    width={300}
                    placeholder="Please select employee"
                    params={{
                      dept: section,
                    }}
                    allowClear={false}
                    onChange={(v: string[]) => setStageOwner(v.join())}
                    request={getDeptEmployee}
                    fieldProps={{
                      optionItemRender(item) {
                        return item.title;
                      },
                    }}
                    fieldNames={{
                      label: 'title',
                    }}
                  />
                );
              } else {
                return (
                  <ProFormSelect
                    name={'people'}
                    mode="multiple"
                    width={300}
                    placeholder="Please select employee"
                  />
                );
              }
            }}
          </ProFormDependency>
        </ProFormGroup> */}
        <Divider orientation="left">Set Stage Sign off</Divider>
        <ProFormSelect
          name={'signOff'}
          placeholder="Please select"
          width={200}
          secondary
          options={signOffGroups?.map((s) => ({ label: s.name, value: s.name }))}
        />
        {/* <ProFormGroup direction="horizontal">
       
          <ProFormTreeSelect
            name="signOffSection"
            placeholder="Please select dept"
            allowClear
            width={200}
            secondary
            request={getSections}
            treeline={true}
            // tree-select args
            fieldProps={{
              showArrow: true,
              filterTreeNode: true,
              showSearch: true,
              dropdownMatchSelectWidth: false,
              labelInValue: false,
              autoClearSearchValue: true,
              multiple: false,
              treeNodeFilterProp: 'title',
              fieldNames: {
                label: 'title',
              },
            }}
          />

          <ProFormDependency name={['signOffSection']}>
            {({ signOffSection }) => {
              if (signOffSection) {
                return (
                  <ProFormSelect
                    name={'signOffPeople'}
                    mode="multiple"
                    width={300}
                    placeholder="Please select employee"
                    params={{
                      dept: signOffSection,
                    }}
                    allowClear={false}
                    onChange={(v: string[]) => setStageSignoff(v.join())}
                    request={getDeptEmployee}
                    fieldProps={{
                      optionItemRender(item) {
                        return item.title;
                      },
                    }}
                    fieldNames={{
                      label: 'title',
                    }}
                  />
                );
              } else {
                return (
                  <ProFormSelect
                    name={'signOffPeople'}
                    mode="multiple"
                    width={300}
                    placeholder="Please select employee"
                  />
                );
              }
            }}
          </ProFormDependency>
        </ProFormGroup> */}
      </ModalForm>

      <ModalForm
        title="Update Stage Info"
        width={600}
        open={updateModalVisible}
        onOpenChange={handleUpdateModalVisible}
        initialValues={selectedStage}
        params={selectedStage}
        request={(params) => {
          return Promise.resolve({
            data: params,
            success: true,
          });
        }}
        onFinish={async (value: Stage) => {
          console.log(value);

          if (selectedStage) {
            value.id = selectedStage.id;
          }

          value.createAt = moment().format('YYYY-MM-DDTHH:mm:ss');
          // value.owner = stageOwner;
          // value.signOff = stageSignoff;

          if (currentUser) value.createBy = currentUser?.userId;

          const success = await handleUpdate(value);
          if (success) {
            handleUpdateModalVisible(false);

            if (actionRef.current) {
              actionRef.current.reload();
            }
          }
        }}
      >
        <ProFormText
          label="Name"
          width={'md'}
          name="name"
          initialValue={selectedStage?.name}
          rules={[
            {
              required: true,
              message: (
                <FormattedMessage
                  id="pages.setup.stage.name"
                  defaultMessage="Stage name is required!"
                />
              ),
            },
          ]}
        />
        <ProFormTextArea
          label="Description"
          initialValue={selectedStage?.description}
          name="description"
        />

        <ProFormRadio.Group
          name="category"
          label={'Category'}
          initialValue={selectedStage?.category}
          options={[
            {
              label: 'Main Stage',
              value: 'main',
            },
            {
              label: 'Sub Stage',
              value: 'sub',
            },
          ]}
        />
        <ProFormSelect
          name={'tier'}
          label="Tier"
          initialValue={selectedStage?.tier}
          rules={[
            {
              required: true,
              message: 'Tier no is required!',
            },
          ]}
          options={[
            {
              label: '0',
              value: 0,
            },
            {
              label: '1',
              value: 1,
            },
            {
              label: '2',
              value: 2,
            },
            {
              label: '3',
              value: 3,
            },
          ]}
        />
        <ProFormDigit
          name={'seq'}
          label="Sequence"
          initialValue={selectedStage?.seq}
          min={1}
          max={100}
          tooltip={'A number to indicate the stage sequence.'}
          rules={[
            {
              required: true,
              message: 'Seq no is required!',
            },
          ]}
        />
        <ProFormDigit
          name={'leadTime'}
          label="Lead Time (days)"
          initialValue={selectedStage?.leadTime}
          min={0}
          max={100}
        />
        <ProFormRadio.Group
          name={'bookTimeSlot'}
          label="Need book time slot?"
          initialValue={'N'}
          options={[
            {
              label: 'Required',
              value: 'Y',
            },
            {
              label: 'Not Required',
              value: 'N',
            },
          ]}
        />
        <Divider orientation="left">Assign Stage Owner</Divider>
        <ProFormSelect
          name={'owner'}
          placeholder="Please select"
          width={200}
          secondary
          options={signOffGroups?.map((s) => ({ label: s.name, value: s.name }))}
        />
        {/* <ProFormGroup direction="horizontal">
          <ProFormTreeSelect
            name="section"
            placeholder="Please select dept"
            allowClear
            width={200}
            secondary
            request={getSections}
            treeline={true}
            // tree-select args
            fieldProps={{
              showArrow: true,
              filterTreeNode: true,
              showSearch: true,
              dropdownMatchSelectWidth: false,
              labelInValue: false,
              autoClearSearchValue: true,
              multiple: false,
              treeNodeFilterProp: 'title',
              fieldNames: {
                label: 'title',
              },
            }}
          />

          <ProFormDependency name={['section']}>
            {({ section }) => {
              if (section) {
                return (
                  <ProFormSelect
                    name={'owner'}
                    mode="multiple"
                    width={300}
                    placeholder="Please select employee"
                    params={{
                      dept: section,
                    }}
                    allowClear={false}
                    initialValue={selectedStage?.owner}
                    onChange={(v: string[]) => setStageOwner(v.join())}
                    request={getDeptEmployee}
                    fieldProps={{
                      optionItemRender(item) {
                        return item.title;
                      },
                    }}
                    fieldNames={{
                      label: 'title',
                    }}
                  />
                );
              } else {
                return (
                  <ProFormSelect
                    name={'owner'}
                    mode="multiple"
                    width={300}
                    placeholder="Please select employee"
                  />
                );
              }
            }}
          </ProFormDependency>
        </ProFormGroup> */}
        <Divider orientation="left">Set Stage Sign off</Divider>
        <ProFormSelect
          name={'signOff'}
          placeholder="Please select"
          width={200}
          secondary
          options={signOffGroups?.map((s) => ({ label: s.name, value: s.name }))}
        />

        {/* <ProFormGroup direction="horizontal">
          <ProFormTreeSelect
            name="signOffSection"
            placeholder="Please select dept"
            allowClear
            width={200}
            secondary
            request={getSections}
            treeline={true}
            // tree-select args
            fieldProps={{
              showArrow: true,
              filterTreeNode: true,
              showSearch: true,
              dropdownMatchSelectWidth: false,
              labelInValue: false,
              autoClearSearchValue: true,
              multiple: false,
              treeNodeFilterProp: 'title',
              fieldNames: {
                label: 'title',
              },
            }}
          />

          <ProFormDependency name={['signOffSection']}>
            {({ signOffSection }) => {
              if (signOffSection) {
                return (
                  <ProFormSelect
                    name={'signOffPeople'}
                    mode="multiple"
                    width={300}
                    placeholder="Please select employee"
                    params={{
                      dept: signOffSection,
                    }}
                    allowClear={false}
                    initialValue={selectedStage?.SignOff}
                    onChange={(v: string[]) => setStageSignoff(v.join())}
                    request={getDeptEmployee}
                    fieldProps={{
                      optionItemRender(item) {
                        return item.title;
                      },
                    }}
                    fieldNames={{
                      label: 'title',
                    }}
                  />
                );
              } else {
                return (
                  <ProFormSelect
                    name={'signOffPeople'}
                    mode="multiple"
                    width={300}
                    placeholder="Please select employee"
                  />
                );
              }
            }}
          </ProFormDependency>
        </ProFormGroup> */}
      </ModalForm>
    </PageContainer>
  );
};

export default SetupStage;
