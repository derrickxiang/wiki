
export type Stage = {
    id?: string;
    name?: string;
    description?: string;
    seq?: number;
    tier?: number;
    category?: string;
    owner?: string;
    SignOff?: string;
    leadTime?: number;
    createAt?: string;
    createBy?: string;
}

export type StageParam = {
    current?: number;
    tier?: number;
    name?: string;
    seq?: number;
  total?: number;
  pageSize?: number;
  currentPage?: number;
}