import { request } from "@umijs/max";
import { Stage } from "../stage/data";
import { StageChecklist } from "../stageChecklist/data";

export async function uploadStage(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: Stage[];
    }>('/api/stage/batch', {
        data,
        method: 'POST',
        ...(options || {}),
    });
}

export async function uploadStageChecklist(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: StageChecklist[];
    }>('/api/stageChecklist/batch', {
        data,
        method: 'POST',
        ...(options || {}),
    });
}

export async function uploadStageList(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    console.log(data);
    return request('/api/file/excelImport', {
        data,
        method: 'POST',
        headers: {
          'Content-Type': 'multipart/form-data',
          //'accept': 'application/json',
        },
        ...(options || {}),
    });
}

