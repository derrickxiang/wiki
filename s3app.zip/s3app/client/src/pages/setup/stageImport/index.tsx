import { PageContainer } from '@ant-design/pro-components';
import { useModel } from '@umijs/max';
import { message } from 'antd';
import { ColumnsType } from 'antd/es/table';
import { useState } from 'react';
import { Stage } from '../stage/data';
import { StageChecklist } from '../stageChecklist/data';
import UploadForm from './components/UploadForm';
import { uploadStage, uploadStageChecklist } from './services';

const handleAdd = async (data: Stage[]) => {
  const hide = message.loading('Adding new stage ...');

  try {
    uploadStage(data);

    hide();
    //message.success('Stages upload successful');
    return true;
  } catch (error) {
    hide();
    message.error('Failed to upload stage, pls try again!');
    return false;
  }
};

const handleAddChecklist = async (data: StageChecklist[]) => {
  const hide = message.loading('Adding new stage checklist ...');

  try {
    uploadStageChecklist(data);

    hide();
    //message.success('Stages upload successful');
    return true;
  } catch (error) {
    hide();
    message.error('Failed to upload stage checklist, pls try again!');
    return false;
  }
};

const StageDataImport = () => {
  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};

  const [stageList, setStageList] = useState<Stage[]>([]);
  const [stageChecks, setStageChecks] = useState<StageChecklist[]>([]);

  const columns: ColumnsType<Stage> = [
    {
      title: 'Tier',
      dataIndex: 'tier',
      width: '100px',
    },
    {
      title: 'Stage Type',
      dataIndex: 'category',
      width: '120px',
    },
    {
      title: 'Stage Name',
      dataIndex: 'name',
    },
    {
      title: 'Seq',
      dataIndex: 'seq',
      width: '120px',
      sorter: (a, b) => a.seq - b.seq,
    },
    {
      title: 'Owner',
      dataIndex: 'owner',
    },
    {
      title: 'Approval',
      dataIndex: 'signOff',
    },
  ];

  const columnsChecklist: ColumnsType<StageChecklist> = [
    {
      title: 'Stage Name',
      dataIndex: 'stageName',
    },
    {
      title: 'Seq',
      dataIndex: 'seq',
      width: '120px',
      sorter: (a, b) => a.seq - b.seq,
    },
    {
      title: 'Stage Item',
      dataIndex: 'item',
    },
    {
      title: 'Input Type',
      dataIndex: 'inputType',
    },
    {
      title: 'Checklist ID',
      dataIndex: 'checklistId',
    },
    {
      title: 'Item Owner',
      dataIndex: 'owner',
    },
  ];

  return (
    <PageContainer
      header={{
        title: 'Stage Data Import',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'setup',
              title: 'Setup',
            },
            {
              path: '',
              title: 'Stage Setup',
            },
          ],
        },
      }}
      content="To import the Stage list and Stage items from excel to the system."
      tabList={[
        {
          tab: 'Stage List Import',
          key: 'stage',
          children: (
            <UploadForm
              pageTitle="Upload Stage Loader File"
              pageAction="stage"
              columns={columns}
              currentUser={currentUser}
              handleAdd={handleAdd}
              stageList={stageList}
              setStageList={setStageList}
            />
          ),
        },
        {
          tab: 'Stage Checklist Import',
          key: 'checklist',
          children: (
            <UploadForm
              pageTitle="Upload Stage Checklist Loader File"
              pageAction="stageChecklist"
              columns={columnsChecklist}
              currentUser={currentUser}
              handleAdd={handleAddChecklist}
              stageList={stageChecks}
              setStageList={setStageChecks}
            />
          ),
        },
      ]}
    ></PageContainer>
  );
};

export default StageDataImport;
