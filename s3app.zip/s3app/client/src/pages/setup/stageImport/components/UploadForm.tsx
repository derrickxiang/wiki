import { FileExcelTwoTone, UploadOutlined } from '@ant-design/icons';
import { ProFormItem } from '@ant-design/pro-components';
import { request } from '@umijs/max';
import {
  Button,
  Card,
  Col,
  message,
  notification,
  Row,
  Space,
  Table,
  Upload,
  UploadFile,
  UploadProps,
} from 'antd';
import { ColumnsType } from 'antd/es/table';
import moment from 'moment';
import { useState } from 'react';
import { Stage } from '../../stage/data';

export type Props = {
    pageTitle: string;
    pageAction: string;
  columns: ColumnsType<Stage>;
  currentUser: any;
  stageList: any[];
  setStageList: (v: any[]) => void;
  handleAdd: (v: Stage[]) => Promise<boolean>;
  options?: {
    [key: string]: any
}
};

const UploadForm = ({ 
    pageTitle,
    pageAction,
    columns, 
    currentUser, 
    stageList,
    setStageList,
    handleAdd,
    options }: Props) => {
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const [api, contextHolder] = notification.useNotification();
  
  const props: UploadProps = {
    name: 'file',
    multiple: false,
    accept:
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel',
    maxCount: 1,
    action: `${API_HOST}/api/file/excelImport/${pageAction}`,
    onRemove: (file) => {
      const index = fileList.indexOf(file);
      const newFileList = fileList.slice();
      newFileList.splice(index, 1);
      setFileList(newFileList);
    },
    beforeUpload: (file) => {
      console.log(file.type);

      const isExcel =
        file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
        file.type === 'application/vnd.ms-excel';
      if (!isExcel) {
        message.error(`${file.name} is not a Excel file.`);
      } else {
        setFileList([...fileList, file]);
      }

      return isExcel || Upload.LIST_IGNORE;
    },
    onChange(info) {
      console.log(info);
      const { status, response } = info.file;
      console.log(status);
      if (status !== 'uploading') {
        console.log(info.file, info.fileList);
      }
      if (status === 'done') {
        if (response.success) {
          setStageList(response.data);
        }
        
        console.log(stageList);

        message.success(`${info.file.name} file uploaded successfully.`);
      } else if (status === 'error') {
        message.error(`${info.file.name} file upload failed.`);
      }
    },
    fileList,
  };

  return (
    <>
    {contextHolder}
      <Space direction="vertical" style={{ width: '100%' }}>
        <Card title={pageTitle} bordered={false}>
          <Row>
            <Col span={12}>
              <ProFormItem
                label="Select data file (Excel)"
                rules={[{ required: true, message: 'Please select file.' }]}
              >
                <Upload {...props}>
                  <Button icon={<UploadOutlined />}>Select File</Button>
                </Upload>
              </ProFormItem>
            </Col>
            <Col>
              <Button
                type="link"
                onClick={() => {
                  request(`/api/file/download/${pageAction}_loader.xlsx`, {
                    method: 'GET',
                    // headers: {
                    //     'Content-Type': 'application/vnd.ms-excel',
                    // },
                    responseType: 'blob',
                  }).then((res) => {
                    const blob = new Blob([res]);
                    const objectURL = URL.createObjectURL(blob);
                    let btn = document.createElement('a');
                    btn.download = `${pageAction}_template.xlsx`;
                    btn.href = objectURL;
                    btn.click();
                    URL.revokeObjectURL(objectURL);
                    btn.remove();
                  });
                }}
              >
                <FileExcelTwoTone /> Download Excel Template
              </Button>
            </Col>
          </Row>
        </Card>
        <Card
          title="Preview the list"
          extra={[
            <Button
              type="primary"
              disabled={stageList.length === 0}
              onClick={async (e) => {
                stageList.forEach((s) => {
                  s.createBy = currentUser?.empId;
                  s.createAt = moment().format('YYYY-MM-DDTHH:mm:ss');

                  s.updateAt = moment().format('YYYY-MM-DDTHH:mm:ss');
                  s.updateBy = currentUser?.empId;
                });

                handleAdd(stageList).then(res => {
                    if (res) {
                        setFileList([]);
                        api['success']({
                          message: 'Data Uploaded Successful',
                          description:
                            'The data has been submited successfully.',
                        });
                    }
                });

              }}
            >
              Submit
            </Button>,
          ]}
        >
          <Table 
          dataSource={stageList} 
          columns={columns}
          {...options}          
          />
        </Card>
      </Space>
    </>
  );
};

export default UploadForm;
