import { request } from "umi";
import { Tool } from "./data";


export async function tools (
    params: {
        currentPage?: number;
        pageSize?: number;
        area?: string;
        section?: string;
        tooltype?: string;
        toolModel?: string;
        supplier?: string;
        location?: string;
        toolClass?: string;
    },
    options?: Record<string, any>,
    ) {
        return request<{
            data: Tool[];
            total?: Number;
            success?: Boolean;
        }>('/api/tool', {
            method: 'GET',
            params: {
                ...params,
            },
            ...(options || {}),
        });
    }

export async function addTool(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: Tool[];
    }>('/api/tool', {
        data,
        method: 'POST',
        ...(options || {}),
    });
}

export async function removeTool(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: Tool[];
    }>('/api/tool', {
        data,
        method: 'DELETE',
        ...(options || {}),
    });
}

export async function updateTool(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<Tool>('/api/tool', {
        data,
        method: 'PUT',
        ...(options || {}),
    });
}