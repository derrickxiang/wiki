
import { Tool } from '../data';
import { request } from 'umi';

export async function addTools(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: Tool[];
    }>('/api/tool/batch', {
        data,
        method: 'POST',
        ...(options || {}),
    });
}