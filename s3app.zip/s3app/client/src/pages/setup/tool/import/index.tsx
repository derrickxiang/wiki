import { PageContainer } from '@ant-design/pro-components';
import { useModel } from '@umijs/max';
import { FormInstance, message } from 'antd';
import { ColumnsType } from 'antd/es/table';
import { useRef, useState } from 'react';
import UploadForm from '../../stageImport/components/UploadForm';
import { Tool } from '../data';
import { addTools } from './services';

const handleAdd = async (data: Tool[]) => {
  const hide = message.loading('Adding new tool ...');

  try {
    addTools(data);

    hide();
    //message.success('Stages upload successful');
    return true;
  } catch (error) {
    hide();
    message.error('Failed to upload tool, pls try again!');
    return false;
  }
};

const ToolImport = () => {

  const [toolData, setToolData] = useState<Tool[]>([]);

  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};


  const columns: ColumnsType<Tool> = [
    {
      title: 'Area',
      dataIndex: 'area',
      width: '100px',
      fixed: 'left',
    },
    {
      title: 'Section',
      dataIndex: 'section',
      width: '100px',
      fixed: 'left',
    },
    {
      title: 'EQPType',
      dataIndex: 'tooltype',
      width: '100px',
      fixed: 'left',
    },
    {
      title: 'Entity',
      dataIndex: 'entity',
      width: '120px',
      fixed: 'left',
    },
    {
      title: 'EQPID',
      dataIndex: 'eqpId',
      width: '100px',
      fixed: 'left',
    },
    {
      title: 'Vendor',
      dataIndex: 'supplier',
      width: '120px',
    },
    {
      title: 'Model',
      dataIndex: 'toolModel',
      width: '120px',
    },
    {
      title: 'Phase',
      dataIndex: 'project',
      width: '100px',
    },
    {
      title: 'Type',
      dataIndex: 'toolClass',
      width: '100px',
    },
    {
      title: 'Process',
      dataIndex: 'process',
      width: '120px',
    },
    {
      title: 'Process Type',
      dataIndex: 'processType',
      width: '150px',
    },
    {
      title: 'Priority',
      dataIndex: 'priority',
      width: '120px',
      sorter: (a, b) => a.priority - b.priority,
    },    
    {
      title: 'FabBay',
      dataIndex: 'fabBay',
      width: '120px',
    },
    {
      title: 'EE Owner',
      dataIndex: 'eeOwner',
      width: '120px',
    },
    {
      title: 'PE Owner',
      dataIndex: 'peOwner',
      width: '120px',
    },
    {
      title: 'Tool Register Plan',
      dataIndex: 'toolRegistrationPlanDate',
      width: '130px',
    },
    {
      title: 'Pre Site Insp Plan',
      dataIndex: 'preSiteInspectionPlanDate',
      width: '130px',
    },
    {
      title: 'Site Insp Plan',
      dataIndex: 'siteInspectionPlanDate',
      width: '130px',
    },
    {
      title: 'Pre Move In Plan',
      dataIndex: 'preMoveInPlanDate',
      width: '130px',
    },
    {
      title: 'Move In Plan',
      dataIndex: 'moveInPlanDate',
      width: '130px',
    },
    {
      title: 'Pre ESO1 Plan',
      dataIndex: 'preESO1PlanDate',
      width: '130px',
    },
    {
      title: 'ESO1 Plan',
      dataIndex: 'esO1PlanDate',
      width: '130px',
    },
    {
      title: 'Pre ESO2 Plan',
      dataIndex: 'preESO2PlanDate',
      width: '130px',
    },
    {
      title: 'ESO2 Plan',
      dataIndex: 'esO2PlanDate',
      width: '130px',
    },
    {
      title: 'Post ESO2 Plan',
      dataIndex: 'postESO2PlanDate',
      width: '130px',
    },
    {
      title: 'EE Handover Plan',
      dataIndex: 'eeHandoverPlanDate',
      width: '130px',
    },
    {
      title: 'Process Tuning Plan',
      dataIndex: 'processTuningPlanDate',
      width: '130px',
    },
    {
      title: 'NPW Matching Plan',
      dataIndex: 'npwMatchingPlanDate',
      width: '130px',      
    },
    {
      title: 'Pre PCRB Plan',
      dataIndex: 'prePcrbPlanDate',
      width: '130px',
    },
    {
      title: 'PCRB Qual Plan',
      dataIndex: 'pcrbQualPlanDate',
      width: 130,
    },
    {
      title: 'Pre Pilot Plan',
      dataIndex: 'prePilotPlanDate',
      width: 130,
    },
    {
      title: 'Pilot Plan',
      dataIndex: 'pilotPlanDate',
      width: 130,
    },
    
    {
      title: 'Tool Register Req',
      dataIndex: 'toolRegistrationReqDate',
      width: '130px',
    },
    {
      title: 'Pre Site Insp Req',
      dataIndex: 'preSiteInspectionReqDate',
      width: '130px',
    },
    {
      title: 'Site Insp Req',
      dataIndex: 'siteInspectionReqDate',
      width: '130px',
    },
    {
      title: 'Pre Move In Req',
      dataIndex: 'preMoveInReqDate',
      width: '130px',
    },
    {
      title: 'Move In Req',
      dataIndex: 'moveInReqDate',
      width: '130px',
    },
    {
      title: 'Pre ESO1 Req',
      dataIndex: 'preESO1ReqDate',
      width: '130px',
    },
    {
      title: 'ESO1 Req',
      dataIndex: 'esO1ReqDate',
      width: '130px',
    },
    {
      title: 'Pre ESO2 Req',
      dataIndex: 'preESO2ReqDate',
      width: '130px',
    },
    {
      title: 'ESO2 Req',
      dataIndex: 'esO2ReqDate',
      width: '130px',
    },
    {
      title: 'Post ESO2 Req',
      dataIndex: 'postESO2ReqDate',
      width: '130px',
    },
    {
      title: 'EE Handover Req',
      dataIndex: 'eeHandoverReqDate',
      width: '130px',
    },
    {
      title: 'Process Tuning Req',
      dataIndex: 'processTuningReqDate',
      width: '130px',
    },
    {
      title: 'NPW Matching Req',
      dataIndex: 'npwMatchingReqDate',
      width: '130px',      
    },
    {
      title: 'Pre PCRB Req',
      dataIndex: 'prePcrbReqDate',
      width: '130px',
    },
    {
      title: 'PCRB Qual Req',
      dataIndex: 'pcrbQualReqDate',
      width: 130,
    },
    {
      title: 'Pre Pilot Req',
      dataIndex: 'prePilotReqDate',
      width: 130,
    },
    {
      title: 'Pilot Req',
      dataIndex: 'pilotReqDate',
      width: 130,
    },
    {
      title: 'Pre Site Inspection',
      dataIndex: 'preSiteInspectionLT',
      width: 130,
    },
    {
      title: 'Pre Move In',
      dataIndex: 'preMoveInLT',
      width: 130,
    },
    {
      title: 'Pre ESO 1',
      dataIndex: 'preESO1LT',
      width: 130,
    },
    {
      title: 'Pre ESO 2',
      dataIndex: 'preESO2LT',
      width: 130,
    },
    {
      title: 'Post ESO 2',
      dataIndex: 'postESO2LT',
      width: 130,
    },
    {
      title: 'Process Tuning',
      dataIndex: 'processTuningLT',
      width: 130,
    },
    {
      title: 'Pre PCRB',
      dataIndex: 'prePcrbLT',
      width: 130,
    },
    {
      title: 'Pre Pilot',
      dataIndex: 'prePilotLT',
      width: 130,
    },
    {
      title: 'Qual Data Preview',
      dataIndex: 'qualDataReviewLT',
      width: 130,
    },
  ];

  
  return (
    <PageContainer
      header={{
        title: 'Tool Import',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'setup',
              title: 'Setup',
            },
            {
              path: '',
              title: 'Tool Setup',
            },
          ],
        },
      }}
      content="Follow the guide to import tool from excel to the system."
    >
      <UploadForm
              pageTitle="Upload Tool Loader File"
              pageAction="tool"
              columns={columns}
              currentUser={currentUser}
              handleAdd={handleAdd}
              stageList={toolData}
              setStageList={setToolData}
              options={{ scroll: {
                x: 1800
              }}}
            />

    </PageContainer>
  );
};

export default ToolImport;
