import { UploadOutlined } from '@ant-design/icons';
import { PageContainer, ProFormItem, StepsForm } from '@ant-design/pro-components';
import { history } from '@umijs/max';
import { Button, Card, FormInstance, message, Result, Upload, UploadFile, UploadProps } from 'antd';
import Table, { ColumnsType } from 'antd/es/table';
import { useRef, useState } from 'react';
import { Tool } from '../data';

const StepDescriptions: React.FC<{
  stepData: Tool[];
  bordered?: boolean;
}> = ({ stepData, bordered }) => {
  const columns: ColumnsType<Tool> = [
    {
      title: 'Area',
      dataIndex: 'area',
      width: '100px',
      fixed: 'left',
    },
    {
      title: 'Section',
      dataIndex: 'section',
      width: '120px',
      fixed: 'left',
    },
    {
      title: 'EQPID',
      dataIndex: 'eqpId',
      width: '100px',
      fixed: 'left',
    },
    {
      title: 'Priority',
      dataIndex: 'priority',
      width: '120px',
      sorter: (a, b) => a.priority - b.priority,
    },
    {
      title: 'Tooltype',
      dataIndex: 'tooltype',
      width: '120px',
    },
    {
      title: 'Tool Model',
      dataIndex: 'toolModel',
    },
    {
      title: 'Supplier',
      dataIndex: 'supplier',
    },
    {
      title: 'Entity',
      dataIndex: 'entity',
      width: '130px',
    },
    {
      title: 'Tool Class',
      dataIndex: 'toolClass',
    },
    {
      title: 'Location',
      dataIndex: 'location',
    },
    {
      title: 'EE Owner',
      dataIndex: 'eeOwner',
      width: '150px',
    },
    {
      title: 'PE Owner',
      dataIndex: 'peOwner',
      width: '150px',
    },
    {
      title: 'Release Target',
      dataIndex: 'releaseTarget',
      width: 150,
    },
  ];

  return (
    <Card>
      <Table dataSource={stepData} columns={columns} />
    </Card>
  );
};

const StepResult: React.FC<{
  onFinish: () => Promise<void>;
}> = (props) => {
  return (
    <Result
      status="success"
      title="Import successful"
      subTitle="The excel was imported successfuly"
      extra={
        <>
          <Button type="primary" onClick={props.onFinish}>
            Import Another File
          </Button>
          <Button onClick={() => history.push('/setup/tool')}>View Toollist</Button>
        </>
      }
    >
    </Result>
  );
};

const ToolImport = () => {
  const [current, setCurrent] = useState(0);
  const formRef = useRef<FormInstance>();

  const [stepData, setStepData] = useState<Tool[]>([]);

  const [fileList, setFileList] = useState<UploadFile[]>([]);

  const columns: ColumnsType<Tool> = [
    {
      title: 'Area',
      dataIndex: 'area',
      width: '100px',
      fixed: 'left',
    },
    {
      title: 'Section',
      dataIndex: 'section',
      width: '120px',
      fixed: 'left',
    },
    {
      title: 'EQPID',
      dataIndex: 'eqpId',
      width: '100px',
      fixed: 'left',
    },
    {
      title: 'Priority',
      dataIndex: 'priority',
      width: '120px',
      sorter: (a, b) => a.priority - b.priority,
    },
    {
      title: 'Tooltype',
      dataIndex: 'tooltype',
      width: '120px',
    },
    {
      title: 'Tool Model',
      dataIndex: 'toolModel',
    },
    {
      title: 'Supplier',
      dataIndex: 'supplier',
    },
    {
      title: 'Entity',
      dataIndex: 'entity',
      width: '130px',
    },
    {
      title: 'Tool Class',
      dataIndex: 'toolClass',
    },
    {
      title: 'Location',
      dataIndex: 'location',
    },
    {
      title: 'EE Owner',
      dataIndex: 'eeOwner',
      width: '150px',
    },
    {
      title: 'PE Owner',
      dataIndex: 'peOwner',
      width: '150px',
    },
    {
      title: 'Release Target',
      dataIndex: 'releaseTarget',
      width: 150,
    },
  ];


  const props: UploadProps = {
    name: 'file',
    multiple: false,
    accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel',
    maxCount: 1,
    action: '/api/file/excelImport',
    onRemove: (file) => {
      const index = fileList.indexOf(file);
      const newFileList = fileList.slice();
      newFileList.splice(index, 1);
      setFileList(newFileList);
    },
    beforeUpload: (file) => {
      console.log(file.type);

      const isExcel =
        (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
          || file.type === 'application/vnd.ms-excel');
      if (!isExcel) {
        message.error(`${file.name} is not a Excel file.`);
      } else {
        setFileList([...fileList, file]);
      }

      return isExcel || Upload.LIST_IGNORE;
     
    },
    onChange(info) {
      console.log(info);
      const { status } = info.file;
      console.log(status);
      if (status !== 'uploading') {
        console.log(info.file, info.fileList);
      }
      if (status === 'done') {
        message.success(`${info.file.name} file uploaded successfully.`);
      } else if (status === 'error') {
        message.error(`${info.file.name} file upload failed.`);
      }
    },
    fileList,
  };

  
  return (
    <PageContainer
      header={{
        title: 'Tool Import',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'setup',
              title: 'Setup',
            },
            {
              path: '',
              title: 'Tool Setup',
            },
          ],
        },
      }}
      content="Follow the guide to import tool from excel to the system."
    >
<Card bordered={false}>
       

            <ProFormItem 
            label="Tool list file"
            rules={[{ required: true, message: 'Please select file.'}]}
            >
            <Upload {...props} 
            
            >
              <Button icon={<UploadOutlined />}>Select File</Button>
            </Upload>

        
            </ProFormItem>


        </Card>
        <Card>
      <Table dataSource={stepData} columns={columns} />
    </Card>

    </PageContainer>
  );
};

export default ToolImport;
