import {
  ModalForm,
  ProFormDatePicker,
  ProFormDigit,
  ProFormGroup,
  ProFormSelect,
  ProFormText,
} from '@ant-design/pro-components';
import { useRequest } from '@umijs/max';
import { Divider } from 'antd';
import { projects } from '../../project/services';
import { stages } from '../../stage/services';
import { Tool } from '../data';

export type FormProps = {
  onSubmit: (values: Tool) => Promise<void>;
  modalOpen: boolean;
  handleModalOpen: (v: boolean) => void;
  selectedTool: Tool | undefined;
};

const UpdateForm = (props: FormProps) => {
  const { data: allProject } = useRequest(projects);
  const { data: allStage } = useRequest(stages);

  return (
    <ModalForm
      title="Update Tool"
      width={'750px'}
      open={props.modalOpen}
      onOpenChange={props.handleModalOpen}
      onFinish={props.onSubmit}
      initialValues={props.selectedTool}
      params={props.selectedTool}
      request={(params) => {
        return Promise.resolve({
          data: params,
          success: true,
        });
      }}
    >
      <Divider orientation="left">Project Info</Divider>
      <ProFormGroup direction="horizontal">
        <ProFormSelect
          name={'projectId'}
          label={'Choose the Project that belongs to'}
          placeholder="Please select"
          width={'md'}
          rules={[
            {
              required: true,
              message: 'Please select a project',
            },
          ]}
          options={allProject
            ?.filter((p) => p.isEnabled)
            .map((p) => {
              return { label: p.name, value: p.id };
            })}
        />
        <ProFormDatePicker
          name={'releaseTarget'}
          label={'Release target'}
          placeholder="Please select"
          rules={[{ required: true, message: 'Please provide release target' }]}
        />
      </ProFormGroup>
      <Divider orientation="left">Basic Info</Divider>
      <ProFormGroup direction="horizontal">
        <ProFormText
          name={'area'}
          label={'Area'}
          width={'xs'}
          rules={[
            {
              required: true,
              message: 'Please provide Area info',
            },
          ]}
          placeholder="Please enter"
        />
        <ProFormText
          name={'section'}
          label={'Section'}
          width={'xs'}
          rules={[
            {
              required: true,
              message: 'Please provide Section info',
            },
          ]}
          placeholder="Please enter"
        />

        <ProFormText
          name={'eqpId'}
          label={'EQPID'}
          rules={[
            {
              required: true,
              message: 'Please provide EQPID',
            },
          ]}
          width={'sm'}
          placeholder="Please enter"
        />

        <ProFormSelect
          name={'priority'}
          label={'Priority'}
          options={[
            {
              label: '1',
              value: 1,
            },
            {
              label: '2',
              value: 2,
            },
            {
              label: '3',
              value: 3,
            },
          ]}
        />
      </ProFormGroup>
      <ProFormGroup direction="horizontal">
        <ProFormText name={'tooltype'} label={'Tooltype'} />
        <ProFormText name={'toolModel'} label={'Tool Model'} />
        <ProFormSelect
          name={'toolClass'}
          label={'Tool Class'}
          options={[
            { label: 'Process', value: 'process' },
            { label: 'Metrology', value: 'metrology' },
          ]}
        />
      </ProFormGroup>

      <Divider orientation="left">Owner Info</Divider>
      <ProFormGroup direction="horizontal">
        <ProFormText name={'eeOwner'} label={'EE Owner'} />
        <ProFormText name={'peOwner'} label={'PE Owner'} />
      </ProFormGroup>

      <Divider orientation="left">Stage Info</Divider>
      <ProFormGroup direction="horizontal">
        <ProFormSelect
          name={'currentStage'}
          label={'Current Stage'}
          placeholder="Please select"
          width={'sm'}
          options={allStage?.map((p) => {
            return { label: p.name, value: p.name };
          })}
        />

        <ProFormDigit name={'gap'} label={'Stage Gap'} />

        <ProFormSelect
          name={'status'}
          label={'Status'}
          options={[
            { label: 'Ongoing', value: 'Ongoing' },
            { label: 'Delay', value: 'Delay' },
            { label: 'Complete', value: 'Complete' },
          ]}
        />
      </ProFormGroup>
    </ModalForm>
  );
};

export default UpdateForm;
