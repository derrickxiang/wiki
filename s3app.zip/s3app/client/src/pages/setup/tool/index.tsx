import { ImportOutlined, PlusOutlined } from '@ant-design/icons';
import {
  ActionType,
  PageContainer,
  ProColumns,
  ProTable,
} from '@ant-design/pro-components';
import { useModel, useRequest, history } from '@umijs/max';
import { Button, message, Popconfirm, Select } from 'antd';
import moment from 'moment';
import { useEffect, useRef, useState } from 'react';
import { projects } from '../project/services';
import CreateForm from './components/CreateForm';
import UpdateForm from './components/UpdateForm';
import { Tool, ToolParam } from './data';
import { addTool, removeTool, tools, updateTool } from './services';

const handleAdd = async (fields: Tool) => {
  const hide = message.loading('Adding new tool ...');

  try {
    await addTool({ ...fields });
    hide();
    message.success('Tool create successful');
    return true;
  } catch (error) {
    hide();
    message.error('Failed to create prject, pls try again!');
    return false;
  }
};

const handleUpdate = async (fields: Tool) => {
  const hide = message.loading('Updating ...');

  try {
    await updateTool({ ...fields });
    hide();
    message.success('Tool update successful');
    return true;
  } catch (error) {
    hide();
    message.error('Failed to update prject, pls try again!');
    return false;
  }
};

const handleDelete = async (selectedRow: Tool) => {
  const hide = message.loading('Deleting ...');
  try {
    await removeTool({ toolId: selectedRow.id });
    hide();
    message.success('Tool delete successful');

    return true;
  } catch (error) {
    hide();
    message.error('Failed to delete tool, pls try again!');
    return false;
  }
};

const SetupTool = () => {
  const [createModalVisible, handleModalVisible] = useState(false);
  const [updateModalVisible, handleUpdateModalVisible] = useState(false);
  const { data: allTools } = useRequest(tools);
  const { data: allProjects } = useRequest(projects);

  const [selectedTool, setSelectedTool] = useState<Tool>();
  const actionRef = useRef<ActionType>();
  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};
  const [dept, setDept] = useState('');
  const [section, setSection] = useState('');

  const [deptList, setDeptList] = useState<string[]>([]);
  const [sectionList, setSectionList] = useState<string[]>([]);
  

  const handleAddTool = async (value: Tool) => {
    console.log(value);

    value.createAt = moment().format('YYYY-MM-DDTHH:mm:ss');

    if (currentUser) value.createBy = currentUser?.userId;

    const success = await handleAdd(value);
    if (success) {
      handleModalVisible(false);

      if (actionRef.current) {
        actionRef.current.reload();
      }
    }
  }

  const handleUpdateTool = async (value: Tool) => {
    console.log(value);

    if (selectedTool) {
      value.id = selectedTool.id;
    }

    value.createAt = moment().format('YYYY-MM-DDTHH:mm:ss');

    if (currentUser) value.createBy = currentUser?.userId;

    const success = await handleUpdate(value);
    if (success) {
      handleUpdateModalVisible(false);

      if (actionRef.current) {
        actionRef.current.reload();
      }
    }
  }

  const columns: ProColumns<Tool>[] = [
    {
      title: 'Area',
      dataIndex: 'area',
      width: '80px',
      fixed: 'left',
      filters: true,
    },
    {
      title: 'Section',
      dataIndex: 'section',
      width: '100px',
      fixed: 'left',
    },
    {
      title: 'EQPType',
      dataIndex: 'tooltype',
      width: '100px',
      fixed: 'left',
    },
    {
      title: 'EQPID',
      dataIndex: 'eqpId',
      width: '130px',
      fixed: 'left',
    },
    {
      title: 'Entity',
      dataIndex: 'entity',
      width: '130px',
    },
    {
      title: 'Vendor',
      dataIndex: 'supplier',
      width: '120px',
    },
    {
      title: 'Model',
      dataIndex: 'toolModel',
      width: '150px',
    },
    {
      title: 'Project',
      dataIndex: 'projectId',
      width: '150px',
      render: (_, record: Tool) => [
        <div>
          { allProjects && allProjects.find(s => s.id === record.projectId)?.name}
          </div>
        ]
    },
    {
      title: 'Type',
      dataIndex: 'toolClass',
      width: '100px',
    },
    {
      title: 'Process',
      dataIndex: 'process',
      width: '130px',
    },
    {
      title: 'Process Type',
      dataIndex: 'processType',
      width: '100px',
    },
    {
      title: 'Priority',
      dataIndex: 'priority',
      width: '120px',
      sorter: (a, b) => a.priority - b.priority,
    },
    {
      title: 'Status',
      dataIndex: 'status',
      valueType: 'select',
      width: '150px',
      valueEnum: {
        Ongoing: { text: 'Ongoing', status: 'Processing' },
        Complete: { text: 'Complete', status: 'Success' },
        Delay: { text: 'Delay', status: 'Error' },
      },
    },
    {
      title: 'Fab Bay',
      dataIndex: 'fabBay',
      width: '120px',
    },
    {
      title: 'EE Owner',
      dataIndex: 'eeOwner',
      width: '150px',
    },
    {
      title: 'PE Owner',
      dataIndex: 'peOwner',
      width: '150px',
    },
    {
      title: 'Release Target',
      dataIndex: 'releaseTarget',
      valueType: 'date',
      hideInSearch: true,
      width: 150
    },
    {
      title: 'Stage',
      dataIndex: 'currentStage',
      width: '150px',
    },
    {
      title: 'Gap',
      dataIndex: 'stageGap',
      tooltip: 'Gap for the current stage, in days',
      width: '100px',
    },
    {
      title: 'Gap(all)',
      dataIndex: 'overallGap',
      tooltip: 'Gap for overall stages, in days',
      width: '100px',
    },
    {
      title: 'Create At',
      dataIndex: 'createAt',
      hideInTable: true,
    },
    {
      title: 'Create By',
      dataIndex: 'createBy',
      hideInForm: true,
      width: '150px',
    },
    {
      title: 'Action',
      dataIndex: 'option',
      valueType: 'option',
      sorter: false,
      width: '150px',
      render: (_, record: Tool) => [
        <a
          key={'config'}
          onClick={async () => {
            setSelectedTool(record);
            handleUpdateModalVisible(true);
          }}
        >
          Edit
        </a>,
        <Popconfirm
          title="Delete the Tool"
          description="Are you sure to delete this tool?"
          onConfirm={async (e: React.MouseEvent<HTMLElement>) => {
            handleDelete(record);

            setSelectedTool(undefined);

            if (actionRef.current) {
              actionRef.current?.reload();
            }
          }}
          okText="Yes"
          cancelText="No"
        >
          <a key="remove">Remove</a>
        </Popconfirm>,
      ],
    },
  ];

  useEffect(() => {
    if (allTools) {
      setDeptList(
        [...new Set(allTools.map((t)=>t.area!))]
      )
    }
  }, [allTools]);

  useEffect(()=> {
    if (dept) {
      setSectionList(
        [...new Set(allTools?.filter(t => t.area === dept).map((s) => s.section!))]
      )
    } else {
      setSectionList([]);
    }
  }, [dept])

  return (
    <PageContainer
      header={{
        title: 'Tool List Initial Setup',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'setup',
              title: 'Setup',
            },
            {
              path: '',
              title: 'Tool Setup',
            },
          ],
        },
      }}
      content={'This is the place where you initialize and manage all the tool list.'}
      style={{ minHeight: '600px' }}

      extra={[       
        <Button color="warning" 
          onClick={()=> history.push('/setup/tool/import')}
        >
          <ImportOutlined />
          Import from Excel
        </Button>
      ]}
    >
      <ProTable<Tool, ToolParam>
        headerTitle="Tool List"
        rowKey={'id'}
        actionRef={actionRef}
        columns={columns}
        params={{dept: dept, section: section}}
        request={tools}
        scroll={{ x: 1800 }}
      search={false}            
      pagination={{
        pageSize: 10,
        showSizeChanger: false,
      }}
        toolBarRender={() => [
          <Select
          value={dept}
          onChange={(e) => setDept(e)}
          style={{ width: 120 }}
          dropdownMatchSelectWidth={false}
          placement={'topLeft'}
          options={[...deptList.map((d) => ({
            label: d,
            value: d,
          })), {
            label: 'All Depts',
            value: '',
          }]}
          />,
          <Select
          value={section}
          onChange={(e) => setSection(e)}
          style={{ width: 120 }}
          dropdownMatchSelectWidth={false}
          placement={'topLeft'}
          options={[...sectionList.map((d) => ({
            label: d,
            value: d,
          })), {
            label: 'All Sections',
            value: '',
          }]}
          />,
          <Button
            type="primary"
            key={'add'}
            onClick={() => {
              handleModalVisible(true);
            }}
          >
            <PlusOutlined /> New Tool
          </Button>,
        ]}
        style={{ minHeight: '500px' }}
      />

      <CreateForm
        modalOpen={createModalVisible}
        handleModalOpen={handleModalVisible}
        onSubmit={handleAddTool}
       />

       <UpdateForm
        modalOpen={updateModalVisible}
        handleModalOpen={handleUpdateModalVisible}
        onSubmit={handleUpdateTool}
        selectedTool={selectedTool}
        
        />
    </PageContainer>
  );
};

export default SetupTool;
