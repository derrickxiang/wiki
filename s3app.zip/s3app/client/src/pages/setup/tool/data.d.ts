
export type Tool = {
    id?: string;
    area?: string;
    section?: string;
    eqpId?: string;
    entity?: string;
    tooltype?: string;
    toolModel?: string;
    process?: string;
    supplier?: string;
    location?: string;
    fabBay?: string;
    toolClass?: string;
    eeOwner?: string;
    peOwner?: string;
    releaseTarget?: string;
    priority?: string;
    releaseCriteria?: string;
    currentStage?: string;
    status?: string;
    stageGap?: string;
    overallGap?: string;
    project?: string;
    projectId?: string;
    createAt?: string;
    createBy?: string;
}

export type ToolParam = {
    currentPage?: number;
    pageSize?: number;
    area?: string;
    dept?: string;
    section?: string;
    tooltype?: string;
    toolModel?: string;
    supplier?: string;
    location?: string;
    toolClass?: string;
}