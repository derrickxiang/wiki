import { request } from "umi";
import { Project } from "./data";


export async function projects (
    params: {
        currentPage?: number;
        pageSize?: number;
    },
    options?: Record<string, any>,
    ) {
        return request<{
            data: Project[];
            total?: Number;
            success?: Boolean;
        }>('/api/project', {
            method: 'GET',
            params: {
                ...params,
            },
            ...(options || {}),
        });
    }

export async function addProject(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: Project[];
    }>('/api/project', {
        data,
        method: 'POST',
        ...(options || {}),
    });
}

export async function setDefaultProject(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: Project[];
    }>('/api/project/default', {
        data,
        method: 'POST',
        ...(options || {}),
    });
}

export async function removeProject(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: Project[];
    }>('/api/project', {
        data,
        method: 'DELETE',
        ...(options || {}),
    });
}

export async function updateProject(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<Project>('/api/project', {
        data,
        method: 'PUT',
        ...(options || {}),
    });
}