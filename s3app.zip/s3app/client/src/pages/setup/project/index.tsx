import {
  CheckCard,
  ModalForm,
  PageContainer,
  ProCard,
  ProFormCheckbox,
  ProFormItem,
  ProFormRadio,
  ProFormText,
  ProFormTextArea,
} from '@ant-design/pro-components';
import { FormattedMessage, useModel, useRequest } from '@umijs/max';
import { Button, Checkbox, message, Popconfirm, Space, Tag } from 'antd';
import moment from 'moment';
import { useEffect, useRef, useState } from 'react';
import { Project } from './data';
import { addProject, projects, removeProject, setDefaultProject, updateProject } from './services';

const handleAdd = async (fields: Project) => {
  const hide = message.loading('Adding new project ...');

  try {
    const newProj = await addProject({ ...fields });
    hide();
    message.success('Project create successful');
    return newProj;
  } catch (error) {
    hide();
    message.error('Failed to create prject, pls try again!');
    return null;
  }
};

const handleUpdate = async (fields: Project) => {
  const hide = message.loading('Updating ...');

  try {
    await updateProject({ ...fields });
    hide();
    message.success('Project update successful');
    return true;
  } catch (error) {
    hide();
    message.error('Failed to update prject, pls try again!');
    return false;
  }
};

const SetupProject = () => {
  const [createModalVisible, handleModalVisible] = useState(false);
  const [updateModalVisible, handleUpdateModalVisible] = useState(false);
  const [openConfirm, setOpenConfirm] = useState(false);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | undefined>();
  const [selectedProjectId, setSelectedProjectId] = useState<string>();

  const showPopconfirm = () => {
    setOpenConfirm(true);
  };

  const handleDelete = async () => {
    setConfirmLoading(true);

    const hide = message.loading('Deleting project ...');
    try {
      await removeProject({ projectId: selectedProjectId });
      hide();
      message.success('Project delete successful');

      setConfirmLoading(false);
      setOpenConfirm(false);

      setProjectList(projectList.filter(p => p.id !== selectedProjectId));
      return true;
    } catch (error) {
      hide();
      message.error('Failed to delete prject, pls try again!');
      setConfirmLoading(false);
      setOpenConfirm(false);
      return false;
    }
  };

  const handleCancelDelete = () => {
    setOpenConfirm(false);
  };

  const { data: allProject } = useRequest(projects);
  //const [ allProject, setAllProject] = useState<Project[] | undefined>(undefined);

  const { initialState, setInitialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};

  const [projectList, setProjectList] = useState<Project[]>([]);
  const [ defaultProjectId, setDefaultProjectId] = useState<string>();

  useEffect(() => {
    if (selectedProjectId) {
      var proj = allProject?.filter((p) => p.id === selectedProjectId);

      if (proj?.length && proj.length > 0) {
        setSelectedProject(proj[0]);
      }
    } else {
      setSelectedProject(undefined);
    }
  }, [selectedProjectId]);

  useEffect(() => {
    if (allProject) {
        var defaultP = allProject.filter( p => p.isDefault);

        if (defaultP.length > 0) {
            setDefaultProjectId(defaultP[0].id.toString());
        }
        setProjectList(allProject);
    }
  }, [allProject])

  console.log(projectList);

  return (
    <>
      <PageContainer
        header={{
          title: 'Project Setup',
          ghost: false,
          breadcrumb: {
            //   itemRender: (item, params, items, paths) => {
            //     console.log(item);
            //     const last = items.indexOf(item) === items.length - 1;
            //     console.log(last);
            //     console.log(paths);
            //     return last ? (
            //       <span>{item.title}</span>
            //     ) : (
            //       <Link to={paths.join('/')}>{item.title}</Link>
            //     );
            //   },
            items: [
              {
                path: 'setup',
                title: 'Setup',
              },
              {
                path: '',
                title: 'Project Setup',
              },
            ],
          },
        }}
        content={
          "A project is used for reference of a group of tools, and it's setup during planning phase by IE."
        }
      >
        <ProCard
          direction="row"
          gutter={[0, 16]}
          title="Active Projects"
          style={{ minHeight: 500 }}
          extra={[
            <Button key="create" type="primary" onClick={() => handleModalVisible(true)}>
              New Project
            </Button>,
          ]}
        >
          <CheckCard.Group
            onChange={(value: any) => {
              console.log('value', value);
              setSelectedProjectId(value);
            }}
            value={selectedProjectId}
          >
            {projectList?.map((p) => (
              <CheckCard
                title={p.name}
                description={
                  <Space size="middle">
                    {p.description}

                    <Tag color={p.isEnabled ? 'green' : ''}>
                      {p.isEnabled ? 'Enabled' : 'Disabled'}
                    </Tag>

                    {p.id === defaultProjectId ? 
                    <Tag color={'warning'} >
                        Default
                        </Tag>
                        : <></>
                    }
                  </Space>
                }
                value={p.id}
                key={p.id}
              />
            ))}
          </CheckCard.Group>

          <Space size={'small'}>
          <Button
              type="primary"
              disabled={selectedProjectId == null}
              onClick={() =>{
                 setDefaultProject({projectId: selectedProjectId!});
                 setDefaultProjectId(selectedProjectId);
                 setInitialState({...initialState, currentUser: {...currentUser, defaultProject: selectedProjectId}});
                message.success("Default project updated");
              }}
            >
              Set as Default Project
            </Button>
            <Button
              type="primary"
              disabled={selectedProjectId == null}
              onClick={() => handleUpdateModalVisible(true)}
            >
              Edit the selected project
            </Button>
            <Popconfirm
              title="Confirm to delete project"
              description="Please confirm if you want to remove the project!"
              open={openConfirm}
              onConfirm={handleDelete}
              onCancel={handleCancelDelete}
              okButtonProps={{ loading: confirmLoading }}
            >
              <Button
                type="primary"
                danger
                disabled={selectedProjectId == null}
                onClick={() => setOpenConfirm(true)}
              >
                Delete the selected project
              </Button>
            </Popconfirm>
          </Space>
        </ProCard>
      </PageContainer>

      <ModalForm
        title="Create new Project"
        width={'500px'}
        open={createModalVisible}
        onOpenChange={handleModalVisible}
        onFinish={async (value: Project) => {
          console.log(value);

          value.createAt = moment().format('YYYY-MM-DDTHH:mm:ss');

          if (currentUser) value.createBy = currentUser?.userId;

          await handleAdd(value)
                .then((res: any) =>{
                    console.log(res);
                    if (res !== null) {
                        setProjectList([...projectList, res])
                    }
                     
                })
                .catch((err) => console.log(err));
          
          handleModalVisible(false);

        }}
      >
        <ProFormText
          label="Name"
          width={'md'}
          name="name"
          rules={[
            {
              required: true,
              message: (
                <FormattedMessage
                  id="pages.setup.project.name"
                  defaultMessage="Project name is required!"
                />
              ),
            },
          ]}
        />
        <ProFormTextArea label="Description" name="description" />
        <ProFormRadio.Group
          name="isEnabled"
          label={'Status'}
          options={[
            {
              label: 'Enabled',
              value: true,
            },
            {
              label: 'Disabled',
              value: false,
            },
          ]}
        />
        <ProFormCheckbox  name={"isDefault"}
            label='Set as default '
            
         > Default Project
            </ProFormCheckbox>
      </ModalForm>

      <ModalForm
        title="Update Project"
        width={'500px'}
        open={updateModalVisible}
        onOpenChange={handleUpdateModalVisible}
        onFinish={async (value: Project) => {
          console.log(value);

          value.createAt = moment().format('YYYY-MM-DDTHH:mm:ss');

          if (currentUser) value.createBy = currentUser?.userId;

          const success = await handleUpdate(value);
          if (success) {
            handleUpdateModalVisible(false);

            setProjectList(projectList)
            setSelectedProjectId(undefined);
            //window.location.reload();
          }
        }}
      >
        <ProFormText name={'id'} initialValue={selectedProjectId} hidden />
        <ProFormText
          label="Name"
          width={'md'}
          name="name"
          initialValue={selectedProject?.name}
          rules={[
            {
              required: true,
              message: (
                <FormattedMessage
                  id="pages.setup.project.name"
                  defaultMessage="Project name is required!"
                />
              ),
            },
          ]}
        />
        <ProFormTextArea
          label="Description"
          name="description"
          initialValue={selectedProject?.description}
        />
        <ProFormRadio.Group
          name="isEnabled"
          label={'Status'}
          initialValue={selectedProject?.isEnabled}
          options={[
            {
              label: 'Enabled',
              value: true,
            },
            {
              label: 'Disabled',
              value: false,
            },
          ]}
        />
        <ProFormCheckbox  name={"isDefault"}
            label='Set as default '
            initialValue={selectedProject?.isDefault}
         > Default Project
            </ProFormCheckbox>
        
      </ModalForm>
    </>
  );
};

export default SetupProject;
