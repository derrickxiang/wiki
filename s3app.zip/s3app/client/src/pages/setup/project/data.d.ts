
export type Project = {
    id: string;
    name: string;
    description?: string;
    isEnabled?: boolean;
    isDefault?: boolean;
    createAt?: string;
    createBy?: string;
}