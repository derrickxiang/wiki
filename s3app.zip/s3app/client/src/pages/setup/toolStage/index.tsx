import { PlusOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import {
  ActionType,
  CheckCard,
  ModalForm,
  PageContainer,
  ProColumns,
  ProFormItem,
  ProFormSelect,
  ProTable,
} from '@ant-design/pro-components';
import { useModel, useRequest } from '@umijs/max';
import { Avatar, Button, message, Popconfirm, Select } from 'antd';
import moment from 'moment';
import { useEffect, useRef, useState } from 'react';
import { Stage } from '../stage/data';
import { stages } from '../stage/services';
import { Tool } from '../tool/data';
import { tools } from '../tool/services';
import { ToolStage, ToolStageParam } from './data';
import { addToolStage, removeToolStage, toolStages } from './services';

const handleAdd = async (fields: ToolStage) => {
  const hide = message.loading('Adding new tool stage ...');

  try {
    await addToolStage({ ...fields });
    hide();
    //message.success('Stage checklist item create successful');
    return true;
  } catch (error) {
    hide();
    console.error(error);
    message.error('Failed to create setting item, pls try again!');
    return false;
  }
};

const handleDelete = async (selectedRow: ToolStage) => {
  const hide = message.loading('Deleting ...');
  try {
    await removeToolStage({ stageId: selectedRow.id });
    hide();
    message.success('Tool setting delete successful');

    return true;
  } catch (error) {
    hide();
    message.error('Failed to delete tool setting, pls try again!');
    return false;
  }
};

const ToolStageSetup = () => {

  const [ dataCnt, setDataCnt] = useState(0);
  const { data: allTools } = useRequest(tools);
  const { data: allStages } = useRequest(stages);
  const { data: allToolStages } = useRequest(toolStages, 
        { 
          refreshDeps: [dataCnt]
        });

  const actionRef = useRef<ActionType>();
  const [createModalVisible, handleModalVisible] = useState(false);

  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};

  const [deptList, setDeptList] = useState<string[]>([]);
  const [dept, setDept] = useState('');
  const [stageList, setStageList] = useState<{ label: string; value: string }[]>([]);

  const [selectedStages, setSelectedStages] = useState<string[]>([]);
  const [expandedRows, setExpandedRows] = useState<string[]>([]);
  const subActionRef = useRef<ActionType>();

  const expandedRowRender = (record: Tool) => {
    let data: Stage[] = [];

    const toolStage = allToolStages && allToolStages?.filter((s) => s && s.toolId === record.id);

    if (toolStage && toolStage.length > 0) {
      toolStage.map((t) => {
        data.push(allStages?.find((s) => s.id === t.stageId)!);
      });
    }

    return (
      <ProTable
        columns={[
          { title: 'Tier', dataIndex: 'tier', key: 'tier' },
          { title: 'Stage Seq', dataIndex: 'seq', key: 'seq' },
          { title: 'Stage Name', dataIndex: 'name', key: 'name' },
          { title: 'Description', dataIndex: 'description', key: 'description' },
          {
            title: 'Action',
            dataIndex: 'operation',
            key: 'operation',
            valueType: 'option',
            render: (_, stage: Stage) => [
              <Popconfirm
                title="Delete the setting"
                description="Are you sure to delete this setting?"
                icon={<QuestionCircleOutlined style={{ color: 'red' }} />}
                onConfirm={async () => {
                  const toolStage = allToolStages?.find(
                    (s) => s.toolId === record.id && s.stageId === stage.id,
                  );

                  if (toolStage) handleDelete(toolStage);

                  if (subActionRef.current) {
                    subActionRef.current?.reload();
                  }

                  if (dataCnt > 0) setDataCnt(dataCnt -1);

                  //setExpandedRows([]);
                }}
              >
                <a key="remove">Remove</a>
              </Popconfirm>,
            ],
          },
        ]}
        headerTitle={false}
        search={false}
        options={false}
        dataSource={data.sort((a, b) => a.seq - b.seq)}
        pagination={false}
        actionRef={subActionRef}
      />
    );
  };

  const columns: ProColumns<Tool>[] = [
    {
      title: 'Area',
      dataIndex: 'area',
      width: '100px',
      filters: true,
    },
    {
      title: 'Section',
      dataIndex: 'section',
      width: '120px',
    },
    {
      title: 'EQPID',
      dataIndex: 'eqpId',
      width: '100px',
    },
    {
      title: 'Priority',
      dataIndex: 'priority',
      width: '120px',
      sorter: (a, b) => a.priority - b.priority,
    },
    {
      title: 'Tooltype',
      dataIndex: 'tooltype',
      width: '120px',
    },
    {
      title: 'Tool Model',
      dataIndex: 'toolModel',
      hideInTable: true,
    },
    {
      title: 'Supplier',
      dataIndex: 'supplier',
      hideInTable: true,
    },
    {
      title: 'Entity',
      dataIndex: 'entity',
      width: '130px',
    },
    {
      title: 'Tool Class',
      dataIndex: 'toolClass',
      hideInTable: true,
    },
    {
      title: 'Location',
      dataIndex: 'location',
      hideInTable: true,
    },
  ];

  useEffect(() => {
    if (allTools) {
      // setToolList(
      //   allTools.map((t) => ({
      //     label: t.eqpId!,
      //     value: t.id!,
      //   })),
      // );
      setDeptList([...new Set(allTools.map((t) => t.area!))]);
    }
  }, [allTools]);

  // useEffect(()=> {
  //   if (allTools && dept) {
  //     setSectionList([...new Set(allTools.filter(t => t.area === dept).map((t)=>(
  //       {
  //         label: t.section!,
  //         value: t.section!,
  //       }
  //     )))]
  //       );
  //   }
  // }, [dept])

  useEffect(() => {
    if (allStages) {
      setStageList(
        allStages.map((s) => ({
          label: s.name!,
          value: s.id!,
        })),
      );
    }
  }, [allStages]);

  useEffect(()=> {
    if (allToolStages)
    setDataCnt(allToolStages?.length);
  }, [allToolStages])

  return (
    <PageContainer
      header={{
        title: 'Tool Stage Setup',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'setup',
              title: 'Setup',
            },
            {
              path: '',
              title: 'Tool Stage Setup',
            },
          ],
        },
      }}
      content={'Define how many stages a tool need go through to release.'}
    >
      <ProTable<Tool, ToolStageParam>
        headerTitle="Tool Stage Setting"
        rowKey={'id'}
        tooltip={'Expand the tool to view mapped stages'}
        actionRef={actionRef}
        columns={columns}
        expandable={{ expandedRowRender }}
        expandedRowKeys={expandedRows}
        onExpand={(expand, record) => {
          if (expand) {
            setExpandedRows([...expandedRows, record.id!]);
          } else {
            setExpandedRows(expandedRows.filter((s) => s !== record.id));
          }
        }}
        params={{ dept: dept }}
        request={tools}
        search={false}
        pagination={{
          pageSize: 10,
        }}
        toolBarRender={() => [
          <Select
            value={dept}
            onChange={(e) => setDept(e)}
            style={{ width: 120 }}
            dropdownMatchSelectWidth={false}
            placement={'topLeft'}
            options={[
              ...deptList.map((d) => ({
                label: d,
                value: d,
              })),
              {
                label: 'All Depts',
                value: '',
              },
            ]}
          />,
          <Button
            type="primary"
            key={'add'}
            onClick={() => {
              handleModalVisible(true);
            }}
          >
            <PlusOutlined /> New Setting
          </Button>,
        ]}
        style={{ minHeight: '500px' }}
      />

      <ModalForm
        title="Create New Tool Stage Mapping"
        open={createModalVisible}
        onOpenChange={handleModalVisible}
        onFinish={(value) => {
          console.log(value);

          if (value.stages && value.stages.length > 0) {
            value.toolId.map((t: string) => {
              value.stages.map((s: string) => {
                handleAdd({
                  toolId: t,
                  stageId: s,
                  updateAt: moment().format('YYYY-MM-DDTHH:mm:ss'),
                  updateBy: currentUser?.userId,
                });
              });
            });

            message.success('Tool Stage map create successful');

            if (actionRef.current) {
              actionRef.current.reload();
            }

            setDataCnt(dataCnt + 1);
            return true;
          }
        }}
      >
        <ProFormSelect
          label="Dept"
          width={'sm'}
          rules={[
            {
              required: true,
              message: 'Please select dept',
            },
          ]}
          name="area"
          options={deptList}
        />

        <ProFormSelect
          label="Select Tool(s)"
          fieldProps={{
            mode: 'multiple',
          }}
          width={'md'}
          rules={[
            {
              required: true,
              message: 'Please select a tool',
            },
          ]}
          name="toolId"
          dependencies={['area']}
          request={async (params) =>
            allTools
              ?.filter((t) => t.area === params.area)
              .map((s) => ({
                label: s.eqpId,
                value: s.id,
              }))
          }
        />

        <ProFormItem
          label="Select mapping stages"
          // rules={[
          //   {
          //     required: true,
          //     message: 'Please select stage',              
          //   },
          // ]}
          name="stages"
          extra={[
            <Button
              type="link"
              onClick={() => {
                if (allStages) {
                  setSelectedStages(allStages?.map((s) => s.id!));
                }
              }}
            >
              Select all
            </Button>,
            <Button type="link" onClick={() => setSelectedStages([])}>
              Un-select all
            </Button>,
          ]}
        >
          <CheckCard.Group
            multiple={true}
            bordered={true}
            value={selectedStages}
            onChange={(e) => {
              console.log(e);
              setSelectedStages(e as string[]);
            }}
          >
            {allStages
              ?.sort((a, b) => a.seq - b.seq)
              .map((s) => (
                <CheckCard
                  key={s.id}
                  avatar={<Avatar style={{ backgroundColor: '#87d068' }}>{s.seq}</Avatar>}
                  title={s.name}
                  value={s.id}
                  style={{ width: 200 }}
                />
              ))}
          </CheckCard.Group>
        </ProFormItem>
      </ModalForm>
    </PageContainer>
  );
};

export default ToolStageSetup;
