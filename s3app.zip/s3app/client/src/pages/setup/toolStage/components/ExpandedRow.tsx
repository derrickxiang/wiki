import { QuestionCircleOutlined } from '@ant-design/icons';
import { ActionType, ProTable } from '@ant-design/pro-components';
import { useRequest } from '@umijs/max';
import { Popconfirm } from 'antd';
import { useEffect, useRef } from 'react';
import { Stage } from '../../stage/data';
import { stages } from '../../stage/services';
import { Tool } from '../../tool/data';
import { toolStages } from '../services';

const ExpandedRowRender = (record: Tool) => {
  const { data: allStages } = useRequest(stages);
  const { data: allToolStages } = useRequest(toolStages);

  let data: Stage[] = [];

  const toolStage = allToolStages?.filter((s) => s.toolId === record.id);
  
  const actionRef = useRef<ActionType>();

  useEffect(()=> {
    if (toolStage && toolStage.length > 0) {
      toolStage.map((t) => {
        data.push(allStages?.find((s) => s.id === t.stageId)!);
      });
    }
  
  }, [toolStage])

  return (
    <ProTable
      columns={[
        { title: 'Tier', dataIndex: 'tier', key: 'tier' },
        { title: 'Stage Seq', dataIndex: 'seq', key: 'seq' },
        { title: 'Stage Name', dataIndex: 'name', key: 'name' },
        { title: 'Description', dataIndex: 'description', key: 'description' },
        {
          title: 'Action',
          dataIndex: 'operation',
          key: 'operation',
          valueType: 'option',
          render: (_, stage: Stage) => [
            <Popconfirm
              title="Delete the setting"
              description="Are you sure to delete this setting?"
              icon={<QuestionCircleOutlined style={{ color: 'red' }} />}
              onConfirm={async (e: React.MouseEvent<HTMLElement>) => {
                const toolStage = allToolStages?.find(
                  (s) => s.toolId === record.id && s.stageId === stage.id,
                );

                if (toolStage) handleDelete(toolStage);

                if (actionRef.current) {
                  actionRef.current?.reload();
                }
              }}
            >
              <a key="remove">Remove</a>
            </Popconfirm>,
          ],
        },
      ]}
      headerTitle={false}
      search={false}
      options={false}
      dataSource={data.sort((a, b) => a.seq - b.seq)}
      pagination={false}
      actionRef={actionRef}
    />
  );
};

export default ExpandedRowRender;
