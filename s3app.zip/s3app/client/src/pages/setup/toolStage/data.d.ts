
export type ToolStage = {
    id?: string;
    toolId?: string;
    eqpId?: string;
    stageId?: string;
    stageName?: string;
    area?: string;
    section?: string;
    tier?: number;
    seq?: number;
    responsibleParty?: string;
    owner?: string;
    requireDate?: string;
    requireDateBy?: string;
    planDate?: string;
    planDateBy?: string;
    forecastDate?: string;
    actualDate?: string;
    status?: string;
    totalChecklist?: number;
    completeChecklist?: number;
    leadTime?: number;
    updateAt?: string;
    updateBy?: string;
}

export type ToolStageParam = {
    currentPage?: number;
    pageSize?: number;
    dept?: string;
}