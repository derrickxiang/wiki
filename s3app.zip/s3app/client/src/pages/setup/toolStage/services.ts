import { request } from "@umijs/max";
import { ToolStage } from "./data";


export async function toolStages (
    params: {
        currentPage?: number;
        pageSize?: number;
        area?: string;
    },
    options?: Record<string, any>,
    ) {
        return request<{
            data: ToolStage[];
            total?: Number;
            success?: Boolean;
        }>('/api/toolStage', {
            method: 'GET',
            params: {
                ...params,
            },
            ...(options || {}),
        });
    }

    export async function toolStage (
        params: {
           toolId?: string;
        },
        options?: Record<string, any>,
        ) {
            return request<{
                data: ToolStage[];
                total?: Number;
                success?: Boolean;
            }>('/api/toolStage/bytool', {
                method: 'GET',
                params: {
                    ...params,
                },
                ...(options || {}),
            });
        }

export async function addToolStage(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: ToolStage[];
    }>('/api/ToolStage', {
        data,
        method: 'POST',
        ...(options || {}),
    });
}

export async function removeToolStage(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: ToolStage[];
    }>('/api/ToolStage', {
        data,
        method: 'DELETE',
        ...(options || {}),
    });
}

export async function updateToolStage(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<ToolStage>('/api/ToolStage', {
        data,
        method: 'PUT',
        ...(options || {}),
    });
}