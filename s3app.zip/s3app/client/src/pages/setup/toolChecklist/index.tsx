import { PageContainer } from "@ant-design/pro-components";

const ToolChecklistSetup = () => {

    return (
        <PageContainer
      header={{
        title: 'Tool to Checklist Mapping',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'setup',
              title: 'Setup',
            },
            {
              path: '',
              title: 'Tool Setup',
            },
          ],
        },
      }}
      content={'To setup the tool to checklist mappings.'}
      style={{ minHeight: '600px' }}

      extra={
        <></>
      }
    >
        </PageContainer>
    )
}

export default ToolChecklistSetup;