import { request } from "@umijs/max";
import { StageChecklist } from "./data";


export async function stageChecklists (
    params: {
        currentPage?: number;
        pageSize?: number;
    },
    options?: Record<string, any>,
    ) {
        return request<{
            data: StageChecklist[];
            total?: Number;
            success?: Boolean;
        }>('/api/stageChecklist', {
            method: 'GET',
            params: {
                ...params,
            },
            ...(options || {}),
        });
    }

export async function stageChecklistByName(
    params: {
        currentPage?: number;
        pageSize?: number;
        stage?: string;
    },
    options?: Record<string, any>,
    ) {
        return request<{
            data: StageChecklist[];
            total?: Number;
            success?: Boolean;
        }>('/api/stageChecklist/bystage', {
            method: 'GET',
            params: {
                ...params,
            },
            ...(options || {}),
        });
    }


export async function addStageChecklist(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: StageChecklist[];
    }>('/api/StageChecklist', {
        data,
        method: 'POST',
        ...(options || {}),
    });
}

export async function removeStageChecklist(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: StageChecklist[];
    }>('/api/StageChecklist', {
        data,
        method: 'DELETE',
        ...(options || {}),
    });
}

export async function updateStageChecklist(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<StageChecklist>('/api/StageChecklist', {
        data,
        method: 'PUT',
        ...(options || {}),
    });
}