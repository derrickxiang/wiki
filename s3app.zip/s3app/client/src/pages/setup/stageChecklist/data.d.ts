
export type StageChecklist = {
    id?: string;
    stageId?: string;
    stageName?: string;
    seq?: number;
    item?: string;
    checklistId?: string;
    templateId?: string;
    templateVer?: int;
    description?: string;
    inputType?: string;
    value?: string;
    owner?: string;
    updateAt?: string;
    updateBy?: string;
}