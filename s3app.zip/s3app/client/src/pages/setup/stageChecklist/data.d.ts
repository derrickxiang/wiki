
export type StageChecklist = {
    id?: string;
    stageId?: string;
    seq?: number;
    item?: string;
    description?: string;
    inputType?: string;
    owner?: string;
    updateAt?: string;
    updateBy?: string;
}