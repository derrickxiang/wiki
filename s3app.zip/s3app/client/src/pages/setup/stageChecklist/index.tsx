import {
  ActionType,
  ModalForm,
  PageContainer,
  ProColumns,
  ProList,
  ProTable,
} from '@ant-design/pro-components';
import { useModel, useRequest } from '@umijs/max';
import { Avatar, Button, message, Popconfirm, Radio, Space, Tag } from 'antd';
import moment from 'moment';
import { useEffect, useRef, useState } from 'react';
import { Stage } from '../stage/data';
import { stages } from '../stage/services';
import ChecklistForm from './components/ChecklistForm';
import { StageChecklist } from './data';
import {
  addStageChecklist,
  removeStageChecklist,
  stageChecklists,
  updateStageChecklist,
} from './services';

const handleAdd = async (fields: StageChecklist) => {
  const hide = message.loading('Adding new stage checklist ...');

  try {
    await addStageChecklist({ ...fields });
    hide();
    message.success('Stage checklist item create successful');
    return true;
  } catch (error) {
    hide();
    console.error(error);
    message.error('Failed to create checklist item, pls try again!');
    return false;
  }
};

const handleUpdate = async (fields: StageChecklist) => {
  const hide = message.loading('Updating ...');

  try {
    await updateStageChecklist({ ...fields });
    hide();
    message.success('Stage checklist update successful');
    return true;
  } catch (error) {
    hide();
    message.error('Failed to update Stage Checklist, pls try again!');
    return false;
  }
};

const handleDelete = async (selectedRow: StageChecklist) => {
  const hide = message.loading('Deleting ...');
  try {
    await removeStageChecklist({ stageId: selectedRow.id });
    hide();
    message.success('Checklist delete successful');

    return true;
  } catch (error) {
    hide();
    message.error('Failed to delete Stage Checklist, pls try again!');
    return false;
  }
};

const StageChecklistPage = () => {
  const { data: allStages } = useRequest(stages,{ pageSize: 50});
  const { data: allChecklists, run, loading } = useRequest(
      stageChecklists, 
      {
        pollingInterval: 2000,
      }
      );

  const [createModalVisible, handleModalVisible] = useState(false);
  const [updateModalVisible, handleUpdateModalVisible] = useState(false);

  const [stageData, setStageData] = useState<Stage[] | undefined>([]);
  const [selectedStage, setSelectedStage] = useState<Stage | undefined>({});
  const [selectedStageChecklist, setSelectedStageChecklist] = useState<StageChecklist | undefined>(
    {},
  );
  const [filterOption, setFilterOption] = useState('All');
  const [needRefresh, setNeedRefresh] = useState(false);

  const actionRef = useRef<ActionType>();

  const columns: ProColumns[] = [
    {
      title: 'Seq',
      dataIndex: 'seq',
    },
    {
      title: 'Item',
      dataIndex: 'item',
    },
    {
      title: 'Description',
      dataIndex: 'description',
    },
    {
      title: 'Input Type',
      dataIndex: 'inputType',
    },
    {
      title: 'Owner',
      dataIndex: 'owner',
    },
    {
      title: 'Action',
      dataIndex: 'option',
      valueType: 'option',
      sorter: false,
      render: (_, record: Stage) => [
        <a
          key={'config'}
          onClick={async () => {
            setSelectedStageChecklist(record);
            handleUpdateModalVisible(true);
          }}
        >
          Edit
        </a>,
        <Popconfirm
          title="Delete the Item"
          description="Are you sure to delete this checklist?"
          onConfirm={async (e: React.MouseEvent<HTMLElement>) => {
            handleDelete(record);

            if (actionRef.current) {
              actionRef.current?.reload?.();
            }
          }}
          okText="Yes"
          cancelText="No"
        >
          <a key="remove">Remove</a>
        </Popconfirm>,
      ],
    },
  ];

  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};

  console.log(allStages);

  useEffect(() => {
    if (filterOption === 'All') {
      setStageData(allStages?.sort((a, b) => a.seq - b.seq));
    } else if (filterOption === 'Main Stage') {
      setStageData(allStages?.filter((s) => s.category === 'main').sort((a, b) => a.seq - b.seq));
    } else if (filterOption === 'Sub Stage') {
      setStageData(allStages?.filter((s) => s.category === 'sub').sort((a, b) => a.seq - b.seq));
    }
  }, [filterOption, allStages]);

  return (
    <PageContainer
      header={{
        title: 'Stage Checklist Setup',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'setup',
              title: 'Setup',
            },
            {
              path: '',
              title: 'Stage Checklist Setup',
            },
          ],
        },
      }}
      content={'Setup and manage checklist of your stages.'}
    >
      <ProList<any>
        toolBarRender={() => {
          return [
            <Radio.Group
              optionType="button"
              buttonStyle="solid"
              value={filterOption}
              onChange={(e) => {
                setFilterOption(e.target.value);
              }}
              options={['All', 'Main Stage', 'Sub Stage']}
            />,
          ];
        }}
        onRow={(record: any) => {
          return {
            onMouseEnter: () => {
              // console.log(record);
            },
            onClick: () => {
              //console.log(record);
              setSelectedStage(record);
            },
          };
        }}
        rowKey="name"
        dataSource={stageData}
        actionRef={actionRef}
        showActions="hover"
        showExtra="hover"
        //expandable={{ expandedRowKeys, onExpandedRowsChange: setExpandedRowKeys }}
        metas={{
          title: {
            dataIndex: 'name',
          },
          avatar: {
            render: (_, { seq, category }) => (
              <Avatar style={{ backgroundColor: '#87d068' }}>{seq}</Avatar>
            ),
            dataIndex: 'seq',
          },
          description: {
            render: (_, record) => {
              const chkdata = allChecklists?.filter((s) => s.stageId === record.id);

              console.log(chkdata?.length);

              if (chkdata && chkdata?.length > 0) {
                return (
                  <ProTable
                    columns={columns}
                    rowKey="id"
                    style={{ width: '100%' }}
                    //actionRef={actionRef}
                    search={false}
                    options={false}
                    pagination={false}
                    dataSource={chkdata.sort((a, b) => a.seq - b.seq)}
                    
                  />
                );
              } else {
                return 'No checklist found!';
              }
            },            
            dataIndex: 'description',
          },
          subTitle: {
            render: (dom, record: any) => {
              return (
                <>
                  <div
                    style={{
                      flex: 1,
                      display: 'flex',
                      justifyContent: 'flex-end',
                    }}
                  >
                    <Space size={1}>
                      <Tag color="blue">Tier {record.tier}</Tag>
                      <Tag color={record.category == 'main' ? 'green' : 'cyan'}>
                        {record.category} stage
                      </Tag>
                    </Space>

                    <Button
                      type="link"
                      onClick={() => {
                        setSelectedStage(record);
                        handleModalVisible(true);
                      }}
                    >
                      New Checklist
                    </Button>
                  </div>
                </>
              );
            },
          },
          actions: {},
        }}
      />

      <ModalForm
        title={'Add new checklist [ Stage: ' + selectedStage?.name + ']'}
        width={600}
        open={createModalVisible}
        onOpenChange={handleModalVisible}
        onFinish={async (value: StageChecklist) => {
          value.updateAt = moment().format('YYYY-MM-DDTHH:mm:ss');
          value.stageId = selectedStage?.id;

          if (currentUser) value.updateBy = currentUser?.userId;

          console.log(value);
          const success = await handleAdd(value);
          if (success) {
            handleModalVisible(false);
            
            run({});
            if (actionRef.current) {
              actionRef.current.reload();
            }

          }
        }}
      >
        <ChecklistForm />
      </ModalForm>

      <ModalForm
        title={'Update checklist [ Stage: ' + selectedStage?.name + ']'}
        width={600}
        open={updateModalVisible}
        onOpenChange={handleUpdateModalVisible}
        onFinish={async (value: StageChecklist) => {
          value.id = selectedStageChecklist?.id;
          value.updateAt = moment().format('YYYY-MM-DDTHH:mm:ss');
          value.stageId = selectedStage?.id;

          if (currentUser) value.updateBy = currentUser?.userId;

          console.log(value);
          const success = await handleUpdate(value);
          if (success) {
            handleUpdateModalVisible(false);

            if (actionRef.current) {
              actionRef.current.reload();
            }
          }
        }}
        initialValues={selectedStageChecklist}
        params={selectedStageChecklist}
        request={(params) => {
          return Promise.resolve({
            data: params,
            success: true,
          });
        }}
      >
        <ChecklistForm />
      </ModalForm>
    </PageContainer>
  );
};

export default StageChecklistPage;
