import {
  ProFormDependency,
  ProFormDigit,
  ProFormRadio,
  ProFormSelect,
  ProFormText,
} from '@ant-design/pro-components';
import { useRequest } from '@umijs/max';
import { useEffect, useState } from 'react';
import { checklistTemplates } from '../../checklist/services';
import { getSignOffGroups } from '../../stage/services';

const ChecklistForm = () => {
  const { data: allChecklistTemplate } = useRequest(checklistTemplates);
  const { data: signOffGroups } = useRequest(getSignOffGroups);
  const [chkTemplates, setChkTemplates] = useState<{ label: String; value: string }[]>([]);

  useEffect(() => {
    if (allChecklistTemplate) {
      setChkTemplates(
        allChecklistTemplate.map(({ id, checklistId }) => ({
          label: checklistId!,
          value: id!,
        })),
      );
    }
  }, [allChecklistTemplate]);

  return (
    <>
      <ProFormRadio.Group
        label="What type of checklist you are adding?"
        name={'inputType'}
        radioType="button"
        rules={[
          {
            required: true,
            message: 'Please select the checklist type',
          },
        ]}
        options={[
          {
            label: 'Checklist Form',
            value: 'Checklist',
          },
          {
            label: 'Yes / No Question',
            value: 'Boolean',
          },
          {
            label: 'Text Input',
            value: 'Text',
          },
          {
            label: 'Notes Link',
            value: 'Notes Link',
          },
        ]}
      />
      <ProFormText
        label={'Item name'}
        width={'lg'}
        name="item"
        rules={[
          {
            required: true,
            message: 'Please enter the item name',
          },
        ]}
      />
      <ProFormDependency name={['inputType']}>
        {({ inputType }) => {
          if (inputType === 'Checklist') {
            return (
              <>
                <ProFormSelect
                  label={'Select a checklist'}
                  name="templateId"
                  width={'lg'}
                  rules={[
                    {
                      required: true,
                      message: 'Please select a checklist',
                    },
                  ]}
                  options={chkTemplates}
                />
              </>
            );
          } else {
            return <></>;
          }
        }}
      </ProFormDependency>
      <ProFormText label={'Description'} width={'lg'} name={'description'} />
      <ProFormDigit
        label={'Seq'}
        name={'seq'}
        tooltip={'Sequence of the checklist'}
        min={0}
        width={'xs'}
        initialValue={0}
      />

      <ProFormSelect
        label={'Select item owner'}
        name={'owner'}
        placeholder="Please select"
        width={200}
        secondary
        options={signOffGroups?.map((s) => ({ label: s.name, value: s.name }))}
      />
      {/* <ProFormGroup>
          <ProFormTreeSelect
          name="owner"
          label="Select item Owner"
          placeholder="Please select dept"
          allowClear
          width={200}
          secondary
          request={getSections}
          treeline={true}
          // tree-select args
          fieldProps={{
            showArrow: true,
            filterTreeNode: true,
            showSearch: true,
            dropdownMatchSelectWidth: false,
            labelInValue: false,
            autoClearSearchValue: true,
            multiple: false,
            treeNodeFilterProp: 'title',
            fieldNames: {
              label: 'title',
            },
          }}
        />
        <ProFormText
        label="Manual enter owner"
        name="owner"
        width={'sm'}
        />
          </ProFormGroup> */}
    </>
  );
};

export default ChecklistForm;
