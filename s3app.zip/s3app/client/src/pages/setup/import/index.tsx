import { UploadOutlined } from '@ant-design/icons';
import {
  PageContainer,
  ProColumns,
  ProFormCheckbox,
  ProFormDigit,
  ProFormGroup,
  ProFormItem,
  ProFormText,
  ProTable,
  StepsForm,
} from '@ant-design/pro-components';
import { useModel, history } from '@umijs/max';
import {
  Button,
  Card,
  Descriptions,
  Divider,
  FormInstance,
  message,
  Result,
  Upload,
  UploadFile,
  UploadProps,
} from 'antd';
import { RcFile } from 'antd/es/upload';
import moment from 'moment';
import { ReactElement, useRef, useState } from 'react';
import { ChecklistItem, ChecklistTemplate } from '../checklist/data';
import { addChecklistTemplate } from '../checklist/services';
import { addChecklistItem } from './services';

const { Dragger } = Upload;

const handleAddChecklist = async (fields: ChecklistTemplate) => {
  const hide = message.loading('Adding new checklist ...');

  try {
    await addChecklistTemplate({ ...fields });
    hide();
    message.success('Chcecklist create successful');
    return true;
  } catch (error) {
    hide();
    message.error('Failed to create checklist, pls try again!');
    return false;
  }
};

console.log(API_HOST);

const handleAddChecklistItem = async (fields: ChecklistItem[]) => {
  const hide = message.loading('Adding new checklist item ...');

  try {
    await addChecklistItem(fields);
    hide();
    message.success('Chcecklist item create successful');
    return true;
  } catch (error) {
    hide();
    message.error('Failed to create checklist, pls try again!');
    return false;
  }
};


const StepDescriptions: React.FC<{
  stepData: ChecklistTemplate;
  bordered?: boolean;
}> = ({ stepData, bordered }) => {
  const { name, checklistId, subTitle, headerFields, footerFields, applicant, signOff } = stepData;
  return (
    <Card>
      <Descriptions column={2} bordered={bordered}>
        <Descriptions.Item label="Checklist ID"> {checklistId}</Descriptions.Item>
        <Descriptions.Item label="Title"> {name}</Descriptions.Item>
        <Descriptions.Item label="Sub Title"> {subTitle}</Descriptions.Item>
        <Descriptions.Item label="Applicant"> {applicant}</Descriptions.Item>
        <Descriptions.Item label="Sign Off"> {signOff}</Descriptions.Item>
      </Descriptions>
      <Divider />
    </Card>
  );
};

const StepResult: React.FC<{
  onFinish: () => Promise<void>;
  children?: ReactElement;
}> = (props) => {
  return (
    <Result
      status="success"
      title="Import successful"
      subTitle="The excel was imported successfuly"
      extra={
        <>
          <Button type="primary" onClick={props.onFinish}>
            Import Another File
          </Button>
          <Button onClick={()=> history.push('/setup/checklist/template')}>View Checklist</Button>
        </>
      }
    >
      {props.children}
    </Result>
  );
};

const ChecklistImport = () => {
  const [current, setCurrent] = useState(0);
  const formRef = useRef<FormInstance>();

  const [stepData, setStepData] = useState<ChecklistTemplate>({});

  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const [fileUploaded, setFileUploaded] = useState<UploadFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const [items, setItems] = useState<ChecklistItem[]>([]);

  const { initialState } = useModel("@@initialState")

  const { currentUser } = initialState || {};

  const handleUpload = () => {
    const formData = new FormData();
    fileList.forEach((file) => {
      formData.append('files[]', file as RcFile);
    });
    setUploading(true);
    // You can use any AJAX library you like
    fetch('/api/file/excelImport', {
      method: 'POST',
      body: formData,
    })
      .then((res) => {
        console.log(res);
        return res.json();
      })
      .then(() => {
        //setFileUploaded([...fileUploaded, fileList])
        setFileList([]);
        message.success('upload successfully.');
      })
      .catch(() => {
        message.error('upload failed.');
      })
      .finally(() => {
        setUploading(false);
      });
  };

  const props: UploadProps = {
    name: 'file',
    multiple: false,
    accept:
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel',
    maxCount: 1,
    action: `${API_HOST}/api/file/excelImport/checklist`,
    onRemove: (file) => {
      const index = fileList.indexOf(file);
      const newFileList = fileList.slice();
      newFileList.splice(index, 1);
      setFileList(newFileList);
    },
    beforeUpload: (file) => {
      console.log(file.type);

      const isExcel =
        file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
        file.type === 'application/vnd.ms-excel';
      if (!isExcel) {
        message.error(`${file.name} is not a Excel file.`);
      } else {
        setFileList([...fileList, file]);
      }

      return isExcel || Upload.LIST_IGNORE;
    },
    onChange(info) {
      console.log(info);
      const { status, response } = info.file;
      console.log(status, response);
      if (status !== 'uploading') {
        console.log(info.file, info.fileList);
      }
      if (status === 'done') {
        if (response.success) {
          setItems(response.data);
        }

        message.success(`${info.file.name} file uploaded successfully.`);
      } 
      else if (status === 'error') {
        message.error(`${info.file.name} file upload failed.`);
      }
    },
    fileList,
  };

  const itemColumns: ProColumns<ChecklistItem>[] = [
    {
      title: 'No',
      dataIndex: 'seq',
    },
    {
      title: 'Category',
      dataIndex: 'category',
      width: 150,
    },
    {
      title: 'Label',
      dataIndex: 'subSeq',
    },
    {
      title: 'Sub Category',
      dataIndex: 'subCategory',
    },
    {
      title: 'Input',
      dataIndex: 'inputType',
    },
    {
      title: 'Max Length',
      dataIndex: 'maxLength',
    },
  ];

  console.log(stepData);

  return (
    <PageContainer
      header={{
        title: 'Checklist Template Import',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'setup',
              title: 'Setup',
            },
            {
              path: '',
              title: 'Checklist Setup',
            },
          ],
        },
      }}
      content="Follow the guide to import checklist from excel to the system."
    >
      <Card bordered={false}>
        <StepsForm
          current={current}
          onCurrentChange={setCurrent}
          submitter={{
            render: (props, dom) => {
              if (props.step === 3) {
                return null;
              }
              return dom;
            },
          }}
        >
          <StepsForm.StepForm<ChecklistTemplate>
            formRef={formRef}
            title="Basic Info"
            initialValues={stepData}
            onFinish={async (values) => {
              console.log(values);

              values.headerFields = values.headerFieldsArray &&  values.headerFieldsArray.join();
              values.footerFields = values.footerFieldsArray && values.footerFieldsArray.join();
              setStepData(values);
              return true;
            }}
          >
            <ProFormGroup>
              <ProFormText
                label="Checklist ID"
                width={'sm'}
                name="checklistId"
                placeholder={'Please enter checklist Id'}
                rules={[{ required: true, message: 'Please enter checklist ID' }]}
              />
            </ProFormGroup>

            <ProFormText
              label="Title"
              width="md"
              name="name"
              rules={[{ required: true, message: 'Please enter checklist name' }]}
              placeholder="Please enter checklist name"
            />
            <ProFormText
              label="Sub Title"
              width="lg"
              name="subTitle"
              placeholder="Please enter sub title"
            />
            <ProFormCheckbox.Group
              name="headerFieldsArray"
              layout="horizontal"
              label="Header Fields"
              initialValue={['Area', 'Tool ID', 'EQ Model', 'Fab Bay', 'Applicant']}
              options={['Area', 'Tool ID', 'EQ Model', 'Fab Bay', 'Applicant']}
            />
            <ProFormCheckbox.Group
              name="footerFieldsArray"
              layout="horizontal"
              label="Footer Fields"
              initialValue={['Sign off', 'Date']}
              options={['Sign off', 'Date']}
            />
            <ProFormGroup direction="horizontal">
              <ProFormText
                label="Applicant"
                name="applicant"
                placeholder="Please enter applicant"
              />
              <ProFormText label="Sign off" name="signOff" placeholder="Please enter sign off" />
            </ProFormGroup>

            <ProFormGroup direction="horizontal">
              <ProFormDigit label="Version" name="version" min={0}></ProFormDigit>
              <ProFormCheckbox name="isLatest" label="Is Latest" initialValue={true}>
                Latest
              </ProFormCheckbox>
              <ProFormDigit name="totalItems" label="Total items" min={0}></ProFormDigit>
            </ProFormGroup>
            
          </StepsForm.StepForm>

          <StepsForm.StepForm
            title="Import checklist items"
            initialValues={stepData}
            
          >
            <StepDescriptions stepData={stepData} bordered={true} />

            <ProFormItem
              label="Import Checklist Items "
              rules={[{ required: true, message: 'Please select template file.' }]}
            >
              <Upload {...props}>
                <Button icon={<UploadOutlined />}>Select File</Button>
              </Upload>
            </ProFormItem>
          </StepsForm.StepForm>
          <StepsForm.StepForm 
          title="Review and confirm"
          onFinish={async ()=>{

            stepData.updateAt = moment().format('YYYY-MM-DDTHH:mm:ss');

          if (currentUser) stepData.updateBy = currentUser?.userId;
           
          const result = await handleAddChecklist(stepData);

          console.log(result);

            if (result) {

               items.forEach((item) => {
                 item.checklistId = stepData.checklistId;
                
               })

              await handleAddChecklistItem(items);
            }

            return true;
          }}
          >
            <StepDescriptions stepData={stepData} bordered />

            <ProTable
              dataSource={items}
              columns={itemColumns}
              options={false}
              search={false}
              pagination={{ pageSize: 5 }}
            />
          </StepsForm.StepForm>

          <StepsForm.StepForm title="Finish">
            <StepResult
              onFinish={async () => {
                setCurrent(0);
                setStepData({});

                if (formRef.current) {
                  formRef.current.setFieldsValue([]);
                  formRef.current?.resetFields();
                }
                
              }}
              
            />
          </StepsForm.StepForm>
        </StepsForm>
      </Card>
    </PageContainer>
  );
};

export default ChecklistImport;
