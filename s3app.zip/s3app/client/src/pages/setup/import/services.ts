import { request } from "@umijs/max";
import { ChecklistItem } from "../checklist/data";


export async function uploadTemplate(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    console.log(data);
    return request('/api/file/excelImport', {
        data,
        method: 'POST',
        headers: {
          'Content-Type': 'multipart/form-data',
          //'accept': 'application/json',
        },
        ...(options || {}),
    });
}

export async function addChecklistItem(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: ChecklistItem[];
    }>('/api/checklist/item', {
        data,
        method: 'POST',
        ...(options || {}),
    });
}