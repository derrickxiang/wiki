import { ImportOutlined, PlusOutlined } from '@ant-design/icons';
import { ActionType, ModalForm, PageContainer, ProColumns, ProFormCheckbox, ProFormDigit, ProFormGroup, ProFormInstance, ProFormRadio, ProFormSelect, ProFormText, ProFormTextArea, ProTable } from '@ant-design/pro-components';
import { FormattedMessage, useModel, history } from '@umijs/max';
import { Button, message, Popconfirm } from 'antd';
import { FormInstance } from 'antd/lib/form';
import moment from 'moment';
import React, { useRef, useState } from 'react';
import { ChecklistItem, ChecklistParam, ChecklistTemplate } from './data';
import {
  addChecklistTemplate,
  checklistItems,
  checklistTemplates,
  removeChecklistTemplate,
  updateChecklistTemplate,
} from './services';

const handleAdd = async (fields: ChecklistTemplate) => {
  const hide = message.loading('Adding new template ...');

  try {
    await addChecklistTemplate({ ...fields });
    hide();
    message.success('Template create successful');
    return true;
  } catch (error) {
    hide();
    message.error('Failed to create prject, pls try again!');
    return false;
  }
};

const handleUpdate = async (fields: ChecklistTemplate) => {
  const hide = message.loading('Updating ...');

  try {
    await updateChecklistTemplate({ ...fields });
    hide();
    message.success('Template update successful');
    return true;
  } catch (error) {
    hide();
    message.error('Failed to update prject, pls try again!');
    return false;
  }
};

const handleDelete = async (selectedRow: ChecklistTemplate) => {
  const hide = message.loading('Deleting ...');
  try {
    await removeChecklistTemplate({ checklistTemplateId: selectedRow.id });
    hide();
    message.success('Template delete successful');

    return true;
  } catch (error) {
    hide();
    message.error('Failed to delete stage, pls try again!');
    return false;
  }
};

const ChecklistSetup = () => {
  const [createModalVisible, handleModalVisible] = useState(false);
  const [updateModalVisible, handleUpdateModalVisible] = useState(false);
  const [viewItemModalVisiable, handleItemModalVisible] = useState(false);

  const [selectedTemplate, setSelectedTemplate] = useState<ChecklistTemplate>();
  const actionRef = useRef<ActionType>();
  const formRef = useRef<ProFormInstance<ChecklistTemplate>>();

  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};

  const columns: ProColumns<ChecklistTemplate>[] = [
    {
      title: 'Checklist ID',
      dataIndex: 'checklistId',
      fixed: 'left',
      width: 150,
    },
    {
      title: 'Title',
      dataIndex: 'name',
      fixed: 'left',
      width: 250,
    },
    {
      title: 'Sub Title',
      dataIndex: 'subTitle',
      hideInSearch: true,
      width: 250,
    },
    {
      title: 'Header',
      dataIndex: 'headerFields',
      hideInSearch: true,
      width: 200,
    },
    {
      title: 'Footer',
      dataIndex: 'footerFields',
      hideInSearch: true,
      width: 150,
    },
    {
      title: 'Applicant',
      dataIndex: 'applicant',
      width: 150,
    },
    {
      title: 'Sign Off',
      dataIndex: 'signOff',
      width: 150,
    },
    {
      title: 'Version',
      dataIndex: 'version',
      width: 100,
    },
    {
      title: 'Total Items',
      dataIndex: 'totalItems',
      width: 100,
      render: (_, record: ChecklistTemplate) => [
        <a
          key={'config'}
          onClick={async () => {
            console.log(record.checklistId)

            setSelectedTemplate(record);
            
            handleItemModalVisible(true);
          }
        }
        >{record.totalItems}</a>
      ]

    },
    {
      title: 'Create At',
      dataIndex: 'createAt',
      hideInSearch: true,
      hideInTable: true,
    },
    {
      title: 'Create By',
      dataIndex: 'createBy',
      hideInSearch: true,
      hideInTable: true,
    },
    {
      title: 'Action',
      dataIndex: 'option',
      valueType: 'option',
      sorter: false,
      width: 150,
      render: (_, record: ChecklistTemplate) => [
        <a
          key={'config'}
          onClick={async () => {
            console.log(record);
            setSelectedTemplate(record);

            if (formRef.current){
              formRef.current.setFieldsValue(record);
            }
            handleUpdateModalVisible(true);
          }}
        >
          Edit
        </a>,
        <Popconfirm
          title="Delete the template"
          description="Are you sure to delete this template?"
          onConfirm={async (e: React.MouseEvent<HTMLElement>) => {
            handleDelete(record);

            setSelectedTemplate(undefined);

            if (actionRef.current) {
              actionRef.current?.reload();
            }
          }}
          okText="Yes"
          cancelText="No"
        >
          <a key="remove">Remove</a>
        </Popconfirm>,
      ],
    },
  ];

  const itemColumns: ProColumns<ChecklistItem>[] = [
    {
      title: 'No',
      dataIndex: 'seq',
    },
    {
      title: 'Category',
      dataIndex: 'category',
      width: 150,
    },
    {
      title: 'Label',
      dataIndex: 'subSeq',
    },
    {
      title: 'Sub Category',
      dataIndex: 'subCategory',
    },
    {
      title: 'Input',
      dataIndex: 'inputType',
    },
    {
      title: 'Max Length',
      dataIndex: 'maxLength',
    },
  ];


  return (
    <PageContainer
      header={{
        title: 'Checklist Template Setup',
        ghost: false,
        breadcrumb: {
          items: [
            {
              path: 'setup',
              title: 'Setup',
            },
            {
              path: '',
              title: 'Checklist Setup',
            },
          ],
        },
      }}
      content={'Setup standardized checklist template and assign it for individual tool.'}
      extra={
        <Button color="warning" 
          onClick={()=> history.push('/setup/checklist/import')}
        >
          <ImportOutlined />
          Import from Excel
        </Button>
      }
    >
      <ProTable<ChecklistTemplate, ChecklistParam>
        headerTitle="Checklist Template List"
        rowKey={'id'}
        actionRef={actionRef}
        columns={columns}
        request={checklistTemplates}
        search={false}
        scroll={{ x: 1300}}
        style={{ minHeight: 500}}
        options={false}
      />

    <ModalForm
      title="View Checklist Items"
      width={'800px'}
      open={viewItemModalVisiable}
      onOpenChange={handleItemModalVisible}
      onFinish={ async (value: any) => {

        handleItemModalVisible(false);
        return true;
      }}
      
      >
      <ProTable
          params={{ checklistId: selectedTemplate?.checklistId}}
              request={checklistItems}
              columns={itemColumns}
              options={false}
              search={false}
              pagination={{ pageSize: 6 }}
            />

      </ModalForm>

    <ModalForm
        title="Update Checklist Template"        
        width={'500px'}
        formRef={formRef}
        open={updateModalVisible}
        onOpenChange={handleUpdateModalVisible}
        params={selectedTemplate}
        initialValues={selectedTemplate}
        onFinish={async (value: any) => {
          console.log(value);

          value.id = selectedTemplate?.id;
          value.headerFields = value.headerFieldsArray &&  value.headerFieldsArray.join();
          value.footerFields = value.footerFieldsArray && value.footerFieldsArray.join();
          value.updateAt = moment().format('YYYY-MM-DDTHH:mm:ss');

          if (currentUser) value.updateBy = currentUser?.userId;

          const success = await handleUpdate(value as ChecklistTemplate);
          if (success) {
            handleUpdateModalVisible(false);

            if (actionRef.current) {
              actionRef.current.reload();
            }
          }
        }}
      >
        <ProFormGroup>
              <ProFormText
                label="Checklist ID"
                width={'sm'}
                name="checklistId"
                placeholder={'Please enter checklist Id'}
                rules={[{ required: true, message: 'Please enter checklist ID' }]}
              />
            </ProFormGroup>

            <ProFormText
              label="Title"
              width="md"
              name="name"
              rules={[{ required: true, message: 'Please enter checklist name' }]}
              placeholder="Please enter checklist name"
            />
            <ProFormText
              label="Sub Title"
              width="lg"
              name="subTitle"
              placeholder="Please enter sub title"
            />
            <ProFormCheckbox.Group
              name="headerFieldsArray"
              layout="horizontal"
              label="Header Fields"
              initialValue={['Area', 'Tool ID', 'EQ Model', 'Fab Bay', 'Applicant']}
              options={['Area', 'Tool ID', 'EQ Model', 'Fab Bay', 'Applicant']}
            />
            <ProFormCheckbox.Group
              name="footerFieldsArray"
              layout="horizontal"
              label="Footer Fields"
              initialValue={['Sign off', 'Date']}
              options={['Sign off', 'Date']}
            />
            <ProFormGroup direction="horizontal">
              <ProFormText
                label="Applicant"
                name="applicant"
                placeholder="Please enter applicant"
              />
              <ProFormText label="Sign off" name="signOff" placeholder="Please enter sign off" />
            </ProFormGroup>

            <ProFormGroup direction="horizontal">
              <ProFormDigit label="Version" name="version" min={0}></ProFormDigit>
              <ProFormCheckbox name="isLatest" label="Is Latest" initialValue={true}>
                Latest
              </ProFormCheckbox>
              <ProFormDigit name="totalItems" label="Total items" min={0}></ProFormDigit>
            </ProFormGroup>
      </ModalForm>
    </PageContainer>
  );
};

export default ChecklistSetup;
