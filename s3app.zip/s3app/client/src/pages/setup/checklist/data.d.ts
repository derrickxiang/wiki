export type ChecklistTemplate = {
  id?: string;
  name?: string;
  subTitle?: string;
  checklistId?: string;
  headerFields?: string;
  footerFields?: string;
  applicant?: string;
  signOff?: string;
  version?: number;
  isLatest?: boolean;
  totalItems?: number;
  file?: RcFile;
  updateAt?: string;
  updateBy?: string;
};

export type ChecklistItem = {
  id?: string;
  templateId?: string;
  category?: string;
  seq?: string;
  subSeq?: string;
  subCategory?: string;
  inputType?: string;
  maxLength?: string;
  checklistId?: string;
}

export type ChecklistParam = {
  current?: number;
  total?: number;
  pageSize?: number;
  currentPage?: number;
};
