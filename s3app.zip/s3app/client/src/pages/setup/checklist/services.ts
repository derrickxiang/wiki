import { request } from "@umijs/max";
import { ChecklistItem, ChecklistTemplate } from "./data";


export async function checklistTemplates (
    params: {
        currentPage?: number;
        pageSize?: number;
        name?: string;
        tier?: string;
        category?: string;
    },
    options?: Record<string, any>,
    ) {
        return request<{
            data: ChecklistTemplate[];
            total?: Number;
            success?: Boolean;
        }>('/api/checklist/template', {
            method: 'GET',
            params: {
                ...params,
            },
            ...(options || {}),
        });
    }

export async function checklistItems (
    params: {
        currentPage?: number;
        pageSize?: number;
        templateId?: string;
        checklistId?: string;
    },
    options?: Record<string, any>,
) {
    return request<{
        data: ChecklistItem[];
        total?: Number;
        success?: Boolean;
    }>('/api/checklist/items', {
        method: 'GET',
        params: {
            ...params,
        },
        ...(options || {}),
    });
}

export async function addChecklistTemplate(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<{
        data: ChecklistTemplate;
    }>('/api/checklist/template', {
        data,
        method: 'POST',
        ...(options || {}),
    });
}

export async function removeChecklistTemplate(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request('/api/checklist/template', {
        data,
        method: 'DELETE',
        ...(options || {}),
    });
}

export async function updateChecklistTemplate(
    data: {
        [key: string]: any
    },
    options?: {
        [key: string]: any
    }
){
    return request<ChecklistTemplate>('/api/checklist/template', {
        data,
        method: 'PUT',
        ...(options || {}),
    });
}