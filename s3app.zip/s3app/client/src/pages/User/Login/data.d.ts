
export type LoginParams = {
    username?: string;
    password?: string;
    autoLogin?: boolean;
    type?: string;
  };

export type LoginResult = {
    status?: number;
    statusText?: string;
    type?: string;
    currentAuthority?: string;
    data?: any;
  };

