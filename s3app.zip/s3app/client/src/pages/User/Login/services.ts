import { request, history } from "@umijs/max";
import { LoginParams, LoginResult, UserTxn } from "./data";

export async function currentUser(options?: { [key: string]: any }) {
    return request<{
      data: API.CurrentUser;
    }>('/api/account/currentUser', {
      method: 'GET',
      ...(options || {}),
    });
  }
  
  export async function outLogin(options?: { [key: string]: any }) {

    localStorage.removeItem('s3-user-token');
    history.push('/user/login');

    // return request<Record<string, any>>('/api/account/logout', {
    //   method: 'POST',
    //   ...(options || {}),
    // });
  }
  
  export async function login(body: LoginParams, options?: { [key: string]: any }) {
    return request<LoginResult>('/api/account/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    });
  }
  
  export async function getNotices(options?: { [key: string]: any }) {
    return request<API.NoticeIconList>('/api/account/notices', {
      method: 'GET',
      ...(options || {}),
    });
  }
