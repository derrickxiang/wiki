import { CurrentUser } from '@/models/data';
import { PageContainer, ProCard } from '@ant-design/pro-components';
import { Access, useAccess, useModel } from '@umijs/max';
import { Avatar, Skeleton } from 'antd';
import { FC } from 'react';

const PageHeaderContent: FC<{ currentUser: Partial<CurrentUser> }> = ({ currentUser }) => {
  const loading = currentUser && Object.keys(currentUser).length;
  const today = new Date();
  const currHr = today.getHours();
  let welcomeMsg = '';

  if (currHr < 12) {
    welcomeMsg = 'Morning';
  } else if (currHr < 18) {
    welcomeMsg = 'Afternoon';
  } else {
    welcomeMsg = 'Evening';
  }

  if (!loading) {
    return <Skeleton avatar paragraph={{ rows: 1 }} active />;
  }

  return (
    <div>
      <div>
        <Avatar size="large" src={currentUser.avatar} />
      </div>
      <div>
        <div>
          {welcomeMsg},{currentUser.name}
          !
        </div>
        <div>
          {currentUser.title} |{currentUser.group}
        </div>
      </div>
    </div>
  );
};

const Dashboard: FC = () => {
  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};
  const access = useAccess();

  console.log(access);
  
  if (access.canAdmin) {
    console.log(access);       
  }

  console.log(currentUser);
  
  return (
    <PageContainer title="Dashboard" >
      <ProCard
        style={{
          height: '100vh',
          minHeight: 800,
        }}
      >
        <div />
       
      </ProCard>

      
    </PageContainer>
  );
};

export default Dashboard;
