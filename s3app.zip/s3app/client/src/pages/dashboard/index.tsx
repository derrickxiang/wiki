import { CurrentUser } from '@/models/data';
import { PageContainer, ProCard, StatisticCard } from '@ant-design/pro-components';
import { useAccess, useModel } from '@umijs/max';
import { Alert, Avatar, Button, Col, Row, Skeleton, Space, Statistic, Table } from 'antd';
import { BarGauge, Bullet, Chart } from 'devextreme-react';
import {
  CommonSeriesSettings,
  Export,
  Grid,
  Legend,
  Series,
  Title,
  Tooltip,
  ValueAxis,
} from 'devextreme-react/chart';
import { Label } from 'devextreme-react/circular-gauge';
import moment from 'moment';
import { FC } from 'react';

const PageHeaderContent: FC<{ currentUser: Partial<CurrentUser> }> = ({ currentUser }) => {
  const loading = currentUser && Object.keys(currentUser).length;
  const today = new Date();
  const currHr = today.getHours();
  let welcomeMsg = '';

  if (currHr < 12) {
    welcomeMsg = 'Morning';
  } else if (currHr < 18) {
    welcomeMsg = 'Afternoon';
  } else {
    welcomeMsg = 'Evening';
  }

  if (!loading) {
    return <Skeleton avatar paragraph={{ rows: 1 }} active />;
  }

  return (
    <div>
      <div>
        <Avatar size="large" src={currentUser.avatar} />
      </div>
      <div>
        <div>
          {welcomeMsg},{currentUser.name}!
        </div>
        <div>
          {currentUser.title} |{currentUser.group}
        </div>
      </div>
    </div>
  );
};

const statusGauge = () => {
  return (
    <BarGauge id="gauge" startValue={0} endValue={10} defaultValues={7.5}>
      <Label
        indentFromTick={30}
        format={{
          type: 'fixedPoint',
          precision: 1,
        }}
      />
    </BarGauge>
  );
};

const progressData: any = [
  {
    date: '2023-05-11',
    onTime: 100,
    delay: 102,
    overdue: 0,
    actual: 1.1,
    target: 1.2,
  },
  {
    date: '2023-05-12',
    onTime: 110,
    delay: 101,
    overdue: 0,
    actual: 2.1,
    target: 2.2,
  },
  {
    date: '2023-05-13',
    onTime: 120,
    delay: 102,
    overdue: 0,
    actual: 2.3,
    target: 2.2,
  },
  {
    date: '2023-05-14',
    onTime: 200,
    delay: 102,
    overdue: 0,
    actual: 3.1,
    target: 3.2,
  },
  {
    date: '2023-05-15',
    onTime: 220,
    delay: 102,
    overdue: 0,
    actual: 3.5,
    target: 3.2,
  },
  {
    date: '2023-05-16',
    onTime: 230,
    delay: 102,
    overdue: 0,
    actual: 4.1,
    target: 4.2,
  },
  {
    date: '2023-05-17',
    onTime: 250,
    delay: 102,
    overdue: 0,
    actual: 5.1,
    target: 5.2,
  },
  {
    date: '2023-05-20',
    onTime: 260,
    delay: 92,
    overdue: 0,
    actual: 7.1,
    target: 6.2,
  },
  {
    date: '2023-05-21',
    onTime: 280,
    delay: 100,
    overdue: 0,
    actual: 8.1,
    target: 7.2,
  },
  {
    date: '2023-05-22',
    onTime: 300,
    delay: 102,
    overdue: 0,
    actual: 8.1,
    target: 8.2,
  },
  {
    date: '2023-05-23',
    onTime: 310,
    delay: 101,
    overdue: 0,
    actual: 9.1,
    target: 9.2,
  },
  {
    date: '2023-05-24',
    onTime: 320,
    delay: 102,
    overdue: 0,
    actual: 10.3,
    target: 10.2,
  },
  {
    date: '2023-05-26',
    onTime: 330,
    delay: 102,
    overdue: 0,
    actual: 13.1,
    target: 13.2,
  },
  {
    date: '2023-05-27',
    onTime: 350,
    delay: 102,
    overdue: 0,
    actual: 13.5,
    target: 13.2,
  },
  {
    date: '2023-05-28',
    onTime: 355,
    delay: 102,
    overdue: 0,
    actual: 14.1,
    target: 14.2,
  },
  {
    date: '2023-05-29',
    onTime: 380,
    delay: 102,
    overdue: 0,
    actual: 15.1,
    target: 15.2,
  },
  {
    date: '2023-05-30',
    onTime: 400,
    delay: 92,
    overdue: 0,
    actual: 17.1,
    target: 16.2,
  },
  {
    date: '2023-06-01',
    onTime: 420,
    delay: 100,
    overdue: 0,
    actual: 18.1,
    target: 17.2,
  },
];

const hiliteColumns: any = [
  {
     title: 'Rating',
    dataIndex: 'priority',
  },{
    title: 'Area',
   dataIndex: 'area',
 },{
  title: 'Tool',
 dataIndex: 'eqpId',
},{
  title: 'Stage Due Date',
 dataIndex: 'dueDate',
},{
  title: 'Gap Day',
 dataIndex: 'gap',
},{
  title: 'Reason',
 dataIndex: 'reason',
},{
  title: 'Catch Up Plan',
 dataIndex: 'catchUp',
},{
  title: 'Due Date',
 dataIndex: 'planDueDate',
},
];

const hiliteData: any = [
  {
    priority: 1,
    area: 'DF1',
    eqpId: 'HI-A01',
    dueDate: '2024-08-10',
    gap: 10,
    reason: 'Part shortage',
    catch:'Shorten ESO1 stage period',
    planDueDate: '2024-10-13',
  },
  {
    priority: 1,
    area: 'DF1',
    eqpId: 'HI-A01',
    dueDate: '2024-08-10',
    gap: 10,
    reason: 'Part shortage',
    catch:'Shorten ESO1 stage period',
    planDueDate: '2024-10-13',
  },
  {
    priority: 1,
    area: 'DF1',
    eqpId: 'HI-A01',
    dueDate: '2024-08-10',
    gap: 10,
    reason: 'Part shortage',
    catch:'Shorten ESO1 stage period',
    planDueDate: '2024-10-13',
  },
];

const progressSources: any = [
  {
    value: 'onTime',
    name: 'On Time',
  },
  {
    value: 'delay',
    name: 'Delayed',
  },
  {
    value: 'overdue',
    name: 'Overdue',
  },
];

const Dashboard: FC = () => {
  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};
  const access = useAccess();

  console.log(access);

  if (access.canAdmin) {
    console.log(access);
  }

  console.log(currentUser);

  return (
    <PageContainer>
        <ProCard
          title="Dashboard"
          extra={moment().format('YYYY-MM-DD')}
          // split={'vertical'}
          headerBordered
          //bordered
          style={{
           // height: '100vh',
            minHeight: 800,
          }}
          gutter={[16, 16]}
          wrap
        >
          <ProCard
            title="LC0 Pilot Line Countdown"
            style={{ minHeight: 230 }}
            colSpan={6}
            hoverable
            bordered
            boxShadow
          >
            <StatisticCard
              statistic={{
                value: 150,
                suffix: 'days',
              }}
              chart={
                <img
                  src="https://gw.alipayobjects.com/zos/alicdn/PmKfn4qvD/mubiaowancheng-lan.svg"
                  alt="progress"
                  width="80%"
                />
              }
            />
          </ProCard>
          <ProCard
            colSpan={6}
            title={'Overall Schedule '}
            style={{ minHeight: 230 }}
            hoverable
            bordered
            boxShadow
          >
            <StatisticCard
              statistic={{
                value: 7.5,
                suffix: 'days',
                description: <></>,
              }}
              chart={
                <BarGauge
                  id="gauge"
                  startValue={0}
                  endValue={10}
                  defaultValues={7.5}
                  relativeInnerRadius={0.8}
                  size={{ height: 80 }}
                  label={false}
                ></BarGauge>
              }
              chartPlacement="right"
            />
          </ProCard>
          <ProCard
            style={{ minHeight: 230 }}
            title={'Overall Hookup '}
            colSpan={6}
            hoverable
            bordered
            boxShadow
          >
            <StatisticCard
              statistic={{
                title: 'Passed',
                value: 784,
                description: <Statistic title="Total" value="870" />,
              }}
            />
          </ProCard>
          <ProCard
            style={{ minHeight: 230 }}
            title={'Pilot Line Status'}
            colSpan={6}
            hoverable
            bordered
            boxShadow
          >
            <table width={'100%'}>
              <tr>
                <td style={{ width: '30%' }}>Current</td>
                <td>
                  <Bullet
                    className="bullet"
                    startScaleValue={0}
                    endScaleValue={85}
                    value={70}
                    target={75}
                    color={'green'}
                  ></Bullet>
                </td>
              </tr>
              <tr>
                <td>IE Tgt</td>
                <td>
                  <Bullet
                    className="bullet"
                    startScaleValue={0}
                    endScaleValue={75}
                    value={50}
                    target={65}
                    color={'blue'}
                  ></Bullet>
                </td>
              </tr>
            </table>
          </ProCard>

          <ProCard colSpan={16} hoverable bordered boxShadow>
            <Chart id="chart" palette={'Material'} dataSource={progressData}>
              <CommonSeriesSettings argumentField="date" type="bar" />
              {progressSources.map((item) => (
                <Series key={item.value} valueField={item.value} name={item.name} />
              ))}
              <Series axis="total" type="spline" valueField="actual" name="Actual" />

              <Series axis="total" type="spline" valueField="target" name="Target" />
              <ValueAxis title="Tool count">
                <Grid visible={true} />
              </ValueAxis>
              <ValueAxis name="total" position="right" title="Gap days">
                <Grid visible={true} />
              </ValueAxis>

              <Legend verticalAlignment="bottom" horizontalAlignment="center" />
              <Export enabled={true} />
              <Tooltip enabled={true} shared={true}></Tooltip>
              <Title text="Overall P3 Installation Progress" />
            </Chart>
          </ProCard>

          <ProCard
          style={{ minHeight: 430, backgroundColor: '#fff2f0', border: '1px solid #ffccc7' }}
          title={'Abnormal Escalation Cases'}
          boxShadow={true}
          colSpan={8} hoverable bordered>

          </ProCard>

          <ProCard
          title={'Gap Day Tool Installation Status Highligh'}
          boxShadow
          style={{ minHeight: 230 }} colSpan={24} hoverable bordered>
<Table
            columns={hiliteColumns}
            dataSource={hiliteData}
            bordered
            
            footer={() => (<Button>Review</Button>)}
          />
          </ProCard>
       
      </ProCard>
    </PageContainer>
  );
};

export default Dashboard;
