/**
 * @see https://umijs.org/zh-CN/plugins/plugin-access
 * */
export default function access(initialState: { currentUser?: API.CurrentUser } | undefined) {
  const { currentUser } = initialState ?? {};
  return {
    canAdmin: currentUser && currentUser.roles?.includes('Admin'),
    isESIguy: currentUser && currentUser.roles?.includes('ESI'),
    isIEguy: currentUser && currentUser.dept?.toUpperCase() === "OP-OPE12I-IE",
    isITguy: currentUser && currentUser.dept?.includes("IT"),
    isFOCguy: currentUser && (currentUser.dept?.toUpperCase() === "FOC-M&E12I" || currentUser.dept?.toUpperCase() === "FOC-FE12I"),
    isESHguy: currentUser && currentUser.dept?.toUpperCase() === "GRM&ESH-ESH12I-SE",
    isQAguy: currentUser && currentUser.dept?.toUpperCase() === "QA-QA12I",
  };
}
