import { tools } from "@/pages/setup/tool/services";
import { ProFormDependency, ProFormGroup, ProFormSelect, ProFormTreeSelect } from "@ant-design/pro-components";
import { useRequest } from "@umijs/max";
import { Cascader } from "antd";
import { useEffect, useState } from "react";

export type DeptSelectProps = {
    deptName?: string;
    sectionName?: string;
  value?: string;
  setValue?: (v: string) => void;
};


const EQSectionSelect = ({
    deptName,
    sectionName,
    value,
    setValue
}: DeptSelectProps) => {

    const { data: allTools} = useRequest(tools);

    const [deptList, setDeptList] = useState<string[]>([]);
    const [toolTreeData, setToolTreeData] = useState<any[]>([]);
    
    const onChange = (newValue: string[]) => {
        console.log(newValue);
    
        if (setValue) setValue(newValue.join());
      };

      useEffect(()=> {
        if (allTools) {
            setToolTreeData(
              [...new Set(allTools.map((t) => t.area))].map((d) => ({
                title: d,
                key: 'D_' + d,
                children: [...new Set(allTools.filter((t) => t.area === d).map((t) => t.section))].map(
                  (s) => ({
                    title: s,
                    key: 'D_' + d + '_S_' + s,
                    children: [...new Set(allTools.filter((t) => t.area === d && t.section === s))].map(
                      (t) => ({
                        title: t.eqpId,
                        key: 'E_' + t.eqpId,
                      }),
                    ),
                  }),
                ),
              })),
            );
            }      
      }, [allTools])
      
    return (
        <ProFormGroup direction="horizontal">
            <Cascader options={toolTreeData}  />
     
    </ProFormGroup>
    )
}

export default EQSectionSelect;