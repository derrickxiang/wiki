import { projects } from '@/pages/setup/project/services';
import { ExclamationCircleOutlined } from '@ant-design/icons';
import { useRequest } from '@umijs/max';
import { Modal, Select, Spin } from 'antd';
import { useState } from 'react';
import { useModel } from 'umi';

const ProjectSelect = () => {
  const { initialState, setInitialState } = useModel('@@initialState');
  const loading = (
    <span>
      <Spin
        size="small"
        style={{
          marginLeft: 8,
          marginRight: 8,
        }}
      />
    </span>
  );

  if (!initialState) {
    return loading;
  }

  const { currentUser } = initialState;

  if (!currentUser || !currentUser.name) {
    return loading;
  }

  const { data: allProject } = useRequest(projects);

  const [modal, contextHolder] = Modal.useModal();
  const [defaultProj, setDefaultProj] = useState(currentUser.defaultProject);

  const confirm = (e: any) => {
    console.log(e);
    modal.confirm({
      title: 'Confirm',
      icon: <ExclamationCircleOutlined />,
      content: `Please confirm to switch to the project - ${e} !`,
      okText: 'Confirm',
      cancelText: 'Cancel',
      onOk: () => {
        console.log('confirmed');
        setInitialState({ ...initialState, currentUser: { ...currentUser, defaultProject: e } });

        setDefaultProj(e);
      },
      onCancel: () => {
        console.log('cancelled');
      },
    });
  };

  return (
    <>
      <Select
        value={defaultProj}        
        style={{ width: 150 }}
        placeholder={'Default Project'}
        disabled={false}
        onSelect={confirm}
        options={allProject
          ?.filter((p) => p.isEnabled)
          .map((p) => {
            return { label: p.name, value: p.name };
          })}
      />
      {contextHolder}
    </>
  );
};

export default ProjectSelect;
