import { request } from '@umijs/max';
import { SectionNode } from './data';

export async function getSections(
  params: {
    currentPage?: number;
    pageSize?: number;
  },
  options?: Record<string, any>,
) {
  return request<{
    data: SectionNode[];
    total?: Number;
    success?: Boolean;
  }>('/api/account/sectionNodes', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

export async function getEqSections(
  params: {
    currentPage?: number;
    pageSize?: number;
  },
  options?: Record<string, any>,
) {
  return request<{
    data: SectionNode[];
    total?: Number;
    success?: Boolean;
  }>('/api/account/eqSectionNodes', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

export async function getDeptEmployee(
  params: {
    dept: string;
  },
  options?: Record<string, any>,
) {
  return request<{
    data: SectionNode[];
    total?: Number;
    success?: Boolean;
  }>('/api/account/employeeByDept', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

export async function getPeople(
  params: {
    currentPage?: number;
    pageSize?: number;
  },
  options?: Record<string, any>,
) {
  return request<{
    data: SectionNode[];
    total?: Number;
    success?: Boolean;
  }>('/api/account/employeeNodes', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}
