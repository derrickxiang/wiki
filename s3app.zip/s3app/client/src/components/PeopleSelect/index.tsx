import {
  ProFormDependency,
  ProFormGroup,
  ProFormSelect,
  ProFormTreeSelect,
} from '@ant-design/pro-components';
import { useRequest } from '@umijs/max';
import { getDeptEmployee, getSections } from './services';

export type PeopleSelectProps = {
    deptName?: string;
    empName?: string;
  value?: string;
  setValue?: (v: string) => void;
};

const PeopleSelect = ({ deptName, empName, value, setValue }: PeopleSelectProps) => {
  
  const { data } = useRequest(getSections);
 
  console.log(data);

  const onChange = (newValue: string[]) => {
    console.log(newValue);

    if (setValue) setValue(newValue.join());
  };

  return (
    <ProFormGroup direction="horizontal">
      <ProFormTreeSelect
        name={deptName}
        placeholder="Please select dept"
        allowClear
        width={200}
        secondary
        request={getSections}
        treeline={true}
        // tree-select args
        fieldProps={{
          showArrow: true,
          filterTreeNode: true,
          showSearch: true,
          dropdownMatchSelectWidth: false,
          labelInValue: false,
          autoClearSearchValue: true,
          multiple: false,
          treeNodeFilterProp: 'title',
          fieldNames: {
            label: 'title',
          },
        }}
      />

      <ProFormDependency name={[deptName]}>
        {({ section }) => {
          if (section) {
            return (
              <ProFormSelect
                name={empName}
                mode="multiple"
                width={300}
                placeholder="Please select employee"
                params={{
                  dept: section,
                }}
                allowClear={false}
                onChange={onChange}
                request={getDeptEmployee}
                fieldProps={{
                  optionItemRender(item) {
                    return item.title;
                  },
                  
                }}
                fieldNames={{
                    label: 'title',
                  }}
              />
            );
          } else {
            return (
                <ProFormSelect
                    name={empName}
                    mode="multiple"
                    width={300}
                    placeholder="Please select employee"
                />
            )
          }
        }}
      </ProFormDependency>
    </ProFormGroup>
  );
};

export default PeopleSelect;
