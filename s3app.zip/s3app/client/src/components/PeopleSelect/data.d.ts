
export type SectionNode = {
    title: string;
    value: string;
    children?: any[];
}